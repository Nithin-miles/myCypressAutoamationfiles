const NODE_ENV = process.env.NODE_ENV
const path = require('path')
var webpack = require('webpack')
module.exports = {
    // //服务
    devServer: {
        port: 8089,
        proxy: {
            "/api": {
                target: "http://192.168.19.115:6001",
                // target: "http://192.168.19.234:6001",
                changeOrigin: true,
                pathRewrite: {
                    "^/api": "/"
                }
            }
        },
        hot: true
    },
}