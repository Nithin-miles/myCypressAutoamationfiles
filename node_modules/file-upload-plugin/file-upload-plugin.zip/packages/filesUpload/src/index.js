const treeData = [{
    title: '我的收藏',
    key: '0-0',
    slots: {
        icon: 'folder',
    },
}, {
    title: '个人空间',
    key: '0-1',
    slots: {
        icon: 'folder',
    },
    type: 0,
    children: [{
        title: '工作文件夹',
        key: '0-1-0',
        slots: {
            icon: 'file'
        }
    }, ],
}, {
    title: '机构空间',
    key: '0-2',
    slots: {
        icon: 'folder',
    },
    type: 1,
    children: [{
        title: '综合办公室',
        key: '0-2-0',
        slots: {
            icon: 'file'
        }
    }, ],
}, {
    title: '系统空间',
    key: '0-3',
    slots: {
        icon: 'folder',
    },
    type: 2,
    children: [{
        title: '基础信息平台',
        key: '0-3-0',
        slots: {
            icon: 'file'
        }
    }, ],
}, {
    title: '快速访问',
    key: '0-4',
    slots: {
        icon: 'folder',
    },
    children: [{
        title: '外链分享',
        key: '0-4-0',
        slots: {
            icon: 'file'
        }
    }, {
        title: '发布门户',
        key: '0-4-1',
        slots: {
            icon: 'file'
        }
    }, {
        title: '共享交换',
        key: '0-4-2',
        slots: {
            icon: 'file'
        }
    }, {
        title: '回收站',
        key: '0-4-3',
        slots: {
            icon: 'file'
        }
    }, ],
}, {
    title: '文件类型',
    key: '0-5',
    slots: {
        icon: 'folder',
    },
    children: [{
        title: '图片',
        key: '0-5-0',
        slots: {
            icon: 'file'
        }
    }, {
        title: '文档',
        key: '0-5-1',
        slots: {
            icon: 'file'
        }
    }, {
        title: '音视频',
        key: '0-5-2',
        slots: {
            icon: 'file'
        }
    }, {
        title: '压缩包',
        key: '0-5-3',
        slots: {
            icon: 'file'
        }
    }, {
        title: '矢量文件',
        key: '0-5-4',
        slots: {
            icon: 'file'
        }
    }, {
        title: '栅格文件',
        key: '0-5-5',
        slots: {
            icon: 'file'
        }
    }, {
        title: '数据文件',
        key: '0-5-6',
        slots: {
            icon: 'file'
        }
    }, {
        title: '其他',
        key: '0-5-7',
        slots: {
            icon: 'file'
        }
    }, ],
}, ];

const FileListColumns = [{
        title: '文件名',
        dataIndex: 'fileName',
        sorter: (a, b) => a.name > b.name,
        scopedSlots: { customRender: 'fileName' },
        align: 'left',
        width: 300,
    },
    {
        title: '更新时间',
        dataIndex: 'updateDate',
        sorter: (a, b) => a.time > b.time,
        align: 'left',
    },
    {
        title: '类型',
        dataIndex: 'fileType',
        sorter: (a, b) => a.time > b.time,
        align: 'left',
    },
    {
        title: '文件大小',
        dataIndex: 'fileStorage',
        // slots: { title: 'fileStorage' },
        scopedSlots: { customRender: 'fileStorage' },
        align: 'left',
    },
    {
        title: '是否发布云门户',
        dataIndex: 'cloudPortal',
        sorter: (a, b) => a.portal > b.portal,
        scopedSlots: { customRender: 'cloudPortal' },
        align: 'left',
    },
    {
        title: '是否被引用',
        dataIndex: 'quote',
        sorter: (a, b) => a.quote > b.quote,
        scopedSlots: { customRender: 'quote' },
        align: 'left',
    },
    {
        title: '是否已分享',
        dataIndex: 'share',
        sorter: (a, b) => a.share > b.share,
        scopedSlots: { customRender: 'share' },
        align: 'left',
    },
];

const FileListData = [];
for (let i = 0; i < 46; i++) {
    FileListData.push({
        key: i,
        name: '重要文档' + i,
        time: '2021-5-' + i,
        type: (i + 1) % 2 == 0 ? 'folder' : 'file',
        collect: (i + 1) % 2 == 0 ? true : false,
        size: '6' + i * 3,
        portal: i % 3 == 0 ? `是` : `否`,
        quote: i % 3 == 0 ? `否` : `是`,
        share: i % 3 == 0 ? `是` : `否`,
    });
}
export {
    treeData,
    FileListColumns,
    FileListData
}