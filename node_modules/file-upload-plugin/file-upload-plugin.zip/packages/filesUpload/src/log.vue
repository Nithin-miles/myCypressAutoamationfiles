<template>
  <div class="main">
    <div class="left">
      <div class="top">
        <div style="display: flex">
          <a-progress
            :percent="50"
            size="small"
            status="active"
            :strokeWidth="30"
            :showInfo="false"
          />
          <div class="totalText">总空间20G</div>
        </div>
        <div class="text">
          <div>已使用123</div>
          <div>已使用123</div>
        </div>
      </div>
      <div class="echarts">
        <div id="echarts"></div>
      </div>
    </div>
    <div class="right">
      <div class="fileLog">
        <div class="title">文档日志({{ logList.length }}条记录)</div>
        <div
          class="content"
          :style="{
            'overflow-y': 'scroll',
            'overflow-x': 'hidden',
          }"
        >
          <div class="log" v-for="(item, index) in logList" :key="index">
            <div class="sign">
              <a-icon type="to-top" />
            </div>
            <div class="cot">
              <div class="title">
                <div class="text">
                  在{{ item.where_is }}{{ item.action_name }}了{{
                    item.file_number
                  }}
                </div>
                <div class="time">{{ showTime(item.create_time) }}</div>
              </div>
              <div class="info" v-for="(i, iKey) in item.file_name" :key="iKey">
                {{ i }}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import * as echarts from "echarts";
import axios from "axios";
import Vue from "vue";
Vue.prototype.$axios = axios;
export default {
  data() {
    return {
      token: "f0f3150d-37fe-4802-8958-6134f4fa3887",
      logList: [],
    };
  },
  created() {
    this.getLog();
  },
  mounted() {
    this.init();
    console.log(this.logList, 3322);
  },
  methods: {
    init() {
      this.showEcharts();
      //localhost:8004/cloudoffice/selectDocInfo?userName=小刘9   普通用户根据用户名查询
    },
    async getLog() {
      // let data = {
      //   key: "fileSystemSettings",
      // };
      await axios
        .get("http://192.168.19.29:6001/cloudoffice/selectDocInfo", {
          headers: {
            "Content-Type": "application/json",
            Authorization: "Bearer " + this.token,
          },
          // params: {
          //   userName: "刘liu",
          // },
        })
        .then((res) => {
          if (res.status == 200) {
            console.log(res);
            //处理文件数量返回值由字符串转换成数组
            res.data.forEach((item) => {
              item.file_name = item.file_name.split(",");
            });
            this.logList = res.data;
          }
        })
        .catch((error) => {
          console.log(error);
        });
    },
    showEcharts() {
      let myChart = echarts.init(document.getElementById("echarts"));

      // 绘制图表
      let option = {
        tooltip: {
          trigger: "item",
          formatter: "{a} <br/>{b} : {c} ({d}%)",
        },
        legend: {
          bottom: "5%",
          left: "center",
        },

        series: [
          {
            name: "容量占比",
            type: "pie",
            radius: ["40%", "70%"],
            data: [
              { value: 1048, name: "Search Engine" },
              { value: 1048, name: "Sech Engine" },
              { value: 1048, name: "Search gine" },
              { value: 1048, name: "Seargine" },
            ],
          },
        ],
      };
      option && myChart.setOption(option);
    },
    showTime(val) {
      //返回的时间转换成时间戳
      let oldVal = new Date(val).getTime() / 1000;
      // 现在的时间转换成时间戳
      let now = new Date().getTime() / 1000;
      // 查看过了多长时间
      let result = now - oldVal;
      //如果时间大于一天时间，那么就取日期
      if (result > 86400000) {
        return val;
      } else {
        let ess = this.toHHmmss(result);
        console.log(ess);
        return ess;
      }
    },
    toHHmmss(data) {
      let hours = parseInt((data % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      let minutes = parseInt((data % (1000 * 60 * 60)) / (1000 * 60));
      // var seconds = (data % (1000 * 60)) / 1000;
      let time =
        (hours == "" ? "" : hours + "小时") +
        (minutes == "" ? "" : minutes) +
        "分前";
      // (seconds < 10 ? "0" + seconds : seconds);
      return time;
    },
  },
};
</script>

<style lang="less" scoped>
.main {
  width: 100%;
  display: flex;
  justify-content: space-evenly;
  .left {
    width: 50%;
    .top {
      width: 60%;
      margin: 0 auto;
      margin-top: 20vh;
      /deep/.ant-progress-inner {
        border: 1px solid #ccc;
      }
      .totalText {
        width: 200px;
        font-size: 20px;
        font-weight: 600;
        line-height: 30px;
        margin-left: 30px;
      }
      .text {
        width: 70%;
        display: flex;
        justify-content: space-between;
        font-size: 16px;
        font-weight: 600;
        margin-top: 10px;
      }
    }
    .echarts {
      width: 70%;
      margin: 0 auto;
      margin-top: 50px;
    }
    #echarts {
      width: 30vw;
      height: 30vw;
      margin-top: -2vw;
    }
  }
  .right {
    width: 50%;
    .fileLog {
      width: 70%;
      margin: 0 auto;
      margin-top: 200px;
      .title {
        margin-bottom: 10px;
      }
      .content {
        width: 100%;
        padding: 20px;
        background: #fdfeff;
        height: 70vh;
        .log {
          border: 1px solid #e3e6e8;
          position: relative;
          border-radius: 5px;
          padding-bottom: 20px;
          border-right: 0;

          .sign {
            width: 30px;
            height: 30px;
            position: absolute;
            top: -15px;
            left: -15px;
            background: #3dbd7d;
            border-radius: 50%;
            font-size: 16px;
            font-weight: 800;
            text-align: center;
            line-height: 30px;
            color: white;
          }
          .cot {
            position: relative;
            top: -20px;
            margin-left: 30px;
            padding: 5px;
            background: #f6f9ff;
            border: 1px solid #e7f5ff;
            .title {
              height: 30px;
              display: flex;
              justify-content: space-between;
              padding: 0 20px;
              background: #eef1f7;
              color: #80889a;
              line-height: 30px;
              border-radius: 5px;
            }
            .info {
              color: #58b3ff;
              margin-left: 20px;
            }
          }
        }
      }
    }
  }
}
</style>
