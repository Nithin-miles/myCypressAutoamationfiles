//分享
<template>
  <a-modal
    :visible.sync="filesShareVisible"
    @ok="shareshandleOk"
    class="wfm-share-container"
    @cancel="sharesHandleCancel"
    :destroyOnClose="true"
  >
    <!-- <template slot="title">
    <span>外链分享{{shareData}}</span>
  </template> -->
    <template slot="footer">
      <a-button
        key="submit"
        type="primary"
        :loading="filesSharesLoading"
        @click="shareshandleOk"
      >
        保存
      </a-button>
      <a-button key="back" @click="sharesHandleCancel"> 取消分享 </a-button>
    </template>
    <!-- 外链分享表单 -->
    <div class="header">
      <div class="left">
        <a-icon type="file" class="icon" />
      </div>
      <div class="right">
        <div class="title">外链分享</div>
        <div class="local">所在位置:{{ local }}</div>
        <div class="time">分享时间:{{ time }}</div>
      </div>
    </div>
    <a-form-model
      :model="filesShareform"
      :label-col="{ span: 6 }"
      :wrapper-col="{ span: 18 }"
      ref="filesShareform"
    >
      <a-form-model-item label="开放外链分享">
        <a-switch v-model="filesShareform.delivery" />
      </a-form-model-item>
      <a-form-model-item label="分享链接">
        <a-input v-model="filesShareform.name" id="copy" :readonly="true">
          <a-button-group
            slot="suffix"
            class="search-btn"
            style="margin-right: -12px"
          >
            <a-button @click="openLink">
              <a-icon type="link" />
            </a-button>
            <a-button @click="copy">
              <a-icon type="copy" />
            </a-button>
          </a-button-group>
        </a-input>
      </a-form-model-item>
      <a-form-model-item label="提取密码">
        <a-input
          v-model="filesShareform.password"
          placeholder="为空则不设置密码"
        >
          <a-button
            slot="suffix"
            class="search-btn"
            style="margin-right: -12px"
            @click="createCode"
          >
            随机生成
          </a-button>
        </a-input>
      </a-form-model-item>
      <a-form-model-item :wrapper-col="{ span: 12, offset: 6 }">
        <a-button
          type="primary"
          @click="
            () => {
              advancedConfiguration = !advancedConfiguration;
            }
          "
        >
          高级配置
        </a-button>
      </a-form-model-item>
      <!-- 高级配置项 -->
      <div v-if="advancedConfiguration">
        <a-form-model-item label="分享标题">
          <a-input v-model="filesShareform.title" placeholder="输入标题" />
        </a-form-model-item>
        <a-form-model-item label="仅登录用户可用">
          <a-switch v-model="filesShareform.uesful" />
        </a-form-model-item>
        <a-form-model-item label="到期时间">
          <a-switch v-model="filesShareform.time" />
        </a-form-model-item>
        <a-form-model-item label="设置到期时间" v-if="filesShareform.time">
          <a-date-picker
            v-model="filesShareform.date1"
            format="YYYY-MM-DD HH:mm:ss"
            :show-time="{ defaultValue: moment('00:00:00', 'HH:mm:ss') }"
            type="date"
            placeholder="请选择时间"
            :disabled-date="disabledDate"
            :disabled-time="disabledDateTime"
            @change="onChangeTime"
          />
          <!-- <a-date-picker
                v-model="filesShareform.date1"
                placeholder="请选择时间"
                format="YYYY-MM-DD HH:mm:ss"
            /> -->
        </a-form-model-item>
      </div>
      <!-- 高级配置项 -->
    </a-form-model>
    <!-- 外链分享表单 -->
  </a-modal>
  <!-- <div class="wfm-share-container">
    分享
  </div> -->
</template>

<script>
import * as moment from "moment";
import Base64 from "base-64";
import axios from "axios";
import Vue from "vue";
Vue.prototype.$axios = axios;
import { token,localHttp,HttpServe } from "./httpAndTokenServe";

export default {
  name: "share-file",
  props: {
    filesShareVisible: Boolean,
    shareData: Array,
    // shareData:{
    //    type: Array,
    //    default: []
    //   },
  },
  data() {
    return {
      filesSharesLoading: false, //分享确定按钮loading
      //filesShareVisible: false, //分享弹框是否显示true
      //位置
      local: "",
      time: "",
      filesShareform: {
        delivery: true, //开放分享
        name: "", //链接
        password: "", //提取码
        title: "", //分享标题
        uesful: false, //仅用户可登录
        time: false, //开启到期时间
        date1: "", //到期时间
      },
      advancedConfiguration: false, //高级配置按钮
      id: "", //生成外链ID
      token,//取到token值
      localHttp,//本地ip
      HttpServe,//请求IP
    };
  },
  watch: {
    filesShareVisible: {
      handler(newName, oldName) {
        console.log(newName, oldName, 22);
        if (newName == true) {
          this.init();
        }
      },
      immediate: true,
    },
  },
  methods: {
    init() {
      console.log(this.shareData);
      this.getLink(); //点击文件生成外链链接
      // console.log(this.shareData[0].filePath);
      this.local = this.shareData[0].filePath;
      this.time = this.shareData[0].updateDate;
    },
    //生成链接
    getLink() {
      let data = {
        fileVirtualInfoId: "",
        fileVirtualFolderInfoId: "",
        baseUrl: this.localHttp+"/link?path=",
      };

      let fileVirtualInfoIdStr = [];
      let fileVirtualFolderInfoIdStr = [];
      this.shareData.forEach((item) => {
        if (item.isFolder == 0) {
          fileVirtualInfoIdStr.push(item.id);
        } else {
          fileVirtualFolderInfoIdStr.push(item.id);
        }
      });
      data.fileVirtualInfoId = fileVirtualInfoIdStr.join(",");
      data.fileVirtualFolderInfoId = fileVirtualFolderInfoIdStr.join(",");

      axios
        .post(
          this.HttpServe+"/cloudoffice/fileOutsideChain/createFileOutsideChain",
          data,
          {
            headers: {
              "Content-Type": "application/json",
              Authorization: "Bearer " + this.token,
            },
          }
        )
        .then((res) => {
          if (res.data.code == 200) {
            // res.data.data.
            this.filesShareform.name = res.data.data.shareLink;
            this.id = res.data.data.id;
          }
        })
        .catch((error) => {
          console.log(error);
        });
    },
    //保存分享设置
    shareshandleOk(e) {
      //打开加载
      this.filesSharesLoading = true;
      let data = {
        id: this.id,
        isShare: this.filesShareform.delivery ? 1 : 0,
        extractPassword: Base64.encode(this.filesShareform.password),
        shareTitle: this.filesShareform.title,
        isLogin: this.filesShareform.uesful ? 1 : 0,
        expirationTime: this.filesShareform.date1,
      };
      axios
        .put(
          this.HttpServe+"/cloudoffice/fileOutsideChain/updateFileOutsideChain",
          data,
          {
            headers: {
              "Content-Type": "application/json",
              Authorization: "Bearer " + this.token,
            },
          }
        )
        .then((res) => {
          if (res.data.code == 200) {
            this.$message.success("保存成功");
            this.filesSharesLoading = false;
            this.$emit("update:filesShareVisible", false);
          }
        })
        .catch((error) => {
          this.$message.warning(error);
        });
      // console.log(Base64.encode(this.filesShareform.password)); //加密
      // console.log(Base64.decode(Base64.encode(this.filesShareform.password))); //解密
    },
    sharesHandleCancel(e) {
      this.$emit("update:filesShareVisible", false);
      // this.$refs.filesShareform.resetFields();
      this.filesShareform = {
        name: "",
        delivery: true,
        password: "",
        title: "",
        uesful: false,
        time: false,
        date1: undefined,
      };
      this.advancedConfiguration = false;
    },
    onSubmit() {
      console.log("submit!");
    },
    // 到期时间
    moment,
    range(start, end) {
      const result = [];
      for (let i = start; i < end; i++) {
        result.push(i);
      }
      return result;
    },

    disabledDate(current) {
      // Can not select days before today and today
      return current && current < moment().endOf("day");
    },

    disabledDateTime() {
      // Can not select time before this moment
      return {
        disabledHours: () => this.range(0, 24).splice(4, 20),
        disabledMinutes: () => this.range(30, 60),
        disabledSeconds: () => [55, 56],
      };
    },
    //点击复制链接
    copy() {
      var e = document.getElementById("copy"); //对象是content
      if (e.value != "") {
        e.select(); //选择对象
        document.execCommand("Copy"); //执行浏览器复制命令
        this.$message.success("复制成功");
      } else {
      }
    },

    //随机生成四位验证码
    createCode() {
      // 所需随机抽取的样本数组
      let nums = new Array(
        "q",
        "w",
        "e",
        "r",
        "t",
        "y",
        "u",
        "i",
        "o",
        "p",
        "a",
        "s",
        "d",
        "f",
        "g",
        "h",
        "j",
        "k",
        "l",
        "z",
        "x",
        "c",
        "v",
        "b",
        "n",
        "m",
        "A",
        "W",
        "E",
        "R",
        "T",
        "Y",
        "U",
        "I",
        "O",
        "P",
        "A",
        "S",
        "D",
        "F",
        "G",
        "H",
        "J",
        "K",
        "L",
        "Z",
        "X",
        "C",
        "V",
        "B",
        "N",
        "M",
        "0",
        "1",
        "2",
        "3",
        "4",
        "5",
        "6",
        "7",
        "8",
        "9"
      );
      // 初始化 拼接字符串
      let str = "";
      for (let i = 0; i < 4; i++) {
        //每次生成一个0 - 61 之间的 number 作为随机获取验证码的下标
        let p = Math.floor(Math.random() * 1000) % 62;
        //拼接验证码  随机抽取大小写字母和数字
        str += nums[p];
      }
      this.filesShareform.password = str;
    },
    onChangeTime(date, dateString) {
      console.log(date, dateString);
      this.filesShareform.date1 = dateString;
    },
    //打开链接
    openLink() {
      console.log(this.filesShareform.name.split("/link?path=/")[1]);
      let path = this.filesShareform.name.split("/link?path=")[1];
      this.$router.push("/link?path=" + path);
    },
  },
};
</script>

<style lang="less" scoped>
.header {
  display: flex;
  height: 120px;
  border-bottom: 1px solid #ccc;
  margin-bottom: 20px;
  .left {
    width: 20%;
    // border: 1px solid red;
    .icon {
      display: block;
      font-size: 60px;
      margin: 0 auto;
      line-height: 120px;
    }
  }
  .right {
    padding-left: 10px;
    .title {
      font-size: 20px;
      font-weight: 600;
      margin-top: 10px;
    }
    .local,
    .time {
      margin-top: 5px;
    }
  }
}
</style>
