<template>
  <div class="main">
    <!-- <a-modal
      title="个人空间"
      :visible="showPersonVisible"
      :confirm-loading="confirmLoading"
      @cancel="handleCancel"
      :width="600"
    >
      <div class="content">
        <a-directory-tree
          multiple
          default-expand-all
          @select="onSelect"
          @expand="onExpand"
        >
          <template v-for="item in fileList1">
            <a-tree-node :key="item.id" :title="item.fileName">
              <template v-if="item.children">
                <template v-for="e in item.children">
                  <a-tree-node :key="e.id" :title="e.fileName" />
                </template>
              </template>
            </a-tree-node>
          </template>
        </a-directory-tree>
      </div>
      <template slot="footer">
        <a-button key="back" @click="handleCancel"> 取消 </a-button>
        <a-button type="primary" key="submit" @click="sure"> 确定 </a-button>
      </template>
    </a-modal> -->
    <a-modal
      class="copy"
      title="保存到"
      :visible="showPersonVisible"
      v-if="showPersonVisible"
      @ok="copyHandleOk"
      @cancel="copyHandleCancel"
    >
      <template slot="footer">
        <a-button key="submit" type="primary" :loading="saveLoading" @click="copyHandleOk">
          确定
        </a-button>
        <a-button key="back" @click="copyHandleCancel"> 取消 </a-button>
      </template>

      <a-tree
        :load-data="onLoadData"
        :defaultExpandParent="false"
        :selected-keys="selectedKeys"
        :tree-data="findSpace"
        @expand="onExpand"
        @select="onSelect"
      />
    </a-modal>
  </div>
</template>

<script>
import Base64 from "base-64";
import axios from "axios";
import Vue from "vue";
Vue.prototype.$axios = axios;
import { token, HttpServe } from "./httpAndTokenServe";
export default {
  props: {
    showPersonVisible: Boolean,
    passWord: String,
    ID: String,
    checkList: Array,
  },
  data() {
    return {
      confirmLoading: false, //加载按钮
      fileList: [],
      fileList1: [],
      chooseFileId: "",
      token,
      HttpServe,

      // showPersonVisible: false,
      //复制路径
      findSpace: [{ title: "个人空间", key: "0", children: [] }],
      saveLoading:false,//保存加载图标
      selectedKeys: [],
      arrarr: [],
      chooseCopyRoute: "",
    };
  },
  /* watch: {
    showPersonVisible: {
      handler(newName, oldName) {
        console.log(newName, oldName, 22);
        if (newName) {
          setTimeout(() => {
            console.log(this.fileList);
            this.fileList1 = this.fileList;
          }, 2000);
        }
      },
      immediate: true,
    }, */
  // },
  created() {
    // this.getList();
    this.findCopyShowModalInfo("-1"); //初始化文件树
  },
  methods: {
    /* getList() {
      let data = {
        parentId: "-1",
        spaceType: "0",
        order: "update_date desc",
      };
      axios
        .post(
          this.HttpServe+"/cloudoffice/fileVirtualFolderInfo/selectAllSpace",
          data,
          {
            headers: {
              "Content-Type": "application/json",
              Authorization: "Bearer " + this.token,
            },
          }
        )
        .then((res) => {
          // console.log(res, "567");
          let List = res.data.data;
          List.forEach((item, index) => {
            if (item.isFolder == 1) {
              this.getChildrenList(item.id, index, List);
            }
          });
        })
        .catch((error) => {
          console.log(error);
        });
    },
    getChildrenList(e, keys, arr) {
      let data = {
        parentId: e,
        spaceType: "0",
      };
      axios
        .post(
          this.HttpServe+"/cloudoffice/fileVirtualFolderInfo/selectAllSpace",
          data,
          {
            headers: {
              "Content-Type": "application/json",
              Authorization: "Bearer " + this.token,
            },
          }
        )
        .then((res) => {
          // console.log(res, "789");
          if (res.data.data.length != 0) {
            arr[keys].children = res.data.data;
          }
          this.fileList = arr;
          // console.log(this.fileList);
        })
        .catch((error) => {
          console.log(error);
        });
    }, */

    /* handleCancel() {
      this.$emit("update:showPersonVisible", false);
    },
    
    onExpand() {
      console.log("Trigger Expand");
    },
    sure() {
      console.log(this.fileList);
      this.saveMine();
    }, */

    /* onSelect(keys, event) {
      console.log("Trigger Select", keys, event);
      this.chooseFileId = keys[0];
    }, */
    //查询个人空间
    findCopyShowModalInfo(e) {
      let data = {
        parentId: e ? e : "-1",
        spaceType: 0,
        isFolder: 1,
      };
      axios
        .post(
          this.HttpServe + "/cloudoffice/fileVirtualFolderInfo/selectAllSpace",
          data,
          {
            headers: {
              "Content-Type": "application/json",
              Authorization: "Bearer " + this.token,
            },
          }
        )
        .then((res) => {
          console.log(res);
          if (res.data.code == 200) {
            if (e == "-1") {
              this.findSpace[0].children = this.treeArry(res.data.data);
            } else {
              this.arrarr = this.treeArry(res.data.data);
            }
          }
        })
        .catch((error) => {
          console.log(error);
        });
    },
    treeArry(arr) {
      let returnArr = [];
      arr.forEach((item) => {
        console.log(item.isFolder);
        returnArr.push({
          title: item.fileName,
          key: item.id,
        });
      });
      return returnArr;
    },
    handleCancel(e) {
      this.visible = false;
    },

    //树型控件懒加载
    onLoadData(treeNode) {
      return new Promise((resolve) => {
        if (treeNode.dataRef.children) {
          resolve();
          return;
        }
        setTimeout(() => {
          treeNode.dataRef.children = this.arrarr;
          this.findSpace = [...this.findSpace];
          resolve();
        }, 1500);
      });
    },
    onSelect(keys, event) {
      console.log("Trigger Select", keys, event);
      this.chooseCopyRoute = keys[0];
    },
    onExpand(expandedKeys) {
      console.log("Trigger Expand", expandedKeys);
      function deepClone(obj) {
        let newObj = Array.isArray(obj) ? [] : {};
        if (obj && typeof obj === "object") {
          for (let key in obj) {
            if (obj.hasOwnProperty(key)) {
              newObj[key] =
                obj && typeof obj[key] === "object"
                  ? deepClone(obj[key])
                  : obj[key];
            }
          }
        }
        return newObj;
      }
      if (expandedKeys.length > 1) {
        console.log(expandedKeys);
        let aaa = deepClone(expandedKeys);
        // let aaa = expandedKeys;
        aaa.splice(0, aaa.length - 1);
        console.log(aaa);
        this.findCopyShowModalInfo(aaa[0]);
      }
    },
    //弹框点击确定按钮
    copyHandleOk(e) {
      this.saveLoading = true;
      this.saveMine();
    },

    saveMine() {
      let fileVirtualInfoVOList = [];
      let fileVirtualFolderInfoVOList = [];
      this.checkList.forEach((item) => {
        if (item.isFolder == 0) {
          fileVirtualInfoVOList.push({
            id: item.id,
          });
        } else {
          fileVirtualFolderInfoVOList.push({
            id: item.id,
          });
        }
      });
      let data = {
        fileOutsideChainVO: {
          id: this.ID,
          extractPassword: Base64.encode(this.passWord),
        },
        fileVirtualInfoVOList: fileVirtualInfoVOList,
        fileVirtualFolderInfoVOList: fileVirtualFolderInfoVOList,
        targetFileVirtualFolderId: this.chooseCopyRoute,
      };
      axios
        .post(
          this.HttpServe + "/cloudoffice/fileOutsideChain/share/saveFiles",
          data,
          {
            headers: {
              "Content-Type": "application/json",
              Authorization: "Bearer " + this.token,
            },
          }
        )
        .then((res) => {
          console.log(res);
          if (res.data.code == 200) {
            this.$message.success("保存成功！！！");
            this.$emit("update:showPersonVisible", false);//关闭保存弹框
          }
        })
        .catch((error) => {
          console.log(error);
        });
    },

    copyHandleCancel(e) {
      console.log("Clicked cancel button");
      this.$emit("update:showPersonVisible", false);
    },
  },
};
</script>

<style lang="less" scoped>
/deep/.ant-modal-body {
  height: 50vh;
  overflow-y: scroll;
  overflow-x: hidden;
}
</style>
