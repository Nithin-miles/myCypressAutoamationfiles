<template>
  <div class="main">
    <link-login
      v-if="showLink"
      :urlPath="urlPath"
      @showLogin="showLogin"
    ></link-login>
    <div class="linkMain" v-if="showList">
      <div class="top">
        <div class="btn">
          <a-button class="btn1" type="primary" @click="save">
            保存到我的空间
          </a-button>
          <a-button class="btn1" type="primary" @click="download">
            下载
          </a-button>
          <a-button class="btn1" type="primary" @click="open"> 打开 </a-button>
          <a-button class="btn1" type="primary" @click="attributes">
            属性
          </a-button>
        </div>
        <div class="search">
          <a-input-search
            v-model="searchName"
            placeholder="输入文件名称进行搜索"
            style="width: 300px"
            @change="onSearchName"
          ></a-input-search>
        </div>
      </div>
      <div class="content">
        <a-layout-header class="breadcrumb">
          <a-row>
            <a-col
              :span="19"
              :xxl="18"
              :xl="18"
              :lg="16"
              :md="15"
              class="breadcrumb_left"
            >
              <a-button type="link" @click="back">
                <a-icon type="undo" />
                <span class="visible-lg-inline">返回上一层</span>
              </a-button>
              <a-button type="link" @click="upData">
                <a-icon type="sync" />
                <span class="visible-lg-inline">刷新</span>
              </a-button>
              <a-divider type="vertical" />
              <a-breadcrumb separator=">">
                <a-breadcrumb-item>Home</a-breadcrumb-item>
                <a-breadcrumb-item href="">
                  Application Center
                </a-breadcrumb-item>
                <a-breadcrumb-item href="">
                  Application List
                </a-breadcrumb-item>
                <a-breadcrumb-item>An Application</a-breadcrumb-item>
              </a-breadcrumb>
            </a-col>
            <a-col
              :span="4"
              :xxl="6"
              :xl="6"
              :lg="8"
              :md="9"
              class="breadcrumb_right"
            >
              <!-- <a-dropdown :trigger="['click']" :placement="'bottomCenter'">
                <a class="ant-dropdown-link" @click="(e) => e.preventDefault()">
                  <a-button type="link">
                    <a-icon type="ordered-list" />
                  </a-button>
                </a>
                <a-menu slot="overlay">
                  <a-menu-item>
                    <a href="javascript:;">名称</a>
                  </a-menu-item>
                  <a-menu-item>
                    <a href="javascript:;">修改时间</a>
                  </a-menu-item>
                  <a-menu-item>
                    <a href="javascript:;">类型</a>
                  </a-menu-item>
                  <a-menu-item>
                    <a href="javascript:;">大小</a>
                  </a-menu-item>
                </a-menu>
              </a-dropdown> -->
              <a-radio-group
                v-model="mode"
                :style="{ marginBottom: '8px' }"
                button-style="solid"
                @change="handleSizeChange"
              >
                <a-radio-button value="table">
                  <a-icon type="bars" />
                </a-radio-button>
                <a-radio-button value="list">
                  <a-icon type="appstore" />
                </a-radio-button>
              </a-radio-group>
            </a-col>
          </a-row>
        </a-layout-header>
        <div class="file-table" v-if="mode == 'table'">
          <!-- :scroll="{ y: tableHeight } -->
          <a-table
            align="left"
            class="tableBoxComponents"
            :columns="FileListColumns"
            :data-source="fileListFilter"
            :pagination="false"
            :scroll="{ y: 700 }"
            row-key="id"
            :row-selection="{
              onSelectAll: onSelectAll,
              onSelect: onSelect,
              onChange: onChange,
            }"
            :expanded-row-keys.sync="expandedRowKeys"
          >
            <template slot="fileName" slot-scope="text, record">
              <div
                style="
                  display: flex;
                  align-items: baseline;
                  justify-content: space-between;
                "
              >
                <span>
                  <a-icon :type="record.type" />
                  <svg
                    class="icon"
                    aria-hidden="true"
                    style="vertical-align: middle"
                  >
                    <use :xlink:href="'#icon-' + record.type"></use>
                  </svg>
                  <span v-if="record.fileType == 'folder'">
                    <a style="cursor: pointer">
                      <img
                        src="../../../assets/fileIcon/icon-big-folder.png"
                        style="max-width: 30px"
                      />
                      <span>{{ record.fileName }}</span>
                    </a>
                  </span>

                  <span
                    v-else-if="
                      record.fileType == 'jpg' ||
                      record.fileType == 'png' ||
                      record.fileType == 'jpeg' ||
                      record.fileType == 'gif' ||
                      record.fileType == 'bmp' ||
                      record.fileType == 'dxf' ||
                      record.fileType == 'bip'
                    "
                  >
                    <a style="cursor: pointer">
                      <img
                        src="../../../assets/fileIcon/tupian.png"
                        style="max-width: 30px"
                      />
                      <span>{{ record.fileName }}</span>
                    </a>
                  </span>
                  <span
                    v-else-if="
                      record.fileType == 'zip' || record.fileType == 'rar'
                    "
                  >
                    <a style="cursor: pointer">
                      <img
                        src="../../../assets/fileIcon/zipRar.png"
                        style="max-width: 30px"
                      />
                      <span>{{ record.fileName }}</span>
                    </a>
                  </span>
                  <span
                    v-else-if="
                      record.fileType == 'cda' ||
                      record.fileType == 'wav' ||
                      record.fileType == 'aif' ||
                      record.fileType == 'au' ||
                      record.fileType == 'mp3' ||
                      record.fileType == 'wma' ||
                      record.fileType == 'mmf' ||
                      record.fileType == 'amr' ||
                      record.fileType == 'aac' ||
                      record.fileType == 'flac'
                    "
                  >
                    <a style="cursor: pointer">
                      <img
                        src="../../../assets/fileIcon/yinpin.png"
                        style="max-width: 30px"
                      />
                      <span>{{ record.fileName }}</span>
                    </a>
                  </span>
                  <span
                    v-else-if="
                      record.fileType == 'avi' ||
                      record.fileType == 'wmv' ||
                      record.fileType == 'mpg' ||
                      record.fileType == 'mov' ||
                      record.fileType == 'rm' ||
                      record.fileType == 'ram' ||
                      record.fileType == 'swf' ||
                      record.fileType == 'flv' ||
                      record.fileType == 'mp4'
                    "
                  >
                    <a style="cursor: pointer">
                      <img
                        src="../../../assets/fileIcon/shipin.png"
                        style="max-width: 30px"
                      />
                      <span>{{ record.fileName }}</span>
                    </a>
                  </span>
                  <span
                    v-else-if="
                      record.fileType == 'docx' || record.fileType == 'doc'
                    "
                  >
                    <a style="cursor: pointer">
                      <img
                        src="../../../assets/fileIcon/word.png"
                        style="max-width: 30px"
                      />
                      <span>{{ record.fileName }}</span>
                    </a>
                  </span>
                  <span
                    v-else-if="
                      record.fileType == 'xlsx' || record.fileType == 'xls'
                    "
                  >
                    <a style="cursor: pointer">
                      <img
                        src="../../../assets/fileIcon/xlsx.png"
                        style="max-width: 30px"
                      />
                      <span>{{ record.fileName }}</span>
                    </a>
                  </span>
                  <span
                    v-else-if="
                      record.fileType == 'ppt' || record.fileType == 'pptx'
                    "
                  >
                    <a style="cursor: pointer">
                      <img
                        src="../../../assets/fileIcon/ppt.png"
                        style="max-width: 30px"
                      />
                      <span>{{ record.fileName }}</span>
                    </a>
                  </span>
                  <span v-else-if="record.fileType == 'pdf'">
                    <a style="cursor: pointer">
                      <img
                        src="../../../assets/fileIcon/pdf.png"
                        style="max-width: 30px"
                      />
                      <span>{{ record.fileName }}</span>
                    </a>
                  </span>
                  <span v-else-if="record.fileType == 'txt'">
                    <a style="cursor: pointer">
                      <img
                        src="../../../assets/fileIcon/txt.png"
                        style="max-width: 30px"
                      />
                      <span>{{ record.fileName }}</span>
                    </a>
                  </span>
                  <span v-else-if="record.fileType == 'txt'">
                    <a style="cursor: pointer">
                      <img
                        src="../../../assets/fileIcon/txt.png"
                        style="max-width: 30px"
                      />
                      <span>{{ record.fileName }}</span>
                    </a>
                  </span>
                  <span v-else-if="record.fileType == 'csv'">
                    <a style="cursor: pointer">
                      <img
                        src="../../../assets/fileIcon/csv.png"
                        style="max-width: 30px"
                      />
                      <span>{{ record.fileName }}</span>
                    </a>
                  </span>
                  <span
                    v-else-if="
                      record.fileType == 'mdb' ||
                      record.fileType == 'dbf' ||
                      record.fileType == 'mdf' ||
                      record.fileType == 'db' ||
                      record.fileType == 'wdb'
                    "
                  >
                    <a style="cursor: pointer">
                      <img
                        src="../../../assets/fileIcon/shujvku.png"
                        style="max-width: 30px"
                      />
                      <span>{{ record.fileName }}</span>
                    </a>
                  </span>
                  <span
                    v-else-if="
                      record.fileType == 'shp' ||
                      record.fileType == 'shx' ||
                      record.fileType == 'dbf' ||
                      record.fileType == 'prj' ||
                      record.fileType == 'sbn' ||
                      record.fileType == 'sbx' ||
                      record.fileType == 'sbn' ||
                      record.fileType == 'fbn' ||
                      record.fileType == 'fbx' ||
                      record.fileType == 'ain' ||
                      record.fileType == 'ixs' ||
                      record.fileType == 'mxs' ||
                      record.fileType == 'atx' ||
                      record.fileType == 'cpg'
                    "
                  >
                    <a style="cursor: pointer">
                      <img
                        src="../../../assets/fileIcon/shapefile.png"
                        style="max-width: 30px"
                      />
                      <span>{{ record.fileName }}</span>
                    </a>
                  </span>

                  <span v-else-if="record.fileType == 'sde'">
                    <a style="cursor: pointer">
                      <img
                        src="../../../assets/fileIcon/kongjianshujv.png"
                        style="max-width: 30px"
                      />
                      <span>{{ record.fileName }}</span>
                    </a>
                  </span>
                  <span v-else-if="record.fileType == 'tif'">
                    <a style="cursor: pointer">
                      <img
                        src="../../../assets/fileIcon/tuxiandili.png"
                        style="max-width: 30px"
                      />
                      <span>{{ record.fileName }}</span>
                    </a>
                  </span>
                  <span v-else-if="record.fileType == 'img'">
                    <a style="cursor: pointer">
                      <img
                        src="../../../assets/fileIcon/img.png"
                        style="max-width: 30px"
                      />
                      <span>{{ record.fileName }}</span>
                    </a>
                  </span>
                  <span v-else-if="record.fileType == 'mxd'">
                    <a style="cursor: pointer">
                      <img
                        src="../../../assets/fileIcon/mxd.png"
                        style="max-width: 30px"
                      />
                      <span>{{ record.fileName }}</span>
                    </a>
                  </span>

                  <span v-else>
                    <a style="cursor: pointer">
                      <img
                        src="../../../assets/fileIcon/qita.png"
                        style="max-width: 30px"
                      />
                      <span>{{ record.fileName }}</span>
                    </a>
                  </span>
                </span>
              </div>
            </template>
            <template slot="fileStorage" slot-scope="text">
              <span> {{ text | KBDate(text) }} </span>
            </template>
          </a-table>
        </div>
        <div v-if="mode == 'list'">
          <template v-for="(item, index) in fileListFilter">
            <a-checkbox-group @change="onChangeCheckBox" :key="index">
              <div class="file">
                <div class="img">
                  <!-- <img
                    src="../../../../src/assets/icon-big-folder.png"
                    alt=""
                  /> -->

                  <span v-if="item.fileType == 'folder'">
                    <a style="cursor: pointer">
                      <img
                        src="../../../assets/fileIcon/icon-big-folder.png"
                        style="max-width: 60px"
                      />
                    </a>
                  </span>

                  <span
                    v-else-if="
                      item.fileType == 'jpg' ||
                      item.fileType == 'png' ||
                      item.fileType == 'jpeg' ||
                      item.fileType == 'gif' ||
                      item.fileType == 'bmp' ||
                      item.fileType == 'dxf' ||
                      item.fileType == 'bip'
                    "
                  >
                    <a style="cursor: pointer">
                      <img
                        src="../../../assets/fileIcon/tupian.png"
                        style="max-width: 60px"
                      />
                    </a>
                  </span>
                  <span
                    v-else-if="item.fileType == 'zip' || item.fileType == 'rar'"
                  >
                    <a style="cursor: pointer">
                      <img
                        src="../../../assets/fileIcon/zipRar.png"
                        style="max-width: 60px"
                      />
                    </a>
                  </span>
                  <span
                    v-else-if="
                      item.fileType == 'cda' ||
                      item.fileType == 'wav' ||
                      item.fileType == 'aif' ||
                      item.fileType == 'au' ||
                      item.fileType == 'mp3' ||
                      item.fileType == 'wma' ||
                      item.fileType == 'mmf' ||
                      item.fileType == 'amr' ||
                      item.fileType == 'aac' ||
                      item.fileType == 'flac'
                    "
                  >
                    <a style="cursor: pointer">
                      <img
                        src="../../../assets/fileIcon/yinpin.png"
                        style="max-width: 60px"
                      />
                    </a>
                  </span>
                  <span
                    v-else-if="
                      item.fileType == 'avi' ||
                      item.fileType == 'wmv' ||
                      item.fileType == 'mpg' ||
                      item.fileType == 'mov' ||
                      item.fileType == 'rm' ||
                      item.fileType == 'ram' ||
                      item.fileType == 'swf' ||
                      item.fileType == 'flv' ||
                      item.fileType == 'mp4'
                    "
                  >
                    <a style="cursor: pointer">
                      <img
                        src="../../../assets/fileIcon/shipin.png"
                        style="max-width: 60px"
                      />
                    </a>
                  </span>
                  <span
                    v-else-if="
                      item.fileType == 'docx' || item.fileType == 'doc'
                    "
                  >
                    <a style="cursor: pointer">
                      <img
                        src="../../../assets/fileIcon/word.png"
                        style="max-width: 60px"
                      />
                    </a>
                  </span>
                  <span
                    v-else-if="
                      item.fileType == 'xlsx' || item.fileType == 'xls'
                    "
                  >
                    <a style="cursor: pointer">
                      <img
                        src="../../../assets/fileIcon/xlsx.png"
                        style="max-width: 60px"
                      />
                    </a>
                  </span>
                  <span
                    v-else-if="
                      item.fileType == 'ppt' || item.fileType == 'pptx'
                    "
                  >
                    <a style="cursor: pointer">
                      <img
                        src="../../../assets/fileIcon/ppt.png"
                        style="max-width: 60px"
                      />
                    </a>
                  </span>
                  <span v-else-if="item.fileType == 'pdf'">
                    <a style="cursor: pointer">
                      <img
                        src="../../../assets/fileIcon/pdf.png"
                        style="max-width: 60px"
                      />
                    </a>
                  </span>
                  <span v-else-if="item.fileType == 'txt'">
                    <a style="cursor: pointer">
                      <img
                        src="../../../assets/fileIcon/txt.png"
                        style="max-width: 60px"
                      />
                    </a>
                  </span>
                  <span v-else-if="item.fileType == 'txt'">
                    <a style="cursor: pointer">
                      <img
                        src="../../../assets/fileIcon/txt.png"
                        style="max-width: 60px"
                      />
                    </a>
                  </span>
                  <span v-else-if="item.fileType == 'csv'">
                    <a style="cursor: pointer">
                      <img
                        src="../../../assets/fileIcon/csv.png"
                        style="max-width: 60px"
                      />
                    </a>
                  </span>
                  <span
                    v-else-if="
                      item.fileType == 'mdb' ||
                      item.fileType == 'dbf' ||
                      item.fileType == 'mdf' ||
                      item.fileType == 'db' ||
                      item.fileType == 'wdb'
                    "
                  >
                    <a style="cursor: pointer">
                      <img
                        src="../../../assets/fileIcon/shujvku.png"
                        style="max-width: 60px"
                      />
                    </a>
                  </span>
                  <span
                    v-else-if="
                      item.fileType == 'shp' ||
                      item.fileType == 'shx' ||
                      item.fileType == 'dbf' ||
                      item.fileType == 'prj' ||
                      item.fileType == 'sbn' ||
                      item.fileType == 'sbx' ||
                      item.fileType == 'sbn' ||
                      item.fileType == 'fbn' ||
                      item.fileType == 'fbx' ||
                      item.fileType == 'ain' ||
                      item.fileType == 'ixs' ||
                      item.fileType == 'mxs' ||
                      item.fileType == 'atx' ||
                      item.fileType == 'cpg'
                    "
                  >
                    <a style="cursor: pointer">
                      <img
                        src="../../../assets/fileIcon/shapefile.png"
                        style="max-width: 60px"
                      />
                    </a>
                  </span>

                  <span v-else-if="item.fileType == 'sde'">
                    <a style="cursor: pointer">
                      <img
                        src="../../../assets/fileIcon/kongjianshujv.png"
                        style="max-width: 60px"
                      />
                    </a>
                  </span>
                  <span v-else-if="item.fileType == 'tif'">
                    <a style="cursor: pointer">
                      <img
                        src="../../../assets/fileIcon/tuxiandili.png"
                        style="max-width: 60px"
                      />
                    </a>
                  </span>
                  <span v-else-if="item.fileType == 'img'">
                    <a style="cursor: pointer">
                      <img
                        src="../../../assets/fileIcon/img.png"
                        style="max-width: 60px"
                      />
                    </a>
                  </span>
                  <span v-else-if="item.fileType == 'mxd'">
                    <a style="cursor: pointer">
                      <img
                        src="../../../assets/fileIcon/mxd.png"
                        style="max-width: 60px"
                      />
                    </a>
                  </span>

                  <span v-else>
                    <a style="cursor: pointer">
                      <img
                        src="../../../assets/fileIcon/qita.png"
                        style="max-width: 60px"
                      />
                    </a>
                  </span>
                </div>
                <a-checkbox class="checkBox" :value="item" />
                <div class="text">{{ item.fileName }}</div>
              </div>
            </a-checkbox-group>
          </template>
        </div>

        <!-- <div class="rightContent">
          <div class="top">
            <div class="name">{{ form.createUser }}的分享</div>
          </div>
          <div class="info">
            <a-form :label-col="{ span: 7 }" :wrapper-col="{ span: 12 }">
              <a-form-item label="标题"> {{ form.title }} </a-form-item>
              <a-form-item label="创建时间">
                {{ form.createDate }}
              </a-form-item>
              <a-form-item label="创建人"> {{ form.createUser }} </a-form-item>
            </a-form>
          </div>
        </div> -->
      </div>
    </div>

    <!-- 属性弹框 -->
    <a-modal
      title="属性"
      :visible="visible"
      @cancel="handleCancel"
      :width="600"
    >
      <div class="ModalContent">
        <a-form-model
          :model="fileAttributesForm"
          :label-col="{ span: 4 }"
          :wrapper-col="{ span: 14 }"
        >
          <div class="img">
            <img src="../../../../src/assets/icon-big-folder.png" alt="" />
            {{ fileAttributesForm.fileName }}
          </div>
          <a-form-model-item label="类型">
            {{ fileAttributesForm.fileType == 0 ? "文件" : "文件夹" }}
          </a-form-model-item>
          <a-form-model-item label="路径">
            {{ fileAttributesForm.filePath }}
          </a-form-model-item>
          <a-form-model-item label="大小">
            {{
              fileAttributesForm.fileSize | KBDate(fileAttributesForm.fileSize)
            }}
          </a-form-model-item>
          <a-form-model-item
            label="包含"
            v-if="fileAttributesForm.fileType == 1"
          >
            {{ fileAttributesForm.fileIncludes }}
          </a-form-model-item>
          <a-form-model-item label="创建时间">
            {{ fileAttributesForm.createTime }}
          </a-form-model-item>
          <a-form-model-item label="修改时间">
            {{ fileAttributesForm.alterTime }}
          </a-form-model-item>
        </a-form-model>
      </div>
      <template slot="footer">
        <a-button key="back" @click="handleCancel"> 关闭 </a-button>
      </template>
    </a-modal>
    <!-- 保存到我的空间弹框 -->
    <div v-if="showPersonVisible">
      <personal-space
        :showPersonVisible.sync="showPersonVisible"
        :passWord="passWord"
        :ID="ID"
        :checkList="checkList"
      ></personal-space>
    </div>
  </div>
</template>

<script>
import Base64 from "base-64";
import axios from "axios";
import Vue from "vue";
Vue.prototype.$axios = axios;
import linkLogin from "./linkLogin.vue";
import { FileListColumns } from "./table.js";
import personalSpace from "./personalSpace.vue";
import { token, HttpServe } from "./httpAndTokenServe";
export default {
  data() {
    return {
      urlPath: "", //链接地址
      passWord: "",
      showLink: "", //是否展示提取密码弹框
      showList: "",
      form: {
        title: "",
        createDate: "",
        createUser: "",
      },
      ID: "", //外链ID
      fileId: "", //当前文件夹ID
      fileList: [], //外链分享文件列表
      fileListFilter: [], //搜索后的文件列表
      searchName: "", //搜索框输入
      mode: "table", //表格与图片列表切换
      FileListColumns: FileListColumns,
      expandedRowKeys: [],
      checkList: [], //选中的表格
      openId: "", //打开文件的ID

      visible: false, //属性弹框开启关闭
      showPersonVisible: false, //控制保存到我的空间弹框开启关闭
      //文件属性渲染内容
      fileAttributesForm: {
        fileName: "",
        fileType: "", //1文件夹 0 文件
        filePath: "",
        fileSize: "",
        fileIncludes: "",
        createTime: "",
        alterTime: "",
      },
      token,
      HttpServe,
    };
  },
  components: {
    linkLogin,
    personalSpace,
  },
  mounted() {
    this.init();
    setTimeout(() => {
      this.getList();
    }, 1000);
  },
  watch: {
    showLink: {
      handler(newName, oldName) {
        console.log(newName, oldName, 22);
        if (newName == false) {
          this.init();
        }
      },
      immediate: true,
    },
  },
  methods: {
    init() {
      this.urlPath = window.location.href.split("path=")[1];
      this.getInfo();
    },
    async getInfo() {
      await axios
        .get(
          this.HttpServe + "/cloudoffice/fileOutsideChain/share/decodeLink",
          {
            headers: {
              "Content-Type": "application/json",
              Authorization: "Bearer " + this.token,
            },
            params: {
              encrypt: this.urlPath,
              code: Base64.encode(this.passWord),
            },
          }
        )
        .then((res) => {
          console.log(res, 3111);
          if (res.data.code == 200) {
            this.showList = true;
            this.showLink = false;
            this.form.title = res.data.data.shareTitle;
            this.form.createDate = res.data.data.createDate;
            this.form.createUser = res.data.data.createUser;
            this.ID = res.data.data.id;
          } else if (res.data.code == 1302) {
            this.showLink = true;
            this.showList = false;
          } else if (res.data.code == 1301) {
            this.$message.warning("访问该链接需要登录");
          }
        })
        .catch((error) => {
          console.log(error);
        });
    },
    async getList(e) {
      let data = {
        fileOutsideChainVO: {
          id: this.ID,
          extractPassword: Base64.encode(this.passWord),
        },
        targetFileVirtualFolderId: e ? e : "-2",
      };
      await axios
        .post(
          this.HttpServe + "/cloudoffice/fileOutsideChain/share/searchFiles",
          data,
          {
            headers: {
              "Content-Type": "application/json",
              Authorization: "Bearer " + this.token,
            },
          }
        )
        .then((res) => {
          console.log(res, 234);
          if (res.data.code == 200) {
            this.fileList = res.data.data.fileAndFolderInfoVOList;
            this.fileListFilter = this.fileList;
            this.fileId = res.data.data.currentFileVirtualFolderId;
          }
        })
        .catch((error) => {
          console.log(error);
        });
    },
    showLogin(e) {
      console.log(e);
      this.passWord = e.pass;
      this.showLink = e.show;
      this.init(); //输入提取码后显示外链资源列表从新初始化加载
      setTimeout(() => {
        this.getList();
      }, 1000);
    },
    onFile(e) {
      let data = {
        fileOutsideChainVO: {
          id: this.ID,
          extractPassword: Base64.encode(this.passWord),
        },
        targetFileVirtualFolderId: e,
      };
      axios
        .post(
          this.HttpServe + "/cloudoffice/fileOutsideChain/share/searchFiles",
          data,
          {
            headers: {
              "Content-Type": "application/json",
              Authorization: "Bearer " + this.token,
            },
          }
        )
        .then((res) => {
          if (res.data.code == 200) {
            console.log(res);
            this.fileId = res.data.data.currentFileVirtualFolderId; //找到当前文件文件夹ID
            console.log(222);
            this.fileList = res.data.data.fileAndFolderInfoVOList;
            this.getList(e);
          }
        })
        .catch((error) => {
          console.log(error);
        });
    },
    //返回上一层
    back() {
      if (this.fileId == "-2") {
        // this.$message.warning("已经时最顶层了");
        this.$router.go(-1);
      } else {
        let data = {
          fileOutsideChainVO: {
            id: this.ID,
            extractPassword: Base64.encode(this.passWord),
          },
          currentFileVirtualFolderId: this.fileId,
        };
        axios
          .post(
            this.HttpServe +
              "/cloudoffice/fileOutsideChain/share/goBackPreviousLevel",
            data,
            {
              headers: {
                "Content-Type": "application/json",
                Authorization: "Bearer " + this.token,
              },
            }
          )
          .then((res) => {
            console.log(res, "返回上一层");
            if (res.data.code == 200) {
              this.fileId = res.data.data.currentFileVirtualFolderId;
              this.fileList = res.data.data.fileAndFolderInfoVOList;
              this.getList(this.fileId);
            }
          })
          .catch((error) => {
            console.log(error);
          });
      }
    },
    //下载接口
    downLoadFile(a, b) {
      let data = {
        fileOutsideChainVO: {
          id: this.ID,
          extractPassword: Base64.encode(this.passWord),
        },
        fileVirtualInfoVOList: a,
        fileVirtualFolderInfoVOList: b,
      };

      axios
        .post(
          this.HttpServe + "/cloudoffice/fileOutsideChain/share/batchDownload",
          data,
          {
            headers: {
              "Content-Type": "application/json",
              Authorization: "Bearer " + this.token,
            },
          }
        )
        .then((res) => {
          console.log(res, "yyyyyy");
        })
        .catch((error) => {
          console.log(error);
        });
    },
    //监听列表类型切换
    handleSizeChange(e) {
      if (e.target.value == "table") {
        console.log(e.target.value);
        // this.$nextTick(() => {
        //   this.tableScroll();
        // });
        // this.tsbleScroll()
      } else {
        console.log("list-----");
        // this.$nextTick(() => {
        //   this.listScroll();
        // });
      }
      //  this.size = e.target.value;
    },
    //保存到我的空间
    save() {
      if (this.checkList.length == 0) {
        this.$message.warning("请选择文件");
      } else {
        this.showPersonVisible = true; //开启弹框
      }
    },
    //下载
    download() {
      if (this.checkList.length == 0) {
        this.$message.warning("请选择文件");
      } else {
        let fileVirtualInfoVOList = []; //文件ID
        let fileVirtualFolderInfoVOList = []; //文件夹ID
        this.checkList.forEach((item) => {
          if (item.isFolder == 0) {
            fileVirtualInfoVOList.push({
              id: item.id,
            });
          } else {
            fileVirtualFolderInfoVOList.push({
              id: item.id,
            });
          }
        });
        // console.log(fileVirtualInfoVOList, fileVirtualFolderInfoVOList);
        this.downLoadFile(fileVirtualInfoVOList, fileVirtualFolderInfoVOList);
      }
    },
    //打开
    open() {
      if (this.checkList.length > 1) {
        this.$message.warning("打开文件只能选中一个");
      } else if (this.checkList.length == 0) {
        this.$message.warning("请选择文件");
      } else {
        console.log(this.checkList[0].id);
        this.onFile(this.checkList[0].id);
      }
    },
    //shuxing
    attributes() {
      if (this.checkList.length > 1) {
        this.$message.warning("查看文件属性只能选中一个文件");
      } else if (this.checkList.length == 0) {
        this.$message.warning("请选择查看属性文件");
      } else {
        this.visible = true;
        let data = {};
        if (this.checkList[0].isFolder == 1) {
          data = {
            fileVirtualFolderInfoId: this.checkList[0].id,
          };
          this.fileAttributesForm.fileType = 1;
          console.log(this.fileAttributesForm);
        } else {
          data = {
            fileVirtualInfoId: this.checkList[0].id,
          };
          this.fileAttributesForm.fileType = 0;
        }
        axios
          .get(
            this.HttpServe + "/cloudoffice/fileAttributes/getFileAttributes",
            {
              headers: {
                "Content-Type": "application/json",
                Authorization: "Bearer " + this.token,
              },
              params: data,
            }
          )
          .then((res) => {
            console.log(res);
            if (res.data.code == 200) {
              console.log(res, "shuxing");
              if (this.checkList[0].isFolder == 1) {
                this.fileAttributesForm.fileName =
                  res.data.data.fileVirtualFolderInfoVO.folderName;
                this.fileAttributesForm.filePath =
                  res.data.data.fileVirtualFolderInfoVO.filePath;
                this.fileAttributesForm.fileSize =
                  res.data.data.fileVirtualFolderInfoVO.fileStorage;
                this.fileAttributesForm.fileIncludes =
                  res.data.data.fileVirtualFolderInfoVO.include;
                this.fileAttributesForm.createTime =
                  res.data.data.fileVirtualFolderInfoVO.createDate;
                this.fileAttributesForm.alterTime =
                  res.data.data.fileVirtualFolderInfoVO.updateDate;
              } else {
                console.log(res.data.data.fileVirtualInfoVO.folderName);
                this.fileAttributesForm.fileName =
                  res.data.data.fileVirtualInfoVO.fileName;
                this.fileAttributesForm.filePath =
                  res.data.data.fileVirtualInfoVO.filePath;
                this.fileAttributesForm.fileSize =
                  res.data.data.fileVirtualInfoVO.fileStorage;
                this.fileAttributesForm.fileIncludes =
                  res.data.data.fileVirtualInfoVO.include;
                this.fileAttributesForm.createTime =
                  res.data.data.fileVirtualInfoVO.createDate;
                this.fileAttributesForm.alterTime =
                  res.data.data.fileVirtualInfoVO.updateDate;
              }
            }
          })
          .catch((error) => {
            console.log(error);
          });
      }
    },
    //关闭属性弹框
    handleCancel() {
      this.visible = false;
    },
    onChange(selectedRowKeys, selectedRows) {
      console.log(
        `selectedRowKeys: ${selectedRowKeys}`,
        "selectedRows: ",
        selectedRows
      );
    },
    onSelect(record, selected, selectedRows) {
      console.log(record, selected, selectedRows);
      this.checkList = selectedRows;
    },
    onSelectAll(selected, selectedRows, changeRows) {
      console.log(selected, selectedRows, changeRows);
      this.checkList = selectedRows;
    },

    //搜索框搜索功能
    onSearchName() {
      if (this.searchName && this.searchName !== "") {
        this.fileListFilter = this.fileListFilter.filter(
          (p) => p.fileName.indexOf(this.searchName) !== -1
        );
        console.log(this.fileListFilter);
      } else {
        this.fileListFilter = this.fileList;
        console.log(this.fileListFilter);
      }
    },
    //当列表为卡片状态时点击复选框得到选中的文件
    onChangeCheckBox(checkedValues) {
      console.log("checked = ", checkedValues);
      this.checkList = checkedValues;
    },
    upData() {
      this.getList();
    },
  },
  filters: {
    //字节转换KB
    KBDate(limita) {
      let limit = parseInt(limita);
      if (limit > 0) {
        console.log("大小" + limit);
        var size = "";
        if (limit < 0.1 * 1024) {
          //如果小于0.1KB转化成B
          let intNum = parseInt(limit);
          size = intNum.toFixed(2) + " B";
        } else if (limit < 0.999 * 1024 * 1024) {
          //如果小于0.1MB转化成KB
          size = (limit / 1024).toFixed(2) + "KB";
        } else if (limit < 0.999 * 1024 * 1024 * 1024) {
          //如果小于0.1GB转化成MB
          size = (limit / (1024 * 1024)).toFixed(4) + "MB";
        } else if (limit < 0.999 * 1024 * 1024 * 1024 * 1024) {
          //其他转化成GB
          size = (limit / (1024 * 1024 * 1024)).toFixed(2) + "G";
        } else {
          size = (limit / (1024 * 1024 * 1024 * 1024)).toFixed(2) + "T";
        }

        var sizestr = size + "";
        var len = sizestr.indexOf(".");
        var dec = sizestr.substr(len + 1, 2);
        if (dec == "00") {
          //当小数点后为00时 去掉小数部分
          return sizestr.substring(0, len) + sizestr.substr(len + 3, 2);
        }
        return sizestr;
      } else {
        return limit;
      }
    },
  },
};
</script>

<style lang="less" scoped>
.main {
  .linkMain {
    .top {
      width: 100%;
      height: 50px;
      background: white;
      position: relative;
      .btn {
        position: absolute;
        top: 10px;
        left: 5vw;
        .btn1 {
          margin-left: 20px;
        }
      }
      .search {
        position: absolute;
        top: 20px;
        right: 100px;
      }
    }
    .content {
      width: 90vw;
      margin: 0 auto;
      height: 90vh;
      .file {
        width: 100px;
        margin: 5px;
        padding: 10px;
        float: left;
        position: relative;
        .img {
          width: 100%;
          height: 70px;
          overflow: hidden;
          // border: 1px solid pink;
        }
        .checkBox {
          position: absolute;
          top: 10px;
          left: 10px;
        }
        img {
          width: 60px;
          display: block;
          margin: 0 auto;
        }
        .text {
          // margin-top: 10px;
          text-align: center;
          // border: 1px solid black;
          max-height: 45px;
          overflow: hidden;
          text-overflow: ellipsis;
        }
      }
      .file:hover {
        background: #e5f3ff;
      }
      // .rightContent {
      //   width: 20%;
      //   height: 100%;
      //   border: 1px solid red;
      //   .top {
      //     height: 50px;
      //     font-size: 20px;
      //     text-align: center;
      //     line-height: 50px;
      //   }
      //   .ant-form-item {
      //     margin: 0;
      //   }
      // }
    }
  }
}

.icon {
  width: 20px;
  height: 20px;
}
.ant-layout-header {
  background: white;
}
.breadcrumb {
  padding: 0;

  .breadcrumb_left {
    text-align: left;

    // padding-left: 40px;
    .ant-breadcrumb {
      line-height: 60px;
      display: inline-block;
    }
  }

  .breadcrumb_center {
    text-align: left;
    line-height: 50px;

    .ant-breadcrumb {
      line-height: 60px;
    }
  }

  .breadcrumb_right {
    text-align: right;
    padding-right: 20px;
    .ant-btn-group {
      margin-right: 20%;
    }
  }
}

//属性弹框
.ModalContent {
  // border: 1px solid red;
  // padding: 20px;
  .ant-form-item {
    margin: 0;
  }
  .img {
    img {
      width: 50px;
      margin-left: 40px;
    }
  }
}
/deep/.ant-checkbox-group {
  vertical-align: top;
}
</style>
