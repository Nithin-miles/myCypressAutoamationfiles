const FileListColumns = [{
        title: '文件名',
        dataIndex: 'fileName',
        sorter: (a, b) => a.fileName > b.fileName,
        scopedSlots: { customRender: 'fileName' },
        align: 'left',
        width: 300,
    },
    {
        title: '更新时间',
        dataIndex: 'updateDate',
        sorter: (a, b) => a.updateDate > b.updateDate,
        align: 'left',
    },
    {
        title: '类型',
        dataIndex: 'fileType',
        sorter: (a, b) => a.fileType > b.fileType,
        align: 'left',
    },
    {
        title: '文件大小',
        dataIndex: 'fileStorage',
        scopedSlots: { customRender: 'fileStorage' },
        sorter: (a, b) => a.fileStorage > b.fileStorage,
        align: 'left',
    },
    {
        title: '是否已分享',
        dataIndex: 'share',
        sorter: (a, b) => a.share > b.share,
        align: 'left',
    },
];

export {
    FileListColumns,
}