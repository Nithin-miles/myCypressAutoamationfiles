<template>
  <div class="main">
    <div class="login">
      <div class="title">提取密码</div>
      <a-input class="inp" v-model="form.code" />
      <a-button type="primary" class="btn" @click="getInfo">确定</a-button>
    </div>
  </div>
</template>

<script>
import Base64 from "base-64";
import axios from "axios";
import Vue from "vue";
Vue.prototype.$axios = axios;
import { token, HttpServe } from "./httpAndTokenServe";
export default {
  data() {
    return {
      urlPath: "",
      form: {
        code: "",
      },
      token,
      HttpServe,
    };
  },
  mounted() {
    this.urlPath = window.location.href.split("path=")[1];
    console.log(this.urlPath);
  },
  methods: {
    getInfo() {
      axios
        .get(
          this.HttpServe+"/cloudoffice/fileOutsideChain/share/decodeLink",
          {
            headers: {
              "Content-Type": "application/json",
              Authorization: "Bearer " + this.token,
            },
            params: {
              encrypt: this.urlPath,
              code: Base64.encode(this.form.code),
            },
          }
        )
        .then((res) => {
          if (res.data.code == 200) {
            let obj = {
              show: false,
              pass: this.form.code,
            };
            this.$emit("showLogin", obj);
          } else {
            this.$message.warning(res.data.message);
          }
        })
        .catch((error) => {
          console.log(error);
        });
    },
  },
};
</script>

<style lang="less" scoped>
.main {
  .login {
    width: 400px;
    height: 280px;
    border-top: 3px solid #03a9f4;
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    margin: auto;
    box-shadow: 0px 0px 20px #ccc;
    border-radius: 5px;
    .title {
      height: 70px;
      background: #eeeeee;
      line-height: 70px;
      font-size: 24px;
      text-align: center;
    }
    .inp {
      display: block;
      width: 250px;
      margin: 0 auto;
      margin-top: 30px;
    }
    .btn {
      width: 250px;
      display: block;
      margin: 0 auto;
      margin-top: 20px;
    }
  }
}
</style>
