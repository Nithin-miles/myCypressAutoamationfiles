// const token = "f0f3150d-37fe-4802-8958-6134f4fa3887";//机构管理员
const token = "ba160393-0dc0-415a-8f71-81eef251cdf2"; //超级管理员
const localHttp = "http://192.168.19.28:8089";
const HttpServe = "http://192.168.19.29:6001";
export {
    token,
    localHttp,
    HttpServe,
}