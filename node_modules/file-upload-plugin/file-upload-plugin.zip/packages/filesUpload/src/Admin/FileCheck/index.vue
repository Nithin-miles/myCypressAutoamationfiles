<template>
  <div class="wfm-filecheck-container">
    <a-row type="flex" justify="space-around" align="middle">
      <a-col :span="8">
        <a-button type="primary"> 快速查杀 </a-button>
      </a-col>
      <a-col :span="8">
        <a-button type="primary"> 开始审计 </a-button>
      </a-col>
    </a-row>
  </div>
</template>

<script>
export default {
  name: "file-check",
};
</script>
<style lang="less" scoped>
.wfm-filecheck-container {
  text-align: center;
}
</style>
