<template>
  <a-card>
    <template #title style="width: 70%">
      <a-icon type="tool" />
      系统设置
    </template>
    <div>
      <a-divider orientation="left">回收站清理策略</a-divider>
      <a-radio-group v-model="value" @change="onChange">
        <a-radio :style="{ display: 'block' }" :value="1"> 不自动清理 </a-radio>
        <a-radio :style="{ display: 'block' }" :value="2">
          <a-input-number
            v-model="days"
            :disabled="value === 1"
          />&nbsp;天自动清理
        </a-radio>
      </a-radio-group>
      <a-divider orientation="left">存储空间预警</a-divider>
      <div>文件存储容量：共100T，已用80T，剩余20T。</div>
      <div>
        当剩余空间大小低于
        <a-input-number v-model="space" />&nbsp;
        <a-select
          :default-value="capacityUnit"
          v-model="capacityUnit"
          style="width: 60px"
          @change="handleChange"
        >
          <a-select-option value="MB"> MB </a-select-option>
          <a-select-option value="GB"> GB </a-select-option>
          <a-select-option value="TB"> TB </a-select-option> </a-select
        >&nbsp;时，向管理员推送预警
      </div>
      <a-divider orientation="left">个人空间设置</a-divider>
      <div>
        个人空间最大限制
        <a-input-number v-model="personCapacity" />&nbsp;
        <a-select
          :default-value="personCapacityUnit"
          v-model="personCapacityUnit"
          style="width: 60px"
          @change="handleChangeMine"
        >
          <a-select-option value="MB"> MB </a-select-option>
          <a-select-option value="GB"> GB </a-select-option>
          <a-select-option value="TB"> TB </a-select-option>
        </a-select>
      </div>
    </div>
    <div class="foot">
      <a-button type="primary" @click="fileSet" style="margin-right: 20px"
        >保存</a-button
      >
      <a-button @click="init()">重置</a-button>
    </div>
  </a-card>
</template>

<script>
import { token, HttpServe } from "../http.js";
import axios from "axios";
import Vue from "vue";
Vue.prototype.$axios = axios;
export default {
  name: "setting",
  data() {
    return {
      value: 1,
      days: 0,
      space: 10,
      capacityUnit: "MB",
      personCapacity: 10,
      personCapacityUnit: "MB",
      token,
      HttpServe,
    };
  },
  mounted() {
    this.init();
  },
  methods: {
    init() {
      this.ShowFileSet();
    },
    //回显接口
    async ShowFileSet() {
      // let data = {
      //   key: "fileSystemSettings",
      // };
      await axios
        .get(this.HttpServe + "/cloudoffice/fileSet/selectFileSet", {
          headers: {
            "Content-Type": "application/json",
            Authorization: "Bearer " + this.token,
          },
          params: {
            key: "fileSystemSettings",
          },
        })
        .then((res) => {
          if (res.status == 200) {
            console.log(JSON.parse(res.data.data[0].value));
            let obj = JSON.parse(res.data.data[0].value);
            this.value = obj.recycleBinStrategy + 1;
            this.days = obj.clearDay;
            this.space = obj.storageCapacity;
            this.capacityUnit = obj.capacityUnit;
            this.personCapacity = obj.personCapacity;
            this.personCapacityUnit = obj.personCapacityUnit;
            console.log(this.capacityUnit);
          }
        })
        .catch((error) => {
          console.log(error);
        });
    },
    //点击保存
    fileSet() {
      this.updateFileSet();
    },
    //保存设置接口
    async updateFileSet() {
      let data = {
        key: "fileSystemSettings",
        setParametersVO: {
          recycleBinStrategy: this.value - 1, //0不自动清理，1多少天后自动清理
          clearDay: this.days,
          storageCapacity: this.space,
          capacityUnit: this.capacityUnit,
          personCapacity: this.personCapacity,
          personCapacityUnit: this.personCapacityUnit,
        },
      };
      await axios
        .put(this.HttpServe + "/cloudoffice/fileSet/updateFileSet", data, {
          headers: {
            "Content-Type": "application/json",
            Authorization: "Bearer " + this.token,
          },
        })
        .then((res) => {
          if (res.status == 200) {
            console.log(res);
            this.$message.success(res.data.message);
          }
        })
        .catch((error) => {
          console.log(error);
          this.$message.warning(error);
        });
    },
    //单选框发生变化
    onChange(e) {
      console.log("radio checked", e.target.value);
      this.value = e.target.value;
    },
    //下拉选择框
    handleChange(value) {
      console.log(`selected ${value}`);
      this.capacityUnit = value;
      console.log(this.capacityUnit, 11122);
    },
    //下拉选择框
    handleChangeMine(value) {
      console.log(`selected ${value}`);
      this.personCapacityUnit = value;
      console.log(this.personCapacityUnit, 11122);
    },
  },
};
</script>
<style lang="less" scoped>
.foot {
  margin: 0 auto;
  margin-top: 10px;
  text-align: center;
}
</style>
