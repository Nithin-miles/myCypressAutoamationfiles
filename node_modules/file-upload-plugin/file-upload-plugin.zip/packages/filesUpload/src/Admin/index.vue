<template>
  <div class="wfm-adminContainer">
    <a-tabs default-active-key="1" tab-position="left">
      <a-tab-pane key="1">
        <span slot="tab">
          <a-icon type="folder" />
          文件管理
        </span>
        <file-manage />
      </a-tab-pane>
      <a-tab-pane key="2">
        <span slot="tab">
          <a-icon type="dashboard" />
          空间管理
        </span>
        <space-manage />
      </a-tab-pane>
      <a-tab-pane key="3">
        <span slot="tab">
          <a-icon type="tool" />
          系统设置
        </span>
        <setting />
      </a-tab-pane>
      <a-tab-pane key="4">
        <span slot="tab">
          <a-icon type="filter" />
          系统审计
        </span>
        <file-check />
      </a-tab-pane>
    </a-tabs>
  </div>
</template>

<script>
import FileManage from "./FileManage";
import FileCheck from "./FileCheck";
import Setting from "./Setting";
import SpaceManage from "./SpaceManage";
export default {
  name: "admin",
  components: { FileManage, FileCheck, Setting, SpaceManage },
  mounted(){
      console.log(222);
  },
};
</script>
<style lang="less" scoped>
.wfm-adminContainer {
  width: 75vw;
}
</style>
