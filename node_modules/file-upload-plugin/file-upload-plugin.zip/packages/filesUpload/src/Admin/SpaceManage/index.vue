<template>
  <div>
    <a-row :gutter="16">
      <a-col :span="8">
        <a-card class="top">
          <a-statistic
            :title="'空间使用情况(总空间' + totalCapacity + 'G)'"
            style="margin-right: 50px"
          >
            <template #formatter>
              <a-progress
                :percent="50"
                size="small"
                status="active"
                :strokeWidth="10"
                :showInfo="false"
              />
              <div
                style="
                  width: 12vw;
                  display: flex;
                  justify-content: space-between;
                  font-size: 14px;
                "
              >
                <div class="left">已使用&nbsp;{{ usedCapacity }}</div>
                <div class="right">还剩&nbsp;{{ residueCapacity }}</div>
              </div>
            </template>
          </a-statistic>
          <a-icon type="cloud-server" class="icon" />
        </a-card>
      </a-col>
      <a-col :span="8">
        <a-card class="top">
          <a-statistic
            title="文件夹总数量"
            :value="TotalFolderCount"
            suffix="个"
          >
          </a-statistic>
          <a-icon type="folder" class="icon" />
        </a-card>
      </a-col>
      <a-col :span="8">
        <a-card class="top">
          <a-statistic title="文件总数量" :value="FileTotalNumber" suffix="个">
          </a-statistic>
          <a-icon type="file" class="icon" />
        </a-card>
      </a-col>
    </a-row>
    <a-row :gutter="16">
      <a-col :span="12">
        <a-card title="文件统计" :bordered="false">
          <a-table
            :columns="columns"
            :data-source="data"
            :pagination="false"
            size="middle"
            :scroll="{ y: 140 }"
          >
          </a-table>
        </a-card>
      </a-col>
      <a-col :span="12">
        <div class="charts" id="main"></div>
        <div class="text1">容量占比</div>
        <div class="text2">数量占比</div>
      </a-col>
    </a-row>
    <a-row :gutter="16">
      <a-col :span="12">
        <a-card title="各类空间统计" :bordered="false">
          <a-table
            :columns="columns1"
            :data-source="data1"
            :pagination="false"
            size="middle"
            :scroll="{ y: 140 }"
          >
            <span slot="fileStorage" slot-scope="text">
              <a-progress :percent="Number(text)" />
            </span>
          </a-table>
        </a-card>
      </a-col>
      <a-col :span="12"> </a-col>
    </a-row>
  </div>
</template>

<script>
import { token, HttpServe } from "../http.js";
import axios from "axios";
import Vue from "vue";
import * as echarts from "echarts";
Vue.prototype.$axios = axios;
const columns = [
  {
    title: "文件类型",
    key: "fileType",
    dataIndex: "fileType",
  },
  {
    title: "容量",
    dataIndex: "fileStorage",
    key: "fileStorage",
  },
  {
    title: "容量占比",
    dataIndex: "capacityProportion",
    key: "capacityProportion",
  },
  {
    title: "数量",
    key: "fileCount",
    dataIndex: "fileCount",
  },
  {
    title: "数量占比",
    key: "countProportion",
    dataIndex: "countProportion",
  },
];

const columns1 = [
  {
    title: "空间类型",
    key: "spaceType",
    dataIndex: "spaceType",
  },
  {
    title: "空间使用情况",
    dataIndex: "fileStorage",
    key: "fileStorage",
    scopedSlots: { customRender: "fileStorage" },
  },
  {
    title: "文件数量",
    dataIndex: "fileCount",
    key: "fileCount",
  },
];

export default {
  name: "space-manage",
  data() {
    return {
      data: [],
      columns,
      data1: [],
      columns1,
      // token: "f0f3150d-37fe-4802-8958-6134f4fa3887",
      HttpServe,
      token,
      totalCapacity: "0", //总空间容量
      TotalFolderCount: "", //文件夹总数
      FileTotalNumber: "", //文件总数
      usedCapacity: "", //已使用
      residueCapacity: "", //剩余空间
      charts: [],
    };
  },

  mounted() {
    this.init();
    //延迟一秒执行图表，等待值加载完毕
    setTimeout(() => {
      this.showEcharts();
    }, 800);
  },
  methods: {
    init() {
      this.fileTotal(); //文件统计
      this.fileTableList(); //各类型空间统计
      this.fileTopTotal(); //获取文件夹文件总数
    },
    async fileTopTotal() {
      await axios
        .get(
          this.HttpServe + "/cloudoffice/spaceUsageCondition/selectSpaceUsage",
          {
            headers: {
              "Content-Type": "application/json",
              Authorization: "Bearer " + this.token,
            },
          }
        )
        .then((res) => {
          if (res.status == 200) {
            this.TotalFolderCount = res.data.folderTotal;
            this.FileTotalNumber = res.data.fileTotal;
            this.totalCapacity = res.data.totalCapacity;
            this.usedCapacity = res.data.usedCapacity;
            this.residueCapacity = res.data.residueCapacity;
          }
        })
        .catch((error) => {
          console.log(error);
        });
    },
    async fileTotal() {
      await axios
        .get(this.HttpServe + "/cloudoffice/fileVirtualInfo/fileStatistics", {
          headers: {
            "Content-Type": "application/json",
            Authorization: "Bearer " + this.token,
          },
        })
        .then((res) => {
          if (res.status == 200) {
            this.data = res.data.data;
          }
        })
        .catch((error) => {
          console.log(error);
        });
    },
    async fileTableList() {
      await axios
        .get(
          this.HttpServe +
            "/cloudoffice/fileVirtualInfo/allSpaceUsageStatistics",
          {
            headers: {
              "Content-Type": "application/json",
              Authorization: "Bearer " + this.token,
            },
          }
        )
        .then((res) => {
          if (res.status == 200) {
            console.log(res, 22);
            this.data1 = res.data.data;
          }
        })
        .catch((error) => {
          console.log(error);
        });
    },
    showEcharts() {
      let myChart = echarts.init(document.getElementById("main"));
      let capacityProportion = [];
      let countProportion = [];
      this.data.forEach((item) => {
        // console.log(item);
        capacityProportion.push({
          name: item.fileType,
          value: item.fileStorage,
        });
        countProportion.push({
          name: item.fileType,
          value: item.fileCount,
        });
        // console.log(capacityProportion, 323);
      });
      // 绘制图表
      let option = {
        tooltip: {
          trigger: "item",
          formatter: "{a} <br/>{b} : {c} ({d}%)",
        },

        series: [
          {
            name: "容量占比",
            type: "pie",
            radius: ["40%", "70%"],
            center: ["25%", "50%"],
            avoidLabelOverlap: false,
            label: {
              show: false,
              position: "center",
            },
            emphasis: {
              label: {
                show: true,
                fontSize: "30",
                fontWeight: "bold",
              },
            },
            labelLine: {
              show: false,
            },
            data: capacityProportion,
          },
          {
            name: "From",
            type: "pie",
            radius: ["40%", "70%"],
            center: ["75%", "50%"],
            avoidLabelOverlap: false,
            label: {
              show: false,
              position: "center",
            },
            emphasis: {
              label: {
                show: true,
                fontSize: "30",
                fontWeight: "bold",
              },
            },
            labelLine: {
              show: false,
            },
            data: countProportion,
          },
        ],
      };
      option && myChart.setOption(option);
    },
  },
};
</script>
<style lang="less" scoped>
.top {
  height: 130px;
  /deep/.ant-progress-show-info .ant-progress-outer {
    width: 250px;
  }
  /deep/.ant-statistic-title {
    font-size: 20px;
    font-weight: 600;
  }
  /deep/.ant-statistic-content {
    font-weight: 700;
  }
  .icon {
    position: absolute;
    top: 20px;
    right: 30px;
    font-size: 80px;
    color: #1890ff;
  }
}
.charts {
  width: 30vw;
  height: 13vw;
  margin-left: 3vw;
  margin-top: 20px;
}
.text1 {
  position: absolute;
  left: 26%;
  bottom: -20px;
  font-size: 20px;
  font-weight: 600;
}
.text2 {
  position: absolute;
  right: 17%;
  bottom: -20px;
  font-size: 20px;
  font-weight: 600;
}
.top /deep/.ant-progress-inner {
  border: 1px solid #ccc;
  width: 12vw;
}
</style>
