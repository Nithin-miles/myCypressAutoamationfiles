<template>
  <div>
    <a-tabs default-active-key="1">
      <a-tab-pane key="1" tab="用户视角" force-render>
        <a-row :gutter="[8, 16]">
          <a-col :span="24">
            <a-form-model
              layout="inline"
              :model="userViewForm"
              ref="userViewForm"
            >
              <a-form-model-item label="区域">
                <a-cascader
                  v-model="userViewForm.region"
                  :options="regioOptions"
                  placeholder="请选择区域"
                  @change="onChange"
                />
              </a-form-model-item>
              <a-form-model-item label="机构部门">
                <a-select
                  style="width: 200px"
                  placeholder="请选择机构部门"
                  v-model="userViewForm.organization"
                  @change="handleOrganizationChange"
                >
                  <a-select-option
                    v-for="(item, index) in organization"
                    :key="index"
                    :value="item.id"
                  >
                    {{ item.organizationName }}
                  </a-select-option>
                </a-select>
              </a-form-model-item>
              <a-form-model-item label="关键字">
                <a-input
                  v-model="userViewForm.keywords"
                  placeholder="输入用户名、姓名搜索"
                />
              </a-form-model-item>
              <a-form-model-item>
                <a-button
                  type="primary"
                  icon="search"
                  @click="userViewQuery"
                  :loading="userViewLoading"
                  style="margin-right: 15px"
                >
                  查询
                </a-button>
                <a-button icon="undo" @click="userViewReset"> 重置 </a-button>
              </a-form-model-item>
            </a-form-model>
          </a-col>
          <a-col :span="24">
            <a-table
              :scroll="{ y: 500 }"
              :columns="userViewColumns"
              :data-source="userViewData"
              :pagination="userViewPagination"
              @change="onChangeUserPage"
            >
              <span slot="referenceFileSpaceUsage" slot-scope="text, record">
                <a-progress
                  :stroke-color="{
                    '0%': '#29bdd9',
                    '100%': '#276ace',
                  }"
                  :percent="record.percentage"
                  :showInfo="false"
                />
                {{ record.totalFileSize | KBDate(record.totalFileSize) }}/
                {{
                  record.personalSpaceSize | KBDate(record.personalSpaceSize)
                }}
              </span>

              <span slot="notQuoteFileSize" slot-scope="text, record">
                {{ text | KBDate(text) }}
              </span>
              <span slot="userViewAction" slot-scope="text, record">
                <a-button type="link" @click="userViewCheck(record)">
                  查看文件
                </a-button>
              </span>
            </a-table>
          </a-col>
        </a-row>
      </a-tab-pane>
      <a-tab-pane key="2" tab="文件视角" force-render>
        <a-row :gutter="[8, 16]">
          <a-col :span="24">
            <a-form-model
              layout="inline"
              :model="filesViewForm"
              ref="filesViewForm"
            >
              <a-form-model-item label="类型">
                <a-select
                  style="width: 150px"
                  placeholder="请选择类型"
                  v-model="filesViewForm.fileType"
                >
                  <a-select-option
                    v-for="(item, index) in fileType"
                    :key="index"
                    :value="item"
                  >
                    {{ item }}
                  </a-select-option>
                </a-select>
              </a-form-model-item>
              <a-form-model-item label="状态">
                <a-select
                  style="width: 150px"
                  placeholder="请选择状态"
                  v-model="filesViewForm.fileState"
                >
                  <a-select-option value="all"> 全部 </a-select-option>
                  <a-select-option value="1"> 上传成功 </a-select-option>
                  <a-select-option value="0"> 上传失败 </a-select-option>
                </a-select>
              </a-form-model-item>
              <a-form-model-item label="引用情况">
                <a-select
                  style="width: 150px"
                  placeholder="请选择引用情况"
                  v-model="filesViewForm.fileCitation"
                >
                  <a-select-option value="all"> 全部 </a-select-option>
                  <a-select-option value="0"> 无引用人 </a-select-option>
                  <a-select-option value="1"> 无引用类型 </a-select-option>
                  <a-select-option value="2"> 没有任何引用 </a-select-option>
                </a-select>
              </a-form-model-item>
              <a-form-model-item label="关键字">
                <a-input
                  v-model="filesViewForm.keywords"
                  placeholder="输入用户名、姓名、文件名搜索"
                  style="width: 230px"
                />
              </a-form-model-item>
              <a-form-model-item>
                <a-button
                  type="primary"
                  icon="search"
                  @click="filesViewQuery"
                  :loading="filesViewLoading"
                  style="margin-right: 15px"
                >
                  查询
                </a-button>
                <a-button icon="undo" @click="filesViewReset"> 重置 </a-button>
              </a-form-model-item>
            </a-form-model>
          </a-col>
          <a-col :span="24">
            <!-- <a-button
              type="primary"
              icon="file"
              ghost
              style="margin-right: 20px"
            >
              移 动
            </a-button> -->
            <a-button
              type="danger"
              icon="delete"
              ghost
              @click="deleteAll('all')"
            >
              批量删除
            </a-button>
          </a-col>
          <a-col :span="24" class="fileViewTable">
            <a-table
              :scroll="{ y: 350 }"
              :columns="fileViewColumns"
              :data-source="fileViewData"
              :pagination="fileViewPagination"
              :row-selection="{
                selectedRowKeys: selectedRowKeys,
                onChange: onSelectChange,
              }"
              @change="onChangeFilePage"
            >
              <!-- :row-selection="{ selectedRowKeys: selectedRowKeys, onChange: onSelectChange }" -->
              <span slot="fileState" slot-scope="text">
                {{ text == 0 ? "上传失败" : "上传成功" }}
              </span>
              <span slot="fileSize" slot-scope="text">
                {{ text | KBDate(text) }}
              </span>

              <template slot="fileAction" slot-scope="text, record">
                <!-- <span
                  v-show="record.fileState == 0"
                  style="color: #1890ff"
                  @click="move('move')"
                >
                  移动
                </span> -->
                <span
                  v-show="record.fileState == 1"
                  style="padding: 10px; color: #1890ff"
                  @click="handOut(record)"
                >
                  分发
                </span>
                <span @click="deleteAll(record)" style="color: red">
                  删除
                </span>
              </template>
            </a-table>
            <div class="selectedBox">
              <span>已选择{{ selectedRowKeys.length }}条</span>
              <a-button type="link" @click="selectedClear"> 清空 </a-button>
            </div>
          </a-col>
        </a-row>
      </a-tab-pane>
    </a-tabs>
    <a-modal
      title="查看文件"
      :visible="fileCheckVisible"
      :confirm-loading="fileConfirmLoading"
      @cancel="fileCheckhandleCancel"
      :width="1000"
    >
      <a-table
        :columns="columns"
        :data-source="userTableData"
        :pagination="false"
        :scroll="{ y: 400 }"
        style="min-height: 400px"
        row-key="id"
      >
        <span slot="fileStorage" slot-scope="text">
          {{ text | KBDate(text) }}
        </span>
        <span slot="cloudPortal" slot-scope="text">
          {{ text == 1 ? "已发布" : "未发布" }}
        </span>
        <span slot="quote" slot-scope="text">
          {{ text == 1 ? "已引用" : "未引用" }}
        </span>
        <span slot="share" slot-scope="text">
          {{ text == 1 ? "已分享" : "未分享" }}
        </span>
      </a-table>
      <template slot="footer">
        <a-button key="back" @click="fileCheckhandleCancel"> 关闭 </a-button>
      </template>
    </a-modal>
    <modal-dia
      :modalVisible.sync="modalVisible"
      @visible="diaVisible"
    ></modal-dia>
    <hand-out-modal
      v-if="handOutVisible"
      :handOutVisible.sync="handOutVisible"
      @visible="handOutModalDial"
      :token="token"
      :HttpServe="HttpServe"
      :sendFileID="sendFileID"
    ></hand-out-modal>
  </div>
</template>

<script>
const columns = [
  {
    dataIndex: "fileName",
    key: "fileName",
    title: "文件名",
  },
  {
    title: "更新时间",
    dataIndex: "updateDate",
    key: "updateDate",
  },
  {
    title: "类型",
    dataIndex: "fileType",
    key: "fileType",
  },
  {
    title: "文件大小",
    dataIndex: "fileStorage",
    key: "fileStorage",
    scopedSlots: { customRender: "fileStorage" },
  },
  {
    title: "是否发布",
    key: "cloudPortal",
    dataIndex: "cloudPortal",
    scopedSlots: { customRender: "cloudPortal" },
  },
  {
    title: "是否引用",
    key: "quote",
    dataIndex: "quote",
    scopedSlots: { customRender: "quote" },
  },
  {
    title: "是否分享",
    key: "share",
    dataIndex: "share",
    scopedSlots: { customRender: "share" },
  },
];

import {
  userViewColumns,
  userViewData,
  fileViewColumns,
  fileViewData,
} from "./fileManage.js";
import { token, HttpServe } from "../http.js";
import modalDia from "./moveModal.vue";
import handOutModal from "./handOutModal.vue";
import axios from "axios";
import Vue from "vue";
Vue.prototype.$axios = axios;

export default {
  name: "file-manage",
  data() {
    return {
      fileCheckData: "",
      fileCheckVisible: false,
      fileConfirmLoading: false,
      // ---------------------
      // 用户视角
      regioOptions: [], //查询区域级联选择
      organization: [], //机构选择框
      organizationChange: "", //选择的机构id
      userPageNum: 1, //当前页数
      userPageNumber: 10, //用户视角表格的每页条数
      userViewForm: {
        //查询表单
        region: [],
        organization: undefined,
        keywords: "",
      },
      userViewLoading: false, //查询按钮loading
      userViewColumns,
      userViewData,
      userViewPagination: {
        size: "small",
        "show-size-changer": true,
        // 'show-quick-jumper': true,
        total: 0,
        "show-total": (total) => `共 ${total} 条`,
      },
      // storagePercent: 50, //引用文件空间使用百分比
      // --------------------------------------------------------------------------
      // 文件视角、
      fileType: ["全部", "png", "pdf", "txt"],
      filesViewForm: {
        //查询表单
        fileType: undefined,
        fileState: undefined,
        fileCitation: undefined,
        keywords: "",
      },
      fileViewColumns,
      fileViewData: [],
      fileViewPagination: {
        size: "small",
        "show-size-changer": true,
        // 'show-quick-jumper': true,
        total: 0,
        "show-total": (total) => `共 ${total} 条`,
      },
      filePageNum: 1, //当前页数
      filePageNumber: 10, //用户视角表格的每页条数
      selectedRowKeys: [], //勾选
      filesViewLoading: false,
      // ---------------------------------
      userTableData: [],
      columns,
      modalVisible: false, //移动弹框
      handOutVisible: false, //分发弹框
      sendFileID: "", //分发文件ID
      chooseFile: [], //文件视角勾选中的文件
      modalVisibleState: "", //区分打开弹框的类型
      // token: "a74aeee2-03a6-4728-89ac-f5280e4aad42",
      // token: "d35a5b03-1ad0-42f0-84ea-dabdb9b7cd80",
      token, //引入地址
      HttpServe, //引入token
    };
  },
  components: {
    modalDia,
    handOutModal,
  },
  created() {
    this.getArea();
    this.userViewQuery("-1");
    this.fileViewCheck();
  },
  mounted() {},

  methods: {
    // 文件视角删除
    fileRowDelete(key) {
      console.log(key);
    },
    // 文件视角清空勾选
    selectedClear() {
      this.selectedRowKeys = [];
    },
    // 文件视角勾选
    onSelectChange(selectedRowKeys, selectedRows) {
      console.log("selectedRowKeys changed: ", selectedRowKeys);
      this.selectedRowKeys = selectedRowKeys;
      console.log(selectedRows);
      this.chooseFile = selectedRows;
    },
    // 文件视角查询
    filesViewQuery() {
      // this.filesViewLoading = true;
      // setTimeout(() => {
      //   this.filesViewLoading = false;
      // }, 1000);
      this.fileViewCheck();
    },
    // 文件视角查询重置
    filesViewReset() {
      console.log(222);
      // this.$refs['userViewForm'].resetFields()
      this.filesViewForm = {
        //查询表单
        fileType: undefined,
        fileState: undefined,
        fileCitation: undefined,
        keywords: "",
      };
    },
    // 用户视角查询
    userViewQuery(e) {
      console.log(111);
      this.userViewLoading = true;
      // setTimeout(() => {
      //   this.userViewLoading = false;
      // }, 1000);
      let that = this;

      axios
        .get(
          that.HttpServe + "/cloudoffice/fileInvoke/selectFileManageInvokeInfo",
          {
            headers: {
              "Content-Type": "application/json",
              Authorization: "Bearer " + that.token,
            },
            params: {
              pageNum: that.userPageNum,
              pageSize: that.userPageNumber,
              organizationId: e == "-1" ? "" : that.organizationChange,
            },
          }
        )
        .then((res) => {
          console.log(res);
          if (res.data.code == 200) {
            that.userViewData = res.data.data;
            that.userViewPagination.total = Number(res.data.total);
            that.userViewLoading = false;
            that.count(that.userViewData);
          }
        })
        .catch((error) => {
          console.log(error);
        });
    },
    //用户视角table表格单个文件查看文件
    lookFile(e) {
      console.log(e);
      let that = this;
      let data = {
        parentId: "",
        pageNum: this.userPageNum,
        pageSize: this.userPageNumber,
        spaceType: 0,
        userId: e.userId,
        order: "update_date desc",
      };
      axios
        .post(
          that.HttpServe +
            "/cloudoffice/fileVirtualFolderInfo/selectAllSpaceByAdminRole",
          data,
          {
            headers: {
              "Content-Type": "application/json",
              Authorization: "Bearer " + that.token,
            },
          }
        )
        .then((res) => {
          console.log(res);
          if (res.data.code == 200) {
            that.userTableData = res.data.data;
          }
        })
        .catch((error) => {
          console.log(error);
        });
    },
    // 用户视角查询重置
    userViewReset() {
      console.log(222);
      // this.$refs['userViewForm'].resetFields()
      this.userViewForm = {
        region: [],
        organization: "",
        keywords: "",
      };
    },
    // 用户视角表单查看文件
    userViewCheck(data) {
      console.log(data);
      this.fileCheckData = JSON.stringify(data);
      this.fileCheckVisible = true;
      this.lookFile(data);
    },
    fileCheckHandleOk(e) {
      this.fileConfirmLoading = true;
      setTimeout(() => {
        this.fileCheckVisible = false;
        this.fileConfirmLoading = false;
      }, 2000);
    },
    fileCheckhandleCancel(e) {
      this.fileCheckVisible = false;
    },

    //文件视角渲染table列表
    fileViewCheck() {
      let that = this;
      axios
        .get(
          that.HttpServe +
            "/cloudoffice/fileInfo/queryAllFileInfoAtFileManagement",
          {
            headers: {
              "Content-Type": "application/json",
              Authorization: "Bearer " + that.token,
            },
            params: {
              pageNum: that.filePageNum,
              pageSize: that.filePageNumber,
              order: "fi.file_upload_time desc",
              fileType:
                that.filesViewForm.fileType == "全部"
                  ? ""
                  : that.filesViewForm.fileType,
              fileState:
                that.filesViewForm.fileState == "all"
                  ? ""
                  : that.filesViewForm.fileState,
              referenceType:
                that.filesViewForm.fileCitation == "all"
                  ? ""
                  : that.filesViewForm.fileCitation,
              searchValue: that.filesViewForm.keywords,
            },
          }
        )
        .then((res) => {
          console.log(res, "file");
          if (res.data.code == 200) {
            that.fileViewData = res.data.data;
            that.fileViewPagination.total = Number(res.data.total);
          }
        })
        .catch((error) => {
          console.log(error);
        });
    },
    //点击移动
    move() {
      this.modalVisible = true;
    },
    //点击分发
    handOut(e) {
      this.handOutVisible = true;
      console.log(e);
      this.sendFileID = e.id; //选中分发文件的ID
    },

    //关闭移动窗口
    diaVisible(e) {
      this.modalVisible = e;
    },

    //关闭分发窗口
    handOutModalDial(e) {
      this.handOutVisible = e;
    },

    //查询机构
    getRegionOptionsMechanism(value) {
      let that = this;
      axios
        .post(
          that.HttpServe +
            "/systemportal/sysOrganization/selectOrganizationByUserRole",
          {
            id: value,
          },
          {
            headers: {
              "Content-Type": "application/json",
              Authorization: "Bearer " + that.token,
            },
          }
        )
        .then((res) => {
          console.log(res);
          if (res.data.code == 200) {
            that.organization = res.data.data;
          }
        })
        .catch((error) => {
          console.log(error);
        });
    },

    //后台管理查询区域
    getArea() {
      let that = this;
      let data = {};
      axios
        .post(
          that.HttpServe + "/systemportal/sysRegion/selectRegionByUserRole",
          data,
          {
            headers: {
              "Content-Type": "application/json",
              Authorization: "Bearer " + that.token,
            },
          }
        )
        .then((res) => {
          console.log(res, "后台");
          if (res.data.code == 200) {
            that.regioOptions = this.formatData(res.data.data);
          }
        })
        .catch((error) => {
          console.log(error);
        });
    },
    //递归查找区域下一层，如果没有children的话返回underfind
    formatData(data) {
      const that = this;
      data.forEach((element) => {
        element.value = element.label;
        if (element.children && element.children.length > 0) {
          // console.log(element);
          that.formatData(element.children);
        } else {
          delete element.children //true
        }
      });
      return data;
    },
    //选择后区域
    onChange(e, selectedOptions) {
      console.log(e, selectedOptions);
      if (selectedOptions.length > 0) {
        this.getRegionOptionsMechanism(
          selectedOptions[selectedOptions.length - 1].id
        );
      }
    },
    //选择机构
    handleOrganizationChange(value) {
      console.log(value);
      this.organizationChange = value;
    },
    //计算百分比
    count(e) {
      e.forEach((item) => {
        let a = Number(item.totalFileSize);
        let b = Number(item.personalSpaceSize);
        let c = Math.round((a / b) * 1000000000000) / 10000000000;
        // let c = a / b;
        console.log(c);
        item.percentage = c;
      });
    },
    //分页
    onChangeUserPage(pageNumber) {
      console.log("Page: ", pageNumber);
      this.userPageNum = pageNumber.current; //当前页数
      this.userPageNumber = pageNumber.pageSize; //当前每页展示条数
      this.userViewQuery();
    },
    //分页
    onChangeFilePage(pageNumber) {
      console.log("Page: ", pageNumber);
      this.userPageNum = pageNumber.current; //当前页数
      this.userPageNumber = pageNumber.pageSize; //当前每页展示条数
      this.fileViewCheck();
    },

    deleteAll(e) {
      let that = this;
      let data = {
        ids: "",
      };
      if (e == "all") {
        //删除全部文件
        if (this.chooseFile.length < 1) {
          this.$message.warning("请选择要删除的文件");
          return;
        }
        that.chooseFile.forEach((item) => {
          data.ids += item.id + ",";
        });
        data.ids = data.ids.substr(0, data.ids.length - 1); //删除最后一个“,”
      } else {
        //删除单个文件
        console.log(e);
        data.ids = e.id;
      }

      axios
        .delete(
          that.HttpServe + "/cloudoffice/fileInfo/batchDeleteFileInfoAndFile",
          {
            headers: {
              "Content-Type": "application/json",
              Authorization: "Bearer " + that.token,
            },
            params: data,
          }
        )
        .then((res) => {
          console.log(res);
          if (res.data.code == 200) {
            that.$message.success("删除成功");
            that.fileViewCheck(); //从新渲染table数据
          } else {
            that.$message.error(res.data.message);
          }
        })
        .catch((error) => {
          console.log(error);
        });
    },
  },
  filters: {
    //字节转换KB
    KBDate(limita) {
      let limit = parseInt(limita);
      if (limit > 0) {
        // console.log("大小" + limit);
        var size = "";
        if (limit < 0.1 * 1024) {
          //如果小于0.1KB转化成B
          let intNum = parseInt(limit);
          size = intNum.toFixed(2) + " B";
        } else if (limit < 0.999 * 1024 * 1024) {
          //如果小于0.1MB转化成KB
          size = (limit / 1024).toFixed(2) + "KB";
        } else if (limit < 0.999 * 1024 * 1024 * 1024) {
          //如果小于0.1GB转化成MB
          size = (limit / (1024 * 1024)).toFixed(2) + "MB";
        } else if (limit < 0.999 * 1024 * 1024 * 1024 * 1024) {
          //其他转化成GB
          size = (limit / (1024 * 1024 * 1024)).toFixed(2) + "G";
        } else {
          size = (limit / (1024 * 1024 * 1024 * 1024)).toFixed(2) + "T";
        }

        var sizestr = size + "";
        var len = sizestr.indexOf(".");
        var dec = sizestr.substr(len + 1, 2);
        if (dec == "00") {
          //当小数点后为00时 去掉小数部分
          return sizestr.substring(0, len) + sizestr.substr(len + 3, 2);
        }
        return sizestr;
      } else {
        return limit;
      }
    },
  },
};
</script>

<style lang="less" scoped>
.fileViewTable {
  position: relative;
  .selectedBox {
    position: absolute;
    bottom: 20px;
  }
}
</style>
