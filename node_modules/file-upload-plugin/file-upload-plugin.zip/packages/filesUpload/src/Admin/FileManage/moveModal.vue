<template>
  <!-- 点击移动分发弹框 -->
  <a-modal
    title="Title"
    :visible.sync="modalVisible"
    @cancel="cancel"
    :width="600"
  >
    <a-tree show-line :default-expanded-keys="['0-0-0']" @select="onSelect">
      <a-icon slot="switcherIcon" type="down" />
      <a-tree-node key="0-0" title="我的资源">
        <a-tree-node key="0-0-3" title="用户" />
        <a-tree-node key="0-0-0" title="资源">
          <a-tree-node key="0-0-0-0" title="leaf" />
          <a-tree-node key="0-0-0-1" title="leaf" />
          <a-tree-node key="0-0-0-2" title="leaf" />
        </a-tree-node>
      </a-tree-node>
    </a-tree>

    <template slot="footer">
      <a-button key="back" @click="cancel">取消</a-button>
      <a-button key="submit" type="primary" @click="sure">确定</a-button>
    </template>
  </a-modal>
</template>

<script>
const treeData = [
  {
    title: "parent 1",
    key: "0-0",
    slots: {
      icon: "smile",
    },
    children: [
      { title: "leaf", key: "0-0-0", slots: { icon: "meh" } },
      { title: "leaf", key: "0-0-1", scopedSlots: { icon: "custom" } },
    ],
  },
];
export default {
  name: "move",
  data() {
    return {
      treeData,
    };
  },
  props: {
    modalVisible: Boolean,
  },
  mounted() {},
  methods: {
    cancel() {
      this.$emit("visible", false);
    },
    sure() {
      this.$emit("visible", false);
    },

    //______________
    onSelect(selectedKeys, info) {
      console.log("selected", selectedKeys, info);
    },
  },
};
</script>

<style lang="" scoped>
</style>
