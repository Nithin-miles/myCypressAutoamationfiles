<template>
  <!-- 点击移动分发弹框 -->
  <a-modal
    title="分发"
    :visible.sync="handOutVisible"
    @cancel="cancel"
    :width="1100"
  >
    <div style="margin-bottom: 30px">
      <a-form-model layout="inline">
        <a-form-model-item label="区域">
          <a-cascader
            v-model="tableForm.region"
            :options="regioOptions"
            placeholder="请选择区域"
            @change="onChange"
          />
        </a-form-model-item>
        <a-form-model-item label="机构部门">
          <a-select
            style="width: 200px"
            placeholder="请选择机构部门"
            v-model="tableForm.organization"
            @change="handleOrganizationChange"
          >
            <a-select-option
              v-for="(item, index) in organization"
              :key="index"
              :value="item.id"
            >
              {{ item.organizationName }}
            </a-select-option>
          </a-select>
        </a-form-model-item>
        <a-form-model-item label="关键字">
          <a-input
            v-model="tableForm.keywords"
            placeholder="输入用户名、姓名搜索"
          />
        </a-form-model-item>
        <a-form-model-item>
          <a-button
            type="primary"
            icon="search"
            @click="search"
            :loading="loading"
            style="margin-right: 15px"
          >
            查询
          </a-button>
          <a-button icon="undo" @click="resetForm"> 重置 </a-button>
        </a-form-model-item>
      </a-form-model>
    </div>

    <a-table
      :columns="columns"
      :data-source="data"
      :row-selection="rowSelection"
      row-key="id"
    >
    </a-table>

    <template slot="footer">
      <a-button key="back" @click="cancel">取消</a-button>
      <a-button key="submit" type="primary" @click="sure">确定</a-button>
    </template>
  </a-modal>
</template>

<script>
import axios from "axios";
import Vue from "vue";
Vue.prototype.$axios = axios;
const columns = [
  {
    dataIndex: "username",
    key: "username",
    title: "用户名",
  },
  {
    dataIndex: "tureName",
    key: "tureName",
    title: "姓名",
  },
  {
    dataIndex: "areaName",
    key: "areaName",
    title: "区域",
  },

  {
    title: "机构",
    dataIndex: "organizationName",
    key: "organizationName",
  },
];

export default {
  name: "hand-out-modal",
  data() {
    return {
      columns,
      data: [],
      //查询表单
      tableForm: {
        region: undefined,
        organization: undefined,
        keywords: "",
      },
      regioOptions: [], //查询区域级联选择
      organization: [], //机构选择框
      organizationChange: "", //选择的机构id
      pageNum: 1, //当前页数
      pageNumber: 10, //用户视角表格的每页条数
      loading: false,
      checkUser: "", //选择分发的用户
    };
  },
  props: {
    handOutVisible: Boolean,
    token: String,
    sendFileID: String,
    HttpServe: String,
  },
  computed: {
    rowSelection() {
      return {
        onChange: (selectedRowKeys, selectedRows) => {
          console.log(
            `selectedRowKeys: ${selectedRowKeys}`,
            "selectedRows: ",
            selectedRows
          );
          if (selectedRows.length > 0) {
            this.checkUser = "";
            selectedRows.forEach((item) => {
              console.log(item.username);
              this.checkUser += item.username + ",";
            });
            this.checkUser = this.checkUser.substr(
              0,
              this.checkUser.length - 1
            ); //删除最后一个“,”
            console.log(this.checkUser, 2211);
          }
        },
        getCheckboxProps: (record) => ({
          props: {
            disabled: record.name === "Disabled User", // Column configuration not to be checked
            name: record.name,
          },
        }),
      };
    },
  },
  created() {
    this.getArea();
  },
  mounted() {},
  methods: {
    cancel() {
      this.$emit("visible", false);
      this.resetForm(); //重置表单
    },
    sure() {
      // this.$emit("visible", false);
      this.sendFile();
    },

    //后台管理查询区域
    getArea() {
      let that = this;
      let data = {};
      axios
        .post(
          that.HttpServe + "/systemportal/sysRegion/selectRegionByUserRole",
          data,
          {
            headers: {
              "Content-Type": "application/json",
              Authorization: "Bearer " + that.token,
            },
          }
        )
        .then((res) => {
          console.log(res, "分发");
          if (res.data.code == 200) {
            that.regioOptions = that.formatData(res.data.data);
            console.log(that.regioOptions);
          }
        })
        .catch((error) => {
          console.log(error);
        });
    },

    //查询机构
    getRegionOptionsMechanism(value) {
      let that = this;
      axios
        .post(
          that.HttpServe +
            "/systemportal/sysOrganization/selectOrganizationByUserRole",
          {
            id: value,
          },
          {
            headers: {
              "Content-Type": "application/json",
              Authorization: "Bearer " + that.token,
            },
          }
        )
        .then((res) => {
          console.log(res, "机构");
          if (res.data.code == 200) {
            that.organization = res.data.data;
          }
        })
        .catch((error) => {
          console.log(error);
        });
    },

    //递归查找区域下一层，如果没有children的话返回underfind
    formatData(data) { 
      const that = this;
      data.forEach((element) => {
        element.value = element.label;
        if (element.children && element.children.length > 0) {
          // console.log(element);
          that.formatData(element.children);
        } else {
           delete element.children
        }
      });
      return data;
    },

    //选择后区域
    onChange(e, selectedOptions) {
      console.log(e, selectedOptions);
      if (e.length > 0) {
        this.getRegionOptionsMechanism(
          selectedOptions[selectedOptions.length - 1].id
        );
      }
    },
    //选择机构
    handleOrganizationChange(value) {
      console.log(value);
      this.organizationChange = value;
    },

    // 查询
    search() {
      let that = this;
      if (!that.tableForm.organization) {
        that.$message.warning("请选择区域和机构");
        return;
      }
      that.loading = true;
      axios
        .get(that.HttpServe + "/systemportal/sysUser/selectSysUserByAdmin", {
          headers: {
            "Content-Type": "application/json",
            Authorization: "Bearer " + that.token,
          },
          params: {
            pageNum: that.userPageNum,
            pageSize: that.userPageNumber,
            organizationId: that.organizationChange,
          },
        })
        .then((res) => {
          console.log(res);
          console.log(that.organizationChange);
          if (res.data.code == 200) {
            that.data = res.data.data;
            that.loading = false;
          }
        })
        .catch((error) => {
          console.log(error);
        });
    },

    //分发文件
    sendFile() {
      let that = this;
      let data = {
        id: that.sendFileID,
        createUser: that.checkUser,
      };

      axios
        .post(
          that.HttpServe +
            "/cloudoffice/fileInfo/distributeFileToPersonalSpace",
          data,
          {
            headers: {
              "Content-Type": "application/json",
              Authorization: "Bearer " + that.token,
            },
          }
        )
        .then((res) => {
          console.log(res);
          if (res.data.code == 200) {
            that.$message.success("分发成功");
          }
        })
        .catch((error) => {
          console.log(error);
        });
    },

    //查询表单重置
    resetForm() {
      // this.$refs['userViewForm'].resetFields()
      this.tableForm = {
        region: undefined,
        organization: undefined,
        keywords: "",
      };
    },
  },
};
</script>

<style lang="" scoped>
</style>
