// 用户视角                       文件视角
/**
 * 用户名                          上传人
 * 上传未引用文件大小               大小
 * 
 * 
 * */
// 用户视角
// 用户视角表格表头
const userViewColumns = [{
        title: '用户名',
        dataIndex: 'trueName',
        width: '10%',
        align: "center"
    },
    {
        title: '部门',
        dataIndex: 'organizationName',
        width: '15%',
        align: "center",
        ellipsis: true

    },
    {
        title: '引用文件空间使用',
        dataIndex: 'referenceFileSpaceUsage',
        align: "center",
        scopedSlots: {
            customRender: 'referenceFileSpaceUsage'
        },

    },
    {
        title: '引用文件数量',
        dataIndex: 'quoteFileCount',
        align: "center"
    },
    {
        title: '上传未引用文件大小',
        dataIndex: 'notQuoteFileSize',
        align: "center",
        scopedSlots: {
            customRender: 'notQuoteFileSize'
        },

    }, {
        title: '上传未引用文件数量',
        dataIndex: 'notQuoteFileCount',
        align: "center"

    },
    {
        title: '操作',
        dataIndex: 'userViewAction',
        align: "center",
        scopedSlots: {
            customRender: 'userViewAction'
        },
    },
];
// 用户视角表格 假数据
const userViewData = [];
for (let i = 0; i < 100; i++) {
    userViewData.push({
        key: i.toString(),
        userViewName: `刘思鉴${i}`,
        userViewDepartment: "文娱部门hao",
        referenceFileSpaceUsage: "1G/20G",
        referenceFileQuantity: 23,
        UploadUnreferenceFileSize: "230MB",
        UploadUnreferenceFileQuantity: 12
    });
}
// 用户视角查询区域级联选择
const regioOptions = [{
        value: 'zhejiang',
        label: 'Zhejiang',
        children: [{
            value: 'hangzhou',
            label: 'Hangzhou',
            children: [{
                value: 'xihu',
                label: 'West Lake',
            }, ],
        }, ],
    },
    {
        value: 'jiangsu',
        label: 'Jiangsu',
        children: [{
            value: 'nanjing',
            label: 'Nanjing',
            children: [{
                value: 'zhonghuamen',
                label: 'Zhong Hua Men',
            }, ],
        }, ],
    },
]

// 文件视角
const fileViewColumns = [{
        title: '文件名',
        dataIndex: 'originalName',
        align: "center"
    },
    {
        title: '类型',
        dataIndex: 'fileType',
        width: '5%',
        align: "center"
    },
    {
        title: '状态',
        dataIndex: 'fileState', // 0正常 1上传中 2 失败
        width: '10%',
        scopedSlots: { customRender: 'fileState' },
        align: "center"
    },
    {
        title: '大小',
        dataIndex: 'fileSize',
        width: '8%',
        scopedSlots: { customRender: 'fileSize' },
        align: "center"
    },
    {
        title: '路径',
        dataIndex: 'fileAbsolutePath',
        width: '15%',
        align: "center"
    },
    {
        title: '更新日期',
        dataIndex: 'fileUploadTime',
        align: "center"
    },
    {
        title: '上传人',
        dataIndex: 'createUser',
        align: "center"
    },
    {
        title: '引用人',
        dataIndex: 'referenceUsers',
        align: "center"
    },
    {
        title: '引用功能',
        dataIndex: 'referenceApplicationTypes',
        align: "center"
    },
    {
        title: '操作',
        dataIndex: 'fileAction',
        scopedSlots: { customRender: 'fileAction' },
        align: "right",
        width: '15%',
    },
]

const fileViewData = []
for (let i = 0; i < 2; i++) {
    fileViewData.push({
        key: i.toString(),
        filename: `我是文件${i}`,
        fileType: "pdf",
        fileState: 0,
        fileSize: "230MB",
        filePath: "/x/xx",
        fileUpdateDate: "2012-02-23",
        fileUploader: `桃todd${i}`,
        fileReferencer: "阿花，阿茂，阿峰",
        fileReferenceFunction: "帮助中心",
    });
}
for (let i = 0; i < 2; i++) {
    fileViewData.push({
        key: i.toString() + 2,
        filename: `我是文件${i}`,
        fileType: "pdf",
        fileState: 1,
        fileSize: "230MB",
        filePath: "/x/xx",
        fileUpdateDate: "2012-02-23",
        fileUploader: `桃子${i}`,
        fileReferencer: "阿花，阿茂，阿峰",
        fileReferenceFunction: "帮助中心",
    });
}
for (let i = 0; i < 2; i++) {
    fileViewData.push({
        key: i.toString() + 4,
        filename: `我是文件${i}`,
        fileType: "pdf",
        fileState: 2,
        fileSize: "230MB",
        filePath: "/x/xx",
        fileUpdateDate: "2012-02-23",
        fileUploader: `桃todd${i}`,
        fileReferencer: "阿花，阿茂，阿峰",
        fileReferenceFunction: "帮助中心",
    });
}
export {
    userViewColumns,
    userViewData,
    regioOptions,
    fileViewColumns,
    fileViewData

}