// const token = "f0f3150d-37fe-4802-8958-6134f4fa3887";//机构管理员
const token = "d35a5b03-1ad0-42f0-84ea-dabdb9b7cd80"; //超级管理员
const localHttp = "http://192.168.19.28:8089";
const HttpServe = "http://192.168.19.29:6001";
export {
    token,
    localHttp,
    HttpServe,
}