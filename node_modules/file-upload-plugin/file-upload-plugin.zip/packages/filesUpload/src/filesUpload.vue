<template>
  <!-- 
 文件列表
 -->
  <div>
    <a-layout class="filesUpload" :style="height()">
      <a-layout-sider
        v-model="collapsed"
        :collapsedWidth="0"
        style="height: auto"
      >
        <div class="treeContainer">
          <a-tree
            :tree-data="treeData"
            show-icon
            :default-selected-keys="['0-1']"
            @expand="navOnExpand"
            @select="navOnSelect"
          >
            <a-icon slot="switcherIcon" type="down" />
            <a-icon slot="folder" type="folder" />
            <a-icon slot="file" type="file" />
            <template slot="custom" slot-scope="{ selected }">
              <a-icon :type="selected ? 'frown' : 'frown-o'" />
            </template>
          </a-tree>
        </div>
        <div class="space" v-if="!collapsed">
          <span class="text">我的空间</span>
          <a-progress
            :stroke-color="{
              from: '#108ee9',

              to: '#87d068',
            }"
            :percent="mySpace.percentum"
            status="active"
            ><br />
            <template #format="percent">
              <span
                >{{ mySpace.totalFileSize | KBDate(mySpace.totalFileSize) }}/{{
                  mySpace.personalSpaceSize | KBDate(mySpace.personalSpaceSize)
                }}</span
              >
            </template>
          </a-progress>
        </div>
      </a-layout-sider>
      <!-- 正常表格信息展示 -->
      <a-layout class="box_left" v-if="selectPageKey != '0-4-3'">
        <a-layout-header class="toolbar">
          <a-row>
            <a-col
              :span="11"
              :xxl="18"
              :xl="16"
              :lg="16"
              :md="12"
              style="display: flex; align-items: center"
            >
              <a-button
                type="link"
                @click="filesUploadModal"
                v-show="config.upload"
              >
                <a-icon type="upload" :style="{ color: '#108ee9' }" /> 上传
              </a-button>
              <a-button
                type="link"
                class="visible-lg-inline"
                @click="folderVisibleClick()"
              >
                <a-icon type="folder-add" :style="{ color: '#fa8c16' }" />
                新建文件夹
              </a-button>
              <a-button type="link">
                <a-icon type="download" :style="{ color: '#87d068' }" /> 下载
              </a-button>
              <a-button
                type="link"
                class="visible-lg-inline"
                @click="shareModal('all')"
              >
                <a-icon type="share-alt" :style="{ color: '#108ee9' }" /> 分享
              </a-button>
              <a-button type="link" @click="deleteContent('deleteAll')">
                <a-icon type="delete" :style="{ color: '#f50' }" /> 删除
              </a-button>
              <a-button
                type="link"
                class="visible-lg-inline"
                @click="showRouteModal('copy')"
              >
                <a-icon type="copy" :style="{ color: '#108ee9' }" /> 复制到
              </a-button>
              <a-button
                type="link"
                class="visible-lg-inline"
                @click="showRouteModal('move')"
              >
                <a-icon type="drag" :style="{ color: '#108ee9' }" /> 移动到
              </a-button>

              <a-dropdown :trigger="['click']" :placement="'bottomCenter'">
                <a class="ant-dropdown-link" @click="(e) => e.preventDefault()">
                  <a-button type="link">
                    <a-icon type="ellipsis" :style="{ color: '#108ee9' }" />
                    更多
                  </a-button>
                </a>
                <a-menu slot="overlay">
                  <a-menu-item>
                    <a href="javascript:;" @click="shareModal('all')">分享</a>
                  </a-menu-item>
                  <a-menu-item>
                    <a href="javascript:;" @click="showRouteModal('copy')"
                      >复制到</a
                    >
                  </a-menu-item>
                  <!-- <a-menu-item>
                    <a href="javasc ript:;">复制</a>
                  </a-menu-item>
                  <a-menu-item>
                    <a href="javascript:;">复制</a>
                  </a-menu-item>
                  <a-menu-item>
                    <a href="javascript:;">剪切</a>
                  </a-menu-item> -->
                  <a-menu-item @click="allCollect">
                    <a href="javascript:;">添加到收藏夹</a>
                  </a-menu-item>
                  <!-- <a-menu-item>
                    <a href="javascript:;">收藏</a>
                  </a-menu-item> -->
                </a-menu>
              </a-dropdown>
              <a-button
                type="primary"
                class="visible-lg-inline"
                @click="showAdmin"
              >
                管理后台
              </a-button>
            </a-col>
            <a-col
              class="searchRight"
              :span="8"
              :xxl="6"
              :xl="8"
              :lg="8"
              :md="12"
            >
              <a-input-group compact class="toolbar-input-search">
                <a-input
                  style="width: 70%"
                  v-model="searchForm.search"
                  placeholder="请输入关键字搜索"
                />
                <a-button-group style="width: 28%; text-align: left">
                  <a-dropdown :trigger="['click']" :placement="'bottomCenter'">
                    <a
                      class="ant-dropdown-link"
                      @click="(e) => e.preventDefault()"
                    >
                      <a-button type="primary">
                        <a-icon type="down" />
                      </a-button>
                    </a>
                    <a-menu slot="overlay" class="searchModal">
                      <a-form-model
                        :model="searchForm"
                        :label-col="{ span: 7 }"
                        :wrapper-col="{ span: 14 }"
                      >
                        <a-form-model-item label="搜索范围">
                          <a-radio-group
                            button-style="solid"
                            v-model="searchForm.scope"
                          >
                            <a-radio-button value="all">
                              全部文件夹
                            </a-radio-button>
                            <a-radio-button value="current">
                              当前文件夹
                            </a-radio-button>
                          </a-radio-group>

                          <div style="line-height: 20px; color: #ccc">
                            {{
                              searchForm.scope == "all"
                                ? "搜索根目录"
                                : "搜索当前目录"
                            }}
                          </div>
                        </a-form-model-item>
                        <a-form-model-item label="文件类型">
                          <a-select
                            default-value="all"
                            @change="searchFormTypeChange"
                            v-model="searchForm.fileType"
                          >
                            <a-select-option value="all">
                              不限类型
                            </a-select-option>
                            <a-select-option value="png"> png </a-select-option>
                            <a-select-option value="txt"> txt </a-select-option>
                          </a-select>
                        </a-form-model-item>
                        <a-form-model-item label="时间范围">
                          <a-range-picker
                            :ranges="dataRange"
                            @change="onChangeTime"
                          >
                          </a-range-picker>
                        </a-form-model-item>
                        <a-form-model-item label="文件大小">
                          <a-select
                            default-value="all"
                            placeholder="请选择文件大小"
                            @change="searchFormSizeChange"
                            v-model="searchForm.fileSize"
                          >
                            <a-select-option value="all">
                              不限大小
                            </a-select-option>
                            <a-select-option value="0~100KB">
                              0~100KB
                            </a-select-option>
                            <a-select-option value="100KB~1MB">
                              100KB~1MB
                            </a-select-option>
                            <a-select-option value="1MB~10MB">
                              1MB~10MB
                            </a-select-option>
                            <a-select-option value="10MB~100MB">
                              10MB~100MB
                            </a-select-option>
                            <a-select-option value="100MB~1GB">
                              100MB~1GB
                            </a-select-option>
                            <a-select-option value="1GB以上">
                              1GB以上
                            </a-select-option>
                          </a-select>
                        </a-form-model-item>
                        <a-form-model-item label="是否已共享">
                          <a-radio-group v-model="searchForm.share">
                            <a-radio value="1"> 全部 </a-radio>
                            <a-radio value="2"> 是 </a-radio>
                            <a-radio value="3"> 否 </a-radio>
                          </a-radio-group>
                        </a-form-model-item>
                        <a-form-model-item label="是否已引用">
                          <a-radio-group v-model="searchForm.quote">
                            <a-radio value="1"> 全部 </a-radio>
                            <a-radio value="2"> 是 </a-radio>
                            <a-radio value="3"> 否 </a-radio>
                          </a-radio-group>
                        </a-form-model-item>
                        <a-form-model-item label="是否已发布">
                          <a-radio-group v-model="searchForm.cloudPortal">
                            <a-radio value="1"> 全部 </a-radio>
                            <a-radio value="2"> 是 </a-radio>
                            <a-radio value="3"> 否 </a-radio>
                          </a-radio-group>
                        </a-form-model-item>
                        <!-- <a-form-model-item> -->
                        <div class="footButton">
                          <a-button type="primary" @click="searchFile">
                            搜索
                          </a-button>
                          <a-button
                            style="margin-left: 10px"
                            @click="resetSearchFile"
                          >
                            重置
                          </a-button>
                        </div>
                        <!-- </a-form-model-item> -->
                      </a-form-model>
                    </a-menu>
                  </a-dropdown>
                  <a-button type="primary" @click="searchFile">
                    <a-icon type="search" />
                  </a-button>
                </a-button-group>
              </a-input-group>
            </a-col>
          </a-row>
        </a-layout-header>
        <a-layout-header class="breadcrumb">
          <a-row>
            <a-col
              :span="19"
              :xxl="18"
              :xl="18"
              :lg="16"
              :md="15"
              class="breadcrumb_left"
            >
              <a-button type="link" @click="backPage">
                <a-icon type="undo" />
                <span class="visible-lg-inline">返回上一层</span>
              </a-button>
              <a-button type="link" @click="refresh">
                <a-icon type="sync" />
                <span class="visible-lg-inline">刷新</span>
              </a-button>
              <a-divider type="vertical" />
              <a-breadcrumb separator=">">
                <a-breadcrumb-item
                  v-for="(item, index) in fileNavigation"
                  :key="index"
                >
                  {{ item }}
                </a-breadcrumb-item>
              </a-breadcrumb>
            </a-col>
            <a-col
              :span="4"
              :xxl="6"
              :xl="6"
              :lg="8"
              :md="9"
              class="breadcrumb_right"
            >
              已选中{{ this.shareData.length }}个文件/文件夹
              <a-dropdown :trigger="['click']" :placement="'bottomCenter'">
                <a class="ant-dropdown-link" @click="(e) => e.preventDefault()">
                  <a-button type="link">
                    <a-icon type="ordered-list" />
                  </a-button>
                </a>
                <a-menu slot="overlay">
                  <a-menu-item>
                    <a href="javascript:;">名称</a>
                  </a-menu-item>
                  <a-menu-item>
                    <a href="javascript:;">修改时间</a>
                  </a-menu-item>
                  <a-menu-item>
                    <a href="javascript:;">类型</a>
                  </a-menu-item>
                  <a-menu-item>
                    <a href="javascript:;">大小</a>
                  </a-menu-item>
                </a-menu>
              </a-dropdown>
              <a-radio-group
                v-model="mode"
                :style="{ marginBottom: '8px' }"
                button-style="solid"
                @change="handleSizeChange"
              >
                <a-radio-button value="table">
                  <a-icon type="bars" />
                </a-radio-button>
                <a-radio-button value="list">
                  <a-icon type="appstore" />
                </a-radio-button>
              </a-radio-group>
            </a-col>
          </a-row>
        </a-layout-header>
        <a-layout-content>
          <div class="file-table" v-if="mode == 'table'">
            <!-- :scroll="{ y: tableHeight } -->
            <a-table
              align="left"
              class="tableBoxComponents"
              :customRow="dblclickFileName"
              :row-selection="{
                selectedRowKeys: selectedRowKeys,
                onChange: onSelectChange,
              }"
              :columns="FileListColumns"
              :data-source="FileListData"
              :pagination="false"
              row-key="id"
            >
              <template slot="fileName" slot-scope="text, record">
                <div
                  style="
                    display: flex;
                    align-items: baseline;
                    justify-content: space-between;
                  "
                >
                  <span>
                    <!-- <a-icon :type="record.type" /> -->
                    <svg
                      class="icon"
                      aria-hidden="true"
                      style="vertical-align: middle"
                    >
                      <use :xlink:href="'#icon-' + record.type"></use>
                    </svg>

                    <span v-if="record.fileType == 'folder'">
                      <a style="cursor: pointer">
                        <img
                          src="../../assets/fileIcon/icon-big-folder.png"
                          style="max-width: 30px"
                        />
                        <span>{{ record.fileName }}</span>
                      </a>
                    </span>

                    <span
                      v-else-if="
                        record.fileType == 'jpg' ||
                        record.fileType == 'png' ||
                        record.fileType == 'jpeg' ||
                        record.fileType == 'gif' ||
                        record.fileType == 'bmp' ||
                        record.fileType == 'dxf' ||
                        record.fileType == 'bip'
                      "
                    >
                      <a style="cursor: pointer">
                        <img
                          src="../../assets/fileIcon/tupian.png"
                          style="max-width: 30px"
                        />
                        <span>{{ record.fileName }}</span>
                      </a>
                    </span>
                    <span
                      v-else-if="
                        record.fileType == 'zip' || record.fileType == 'rar'
                      "
                    >
                      <a style="cursor: pointer">
                        <img
                          src="../../assets/fileIcon/zipRar.png"
                          style="max-width: 30px"
                        />
                        <span>{{ record.fileName }}</span>
                      </a>
                    </span>
                    <span
                      v-else-if="
                        record.fileType == 'cda' ||
                        record.fileType == 'wav' ||
                        record.fileType == 'aif' ||
                        record.fileType == 'au' ||
                        record.fileType == 'mp3' ||
                        record.fileType == 'wma' ||
                        record.fileType == 'mmf' ||
                        record.fileType == 'amr' ||
                        record.fileType == 'aac' ||
                        record.fileType == 'flac'
                      "
                    >
                      <a style="cursor: pointer">
                        <img
                          src="../../assets/fileIcon/yinpin.png"
                          style="max-width: 30px"
                        />
                        <span>{{ record.fileName }}</span>
                      </a>
                    </span>
                    <span
                      v-else-if="
                        record.fileType == 'avi' ||
                        record.fileType == 'wmv' ||
                        record.fileType == 'mpg' ||
                        record.fileType == 'mov' ||
                        record.fileType == 'rm' ||
                        record.fileType == 'ram' ||
                        record.fileType == 'swf' ||
                        record.fileType == 'flv' ||
                        record.fileType == 'mp4'
                      "
                    >
                      <a style="cursor: pointer">
                        <img
                          src="../../assets/fileIcon/shipin.png"
                          style="max-width: 30px"
                        />
                        <span>{{ record.fileName }}</span>
                      </a>
                    </span>
                    <span
                      v-else-if="
                        record.fileType == 'docx' || record.fileType == 'doc'
                      "
                    >
                      <a style="cursor: pointer">
                        <img
                          src="../../assets/fileIcon/word.png"
                          style="max-width: 30px"
                        />
                        <span>{{ record.fileName }}</span>
                      </a>
                    </span>
                    <span
                      v-else-if="
                        record.fileType == 'xlsx' || record.fileType == 'xls'
                      "
                    >
                      <a style="cursor: pointer">
                        <img
                          src="../../assets/fileIcon/xlsx.png"
                          style="max-width: 30px"
                        />
                        <span>{{ record.fileName }}</span>
                      </a>
                    </span>
                    <span
                      v-else-if="
                        record.fileType == 'ppt' || record.fileType == 'pptx'
                      "
                    >
                      <a style="cursor: pointer">
                        <img
                          src="../../assets/fileIcon/ppt.png"
                          style="max-width: 30px"
                        />
                        <span>{{ record.fileName }}</span>
                      </a>
                    </span>
                    <span v-else-if="record.fileType == 'pdf'">
                      <a style="cursor: pointer">
                        <img
                          src="../../assets/fileIcon/pdf.png"
                          style="max-width: 30px"
                        />
                        <span>{{ record.fileName }}</span>
                      </a>
                    </span>
                    <span v-else-if="record.fileType == 'txt'">
                      <a style="cursor: pointer">
                        <img
                          src="../../assets/fileIcon/txt.png"
                          style="max-width: 30px"
                        />
                        <span>{{ record.fileName }}</span>
                      </a>
                    </span>
                    <span v-else-if="record.fileType == 'txt'">
                      <a style="cursor: pointer">
                        <img
                          src="../../assets/fileIcon/txt.png"
                          style="max-width: 30px"
                        />
                        <span>{{ record.fileName }}</span>
                      </a>
                    </span>
                    <span v-else-if="record.fileType == 'csv'">
                      <a style="cursor: pointer">
                        <img
                          src="../../assets/fileIcon/csv.png"
                          style="max-width: 30px"
                        />
                        <span>{{ record.fileName }}</span>
                      </a>
                    </span>
                    <span
                      v-else-if="
                        record.fileType == 'mdb' ||
                        record.fileType == 'dbf' ||
                        record.fileType == 'mdf' ||
                        record.fileType == 'db' ||
                        record.fileType == 'wdb'
                      "
                    >
                      <a style="cursor: pointer">
                        <img
                          src="../../assets/fileIcon/shujvku.png"
                          style="max-width: 30px"
                        />
                        <span>{{ record.fileName }}</span>
                      </a>
                    </span>
                    <span
                      v-else-if="
                        record.fileType == 'shp' ||
                        record.fileType == 'shx' ||
                        record.fileType == 'dbf' ||
                        record.fileType == 'prj' ||
                        record.fileType == 'sbn' ||
                        record.fileType == 'sbx' ||
                        record.fileType == 'sbn' ||
                        record.fileType == 'fbn' ||
                        record.fileType == 'fbx' ||
                        record.fileType == 'ain' ||
                        record.fileType == 'ixs' ||
                        record.fileType == 'mxs' ||
                        record.fileType == 'atx' ||
                        record.fileType == 'cpg'
                      "
                    >
                      <a style="cursor: pointer">
                        <img
                          src="../../assets/fileIcon/shapefile.png"
                          style="max-width: 30px"
                        />
                        <span>{{ record.fileName }}</span>
                      </a>
                    </span>

                    <span v-else-if="record.fileType == 'sde'">
                      <a style="cursor: pointer">
                        <img
                          src="../../assets/fileIcon/kongjianshujv.png"
                          style="max-width: 30px"
                        />
                        <span>{{ record.fileName }}</span>
                      </a>
                    </span>
                    <span v-else-if="record.fileType == 'tif'">
                      <a style="cursor: pointer">
                        <img
                          src="../../assets/fileIcon/tuxiandili.png"
                          style="max-width: 30px"
                        />
                        <span>{{ record.fileName }}</span>
                      </a>
                    </span>
                    <span v-else-if="record.fileType == 'img'">
                      <a style="cursor: pointer">
                        <img
                          src="../../assets/fileIcon/img.png"
                          style="max-width: 30px"
                        />
                        <span>{{ record.fileName }}</span>
                      </a>
                    </span>
                    <span v-else-if="record.fileType == 'mxd'">
                      <a style="cursor: pointer">
                        <img
                          src="../../assets/fileIcon/mxd.png"
                          style="max-width: 30px"
                        />
                        <span>{{ record.fileName }}</span>
                      </a>
                    </span>

                    <span v-else>
                      <a style="cursor: pointer">
                        <img
                          src="../../assets/fileIcon/qita.png"
                          style="max-width: 30px"
                        />
                        <span>{{ record.fileName }}</span>
                      </a>
                    </span>

                    <!-- <span> {{ record.fileName }}</span> -->
                  </span>
                  <span>
                    <a-icon
                      @click="ChangeCollection(record)"
                      type="star"
                      theme="filled"
                      class="wfm-file-icon"
                      :style="
                        record.fileCollectId ? { color: 'gold' } : { color: '' }
                      "
                    />
                    <!-- <a-icon
                      @click="tableCollection(record)"
                      v-else
                      type="star"
                      class="wfm-file-icon"
                    /> -->
                    <a-icon type="download" class="wfm-file-icon" />

                    <a-dropdown
                      :trigger="['click']"
                      :placement="'bottomCenter'"
                    >
                      <a
                        class="ant-dropdown-link"
                        @click="(e) => e.preventDefault()"
                      >
                        <a-icon type="ellipsis" class="wfm-file-icon" />
                      </a>
                      <a-menu slot="overlay">
                        <a-menu-item @click="openFile(record)">
                          <a href="javascript:;">打开</a>
                        </a-menu-item>
                        <a-menu-item>
                          <a href="javascript:;">下载</a>
                        </a-menu-item>
                        <a-menu-item>
                          <a
                            href="javascript:;"
                            @click="shareModal('one', record)"
                            >分享</a
                          >
                        </a-menu-item>
                        <!-- <a-menu-item>
                          <a href="javascript:;">复制</a>
                        </a-menu-item>
                        <a-menu-item>
                          <a href="javascript:;">剪切</a>
                        </a-menu-item> -->
                        <a-menu-item @click="rename(record)">
                          <a href="javascript:;">重命名</a>
                        </a-menu-item>
                        <a-menu-item @click="deleteFile(record)">
                          <a href="javascript:;">删除</a>
                        </a-menu-item>
                        <a-menu-item>
                          <a
                            href="javascript:;"
                            @click="showRouteModal('copy', record)"
                            >复制到</a
                          >
                        </a-menu-item>
                        <a-menu-item>
                          <a
                            href="javascript:;"
                            @click="showRouteModal('move', record)"
                            >移动到</a
                          >
                        </a-menu-item>
                        <a-menu-item>
                          <a href="javascript:;">添加到收藏夹</a>
                        </a-menu-item>
                        <a-menu-item>
                          <a
                            href="javascript:;"
                            @click="attributeFileList(record)"
                            >属性</a
                          >
                        </a-menu-item>
                      </a-menu>
                    </a-dropdown>
                  </span>
                </div>
              </template>
              <template slot="fileStorage" slot-scope="text">
                <!-- <div>{{text}}</div>  -->
                <span>
                  {{ text | KBDate(text) }}
                </span>
              </template>
              <template slot="cloudPortal" slot-scope="text">
                <span>
                  {{ text == "1" ? "是" : "否" }}
                </span>
              </template>
              <template slot="quote" slot-scope="text">
                <span>
                  {{ text == "1" ? "是" : "否" }}
                </span>
              </template>
              <template slot="share" slot-scope="text">
                <span>
                  {{ text == "1" ? "是" : "否" }}
                </span>
              </template>
            </a-table>
          </div>
          <div class="file-list" v-if="mode == 'list'">
            <a-checkbox-group
              @change="onChangeCheckbox"
              :default-value="shareData"
              style="width: 100%"
            >
              <a-list
                class="listBoxComponents"
                :grid="{
                  gutter: 19,
                  xs: 4,
                  sm: 4,
                  md: 4,
                  lg: 4,
                  xl: 6,
                  xxl: 6,
                }"
                :data-source="FileListData"
                :pagination="false"
                size="small"
              >
                <a-list-item
                  class="listFileBox"
                  slot="renderItem"
                  slot-scope="item, index"
                  @mousemove="local($event, item, index)"
                  @mouseleave="leaveLocal"
                  @dblclick="dblclickFileList(item, index)"
                >
                  <!-- -------------------------- -->
                  <!-- <a-popover title="Title" placement="bottomLeft">
                    <template slot="content">@dblclick="dblclickFileName(item, index)"
                      <p>Content</p>
                      <p>Content</p>
                    </template> -->
                  <div class="list-content">
                    <div class="list-menu" v-if="true">
                      <div class="list-checkbox">
                        <a-checkbox :value="item" />
                      </div>
                      <div class="list-iconbox" v-show="listCard.id == index">
                        <!-- <a-icon type="star" theme="filled" :class="{'activeStar': isActive}"  /> -->
                        <!-- <i
                          @click="changeStar(index)"
                          :class="[isActive == index ? 'activeStar' : '']"
                        >
                          <a-icon type="star" theme="filled" />
                        </i> -->
                        <a-icon
                          @click="ChangeCollection(item)"
                          type="star"
                          theme="filled"
                          class="wfm-file-icon"
                          :style="
                            item.fileCollectId
                              ? { color: 'gold' }
                              : { color: '' }
                          "
                        />
                        <a-icon type="download" />
                        <a-dropdown
                          :trigger="['click']"
                          :placement="'bottomCenter'"
                        >
                          <a
                            class="ant-dropdown-link"
                            @click="(e) => e.preventDefault()"
                          >
                            <a-icon type="ellipsis" />
                          </a>
                          <a-menu slot="overlay">
                            <a-menu-item @click="openFile(item)">
                              <a href="javascript:;">打开</a>
                            </a-menu-item>
                            <a-menu-item>
                              <a href="javascript:;">下载</a>
                            </a-menu-item>
                            <a-menu-item>
                              <a
                                href="javascript:;"
                                @click="shareModal('one', item)"
                                >分享</a
                              >
                            </a-menu-item>
                            <!-- <a-menu-item>
                              <a href="javascript:;">复制</a>
                            </a-menu-item>
                            <a-menu-item>
                              <a href="javascript:;">剪切</a>
                            </a-menu-item> -->
                            <a-menu-item @click="rename(item)">
                              <a href="javascript:;">重命名</a>
                            </a-menu-item>
                            <a-menu-item @click="deleteFile(item)">
                              <a href="javascript:;">删除</a>
                            </a-menu-item>
                            <a-menu-item>
                              <a
                                href="javascript:;"
                                @click="showRouteModal('copy', item)"
                                >复制到</a
                              >
                            </a-menu-item>
                            <a-menu-item>
                              <a
                                href="javascript:;"
                                @click="showRouteModal('move', item)"
                                >移动到</a
                              >
                            </a-menu-item>
                            <a-menu-item>
                              <a href="javascript:;">添加到收藏夹</a>
                            </a-menu-item>
                            <a-menu-item>
                              <a
                                href="javascript:;"
                                @click="attributeFileList(item)"
                                >属性</a
                              >
                            </a-menu-item>
                          </a-menu>
                        </a-dropdown>
                      </div>
                    </div>

                    <span v-if="item.fileType == 'folder'">
                      <a style="cursor: pointer">
                        <img
                          class="imgFile"
                          src="../../assets/fileIcon/icon-big-folder.png"
                        />
                        <span class="fileListImg">{{ item.fileName }}</span>
                      </a>
                    </span>

                    <span
                      v-else-if="
                        item.fileType == 'jpg' ||
                        item.fileType == 'png' ||
                        item.fileType == 'jpeg' ||
                        item.fileType == 'gif' ||
                        item.fileType == 'bmp' ||
                        item.fileType == 'dxf' ||
                        item.fileType == 'bip'
                      "
                    >
                      <a style="cursor: pointer">
                        <img
                          class="imgFile"
                          src="../../assets/fileIcon/tupian.png"
                        />
                        <span class="fileListImg">{{ item.fileName }}</span>
                      </a>
                    </span>
                    <span
                      v-else-if="
                        item.fileType == 'zip' || item.fileType == 'rar'
                      "
                    >
                      <a style="cursor: pointer">
                        <img
                          class="imgFile"
                          src="../../assets/fileIcon/zipRar.png"
                        />
                        <span class="fileListImg">{{ item.fileName }}</span>
                      </a>
                    </span>
                    <span
                      v-else-if="
                        item.fileType == 'cda' ||
                        item.fileType == 'wav' ||
                        item.fileType == 'aif' ||
                        item.fileType == 'au' ||
                        item.fileType == 'mp3' ||
                        item.fileType == 'wma' ||
                        item.fileType == 'mmf' ||
                        item.fileType == 'amr' ||
                        item.fileType == 'aac' ||
                        item.fileType == 'flac'
                      "
                    >
                      <a style="cursor: pointer">
                        <img
                          class="imgFile"
                          src="../../assets/fileIcon/yinpin.png"
                        />
                        <span class="fileListImg">{{ item.fileName }}</span>
                      </a>
                    </span>
                    <span
                      v-else-if="
                        item.fileType == 'avi' ||
                        item.fileType == 'wmv' ||
                        item.fileType == 'mpg' ||
                        item.fileType == 'mov' ||
                        item.fileType == 'rm' ||
                        item.fileType == 'ram' ||
                        item.fileType == 'swf' ||
                        item.fileType == 'flv' ||
                        item.fileType == 'mp4'
                      "
                    >
                      <a style="cursor: pointer">
                        <img
                          class="imgFile"
                          src="../../assets/fileIcon/shipin.png"
                        />
                        <span class="fileListImg">{{ item.fileName }}</span>
                      </a>
                    </span>
                    <span
                      v-else-if="
                        item.fileType == 'docx' || item.fileType == 'doc'
                      "
                    >
                      <a style="cursor: pointer">
                        <img
                          class="imgFile"
                          src="../../assets/fileIcon/word.png"
                        />
                        <span class="fileListImg">{{ item.fileName }}</span>
                      </a>
                    </span>
                    <span
                      v-else-if="
                        item.fileType == 'xlsx' || item.fileType == 'xls'
                      "
                    >
                      <a style="cursor: pointer">
                        <img
                          class="imgFile"
                          src="../../assets/fileIcon/xlsx.png"
                        />
                        <span class="fileListImg">{{ item.fileName }}</span>
                      </a>
                    </span>
                    <span
                      v-else-if="
                        item.fileType == 'ppt' || item.fileType == 'pptx'
                      "
                    >
                      <a style="cursor: pointer">
                        <img
                          class="imgFile"
                          src="../../assets/fileIcon/ppt.png"
                        />
                        <span class="fileListImg">{{ item.fileName }}</span>
                      </a>
                    </span>
                    <span v-else-if="item.fileType == 'pdf'">
                      <a style="cursor: pointer">
                        <img
                          class="imgFile"
                          src="../../assets/fileIcon/pdf.png"
                        />
                        <span class="fileListImg">{{ item.fileName }}</span>
                      </a>
                    </span>
                    <span v-else-if="item.fileType == 'txt'">
                      <a style="cursor: pointer">
                        <img
                          class="imgFile"
                          src="../../assets/fileIcon/txt.png"
                        />
                        <span class="fileListImg">{{ item.fileName }}</span>
                      </a>
                    </span>
                    <span v-else-if="item.fileType == 'txt'">
                      <a style="cursor: pointer">
                        <img
                          class="imgFile"
                          src="../../assets/fileIcon/txt.png"
                        />
                        <span class="fileListImg">{{ item.fileName }}</span>
                      </a>
                    </span>
                    <span v-else-if="item.fileType == 'csv'">
                      <a style="cursor: pointer">
                        <img
                          class="imgFile"
                          src="../../assets/fileIcon/csv.png"
                        />
                        <span class="fileListImg">{{ item.fileName }}</span>
                      </a>
                    </span>
                    <span
                      v-else-if="
                        item.fileType == 'mdb' ||
                        item.fileType == 'dbf' ||
                        item.fileType == 'mdf' ||
                        item.fileType == 'db' ||
                        item.fileType == 'wdb'
                      "
                    >
                      <a style="cursor: pointer">
                        <img
                          class="imgFile"
                          src="../../assets/fileIcon/shujvku.png"
                        />
                        <span class="fileListImg">{{ item.fileName }}</span>
                      </a>
                    </span>
                    <span
                      v-else-if="
                        item.fileType == 'shp' ||
                        item.fileType == 'shx' ||
                        item.fileType == 'dbf' ||
                        item.fileType == 'prj' ||
                        item.fileType == 'sbn' ||
                        item.fileType == 'sbx' ||
                        item.fileType == 'sbn' ||
                        item.fileType == 'fbn' ||
                        item.fileType == 'fbx' ||
                        item.fileType == 'ain' ||
                        item.fileType == 'ixs' ||
                        item.fileType == 'mxs' ||
                        item.fileType == 'atx' ||
                        item.fileType == 'cpg'
                      "
                    >
                      <a style="cursor: pointer">
                        <img
                          class="imgFile"
                          src="../../assets/fileIcon/shapefile.png"
                        />
                        <span class="fileListImg">{{ item.fileName }}</span>
                      </a>
                    </span>

                    <span v-else-if="item.fileType == 'sde'">
                      <a style="cursor: pointer">
                        <img
                          class="imgFile"
                          src="../../assets/fileIcon/kongjianshujv.png"
                        />
                        <span class="fileListImg">{{ item.fileName }}</span>
                      </a>
                    </span>
                    <span v-else-if="item.fileType == 'tif'">
                      <a style="cursor: pointer">
                        <img
                          class="imgFile"
                          src="../../assets/fileIcon/tuxiandili.png"
                        />
                        <span class="fileListImg">{{ item.fileName }}</span>
                      </a>
                    </span>
                    <span v-else-if="item.fileType == 'img'">
                      <a style="cursor: pointer">
                        <img
                          class="imgFile"
                          src="../../assets/fileIcon/img.png"
                        />
                        <span class="fileListImg">{{ item.fileName }}</span>
                      </a>
                    </span>
                    <span v-else-if="item.fileType == 'mxd'">
                      <a style="cursor: pointer">
                        <img
                          class="imgFile"
                          src="../../assets/fileIcon/mxd.png"
                        />
                        <span class="fileListImg">{{ item.fileName }}</span>
                      </a>
                    </span>

                    <span v-else>
                      <a style="cursor: pointer">
                        <img
                          class="imgFile"
                          src="../../assets/fileIcon/qita.png"
                        />
                        <span class="fileListImg">{{ item.fileName }}</span>
                      </a>
                    </span>
                    <p>
                      {{ item.name }}
                    </p>
                  </div>
                  <!-- </a-popover> -->
                  <!-- -------------------------- -->
                </a-list-item>
              </a-list>
            </a-checkbox-group>
          </div>
        </a-layout-content>
      </a-layout>
      <!-- 展示回收站信息 -->
      <a-layout-content v-if="selectPageKey == '0-4-3'">
        <recycle-bin :serviceHttp="serviceHttp" :token="token" :parentId="parentFileId"></recycle-bin>
      </a-layout-content>

      <!-- <upload-files :uploadVisible.sync="uploadVisible"></upload-files>
  <file-attribute :attributeVisible.sync="attributeVisible"></file-attribute>
  <share-files :filesShareVisible.sync="filesShareVisible"></share-files> -->

      <!-- 管理后台弹框 -->
      <!-- <a-modal v-model="adminVisible" title="管理后台" @ok="hideAdmin" :bodyStyle="{height:'80vh'}" :dialog-style="{ top: '20px' }" width="80vw" :footer="null">
    <admin />
  </a-modal> -->

      <div class="float_layer" id="miaov_float_layer" v-show="config.upload">
        <h2>
          <a-icon type="cloud-upload" class="float_layer_title_icon" />
          <strong>文件上传</strong>

          <a id="btn_min" href="javascript:;" class="min">
            <a-icon type="up" v-if="upDownType == 1" class="icon_r" />
            <a-icon type="down" v-if="upDownType == 0" class="icon_r" />
          </a>

          <a id="btn_close" href="javascript:;" class="close">
            <a-icon type="close" class="icon_r" />
          </a>
        </h2>

        <div class="content">
          <div class="wrap">
            <uploadHttp
              :uploadHttp="dataUploadHttp"
              :queryFileHttp="dataQueryFileHttp"
              :token="dataToken"
              @change="aaa"
              ref="uploadHttp"
            >
            </uploadHttp>
          </div>
        </div>
        <div class="float_footer"></div>
      </div>
    </a-layout>

    <!-- 分享弹窗 -->
    <share-files
      :filesShareVisible.sync="shareVisible"
      :shareData="shareFileData"
    ></share-files>

    <!-- 文件属性 -->
    <a-modal
      v-model="attributeVisible"
      title="属性"
      @ok="attributeHandleOk"
      class="wfm-attribute-container"
      :maskClosable="false"
      @cancel="attributeHandleCancel"
      :destroyOnClose="true"
    >
      <template slot="footer">
        <a-button
          key="submit"
          type="primary"
          :loading="attributeLoading"
          @click="attributeHandleOk"
        >
          确定
        </a-button>
        <a-button key="back" @click="attributeHandleCancel"> 取消 </a-button>
      </template>
      <a-tabs default-active-key="1" type="card">
        <a-tab-pane key="1" tab="属性" class="tab1">
          <!-- 属性表单 -->
          <a-form-model
            ref="fileAttributeruleForm"
            :model="fileAttributeForm"
            :rules="fileAttributerules"
            :label-col="labelCol"
            :wrapper-col="wrapperCol"
          >
            <a-form-model-item ref="fileName" label="文件名" prop="fileName">
              <a-input
                v-model="fileAttributeForm.fileName"
                placeholder="请输入文件名"
                @blur="
                  () => {
                    $refs.fileName.onFieldBlur();
                  }
                "
              />
            </a-form-model-item>
            <a-form-model-item label="类型" prop="fileType">
              <span>{{ fileAttributeForm.fileType }}</span>
            </a-form-model-item>
            <a-form-model-item label="路径" prop="filePath">
              <span>{{ fileAttributeForm.filePath }}</span>
            </a-form-model-item>
            <a-form-model-item label="文件大小" prop="fileStorage">
              <span>{{ fileAttributeForm.fileStorage }}</span>
            </a-form-model-item>
            <a-form-model-item label="包含" prop="fileInclude">
              <span>{{ fileAttributeForm.fileInclude }}</span>
            </a-form-model-item>
            <a-form-model-item label="创建时间" prop="fileCreattime">
              <span>{{ fileAttributeForm.fileCreattime }}</span>
            </a-form-model-item>
            <a-form-model-item label="修改时间" prop="fileMtime">
              <span>{{ fileAttributeForm.fileMtime }}</span>
            </a-form-model-item>
            <a-form-model-item label="描述说明" prop="fileDesc">
              <a-input
                v-model="fileAttributeForm.filedesc"
                type="textarea"
                placeholder="添加描述"
              />
            </a-form-model-item>
          </a-form-model>
          <!-- 属性表单 -->
        </a-tab-pane>
        <a-tab-pane
          v-if="fileAttributeForm.fileType !== '文件夹'"
          key="2"
          tab="版本"
          force-render
        >
          <!-- 版本说明 -->
          <a-row
            :gutter="[8, 24]"
            type="flex"
            justify="space-around"
            align="middle"
          >
            <a-col :span="12">
              <div>
                <a-icon type="history" /> 历史版本({{ fileHistoryTotal }}条记录)
              </div>
            </a-col>
            <a-col :span="12" type="flex" justify="space-around" align="end">
              <a-button icon="sync" size="small"></a-button>
              <a-button icon="upload" size="small" @click="uploadFileVersion()">上传新版本</a-button>
            </a-col>
          </a-row>
          <a-card
            size="small"
            title="管理员"
            style="margin-top: 20px; border-radius: 5px"
          >
            <span slot="extra">时间</span>
            <a-row type="flex" justify="space-around" align="middle">
              <a-col :span="12">
                <a-tag color="blue"> 当前版本 </a-tag>
              </a-col>
              <a-col :span="12" type="flex" justify="space-around" align="end">
                大小: <span>2.1kb </span>
              </a-col>
            </a-row>
          </a-card>
          <a-card
            size="small"
            title="管理员"
            style="margin-top: 20px; border-radius: 5px"
          >
            <span slot="extra">时间</span>
            <a-row type="flex" justify="space-around" align="middle">
              <a-col :span="12">
                <div>添加文档描述</div>
              </a-col>
              <a-col :span="12" type="flex" justify="space-around" align="end">
                <span>2.1kb </span>
                <a-dropdown>
                  <a-button
                    icon="ellipsis"
                    size="small"
                    @click="(e) => e.preventDefault()"
                  ></a-button>
                  <a-menu slot="overlay">
                    <a-menu-item>
                      <a href="javascript:;">
                        <a-icon type="folder-open" /> 打开</a
                      >
                    </a-menu-item>
                    <!-- <a-menu-item>
                      <a href="javascript:;">
                        <a-icon type="import" /> 打开为</a
                      >
                    </a-menu-item> -->
                    <a-menu-item>
                      <a href="javascript:;">
                        <a-icon type="download" /> 下载</a
                      >
                    </a-menu-item>
                    <a-menu-item>
                      <a href="javascript:;">
                        <a-icon type="menu" /> 设置为当前版本</a
                      >
                    </a-menu-item>
                    <a-menu-item>
                      <a href="javascript:;">
                        <a-icon type="delete" /> 删除改版本</a
                      >
                    </a-menu-item>
                    <a-menu-item>
                      <a href="javascript:;">
                        <a-icon type="delete" /> 删除所有版本记录</a
                      >
                    </a-menu-item>
                  </a-menu>
                </a-dropdown>
              </a-col>
            </a-row>
          </a-card>
          <!-- 版本说明 -->
        </a-tab-pane>
        <a-tab-pane key="3" tab="引用" force-render>
          <!-- 引用表格 -->
          <a-table
            :scroll="{ y: 400 }"
            :columns="flieColumns"
            :data-source="pullindata"
            :pagination="tablePagination"
          >
            <!-- <a slot="name" slot-scope="text">{{ text }}</a> -->
          </a-table>
          <!-- 引用表格 -->
        </a-tab-pane>
        <a-tab-pane key="4" tab="分享" force-render>
          <a-row :gutter="[48, 48]">
            <a-col :span="12">
              <div class="file-share">
                浏览 <span>{{ fileShareBrowsed }}</span>
              </div>
            </a-col>
            <a-col :span="12">
              <div class="file-share">
                下载 <span>{{ fileShareDownload }}</span>
              </div>
            </a-col>
          </a-row>
          <a-row :gutter="[48, 48]">
            <a-col :span="12">
              <div class="file-share">
                被转存 <span>{{ fileShareUnloading }}</span>
              </div>
            </a-col>
            <!-- <a-col :span="12"> </a-col> -->
          </a-row>
        </a-tab-pane>
      </a-tabs>
    </a-modal>

    <!-- 复制到或者移动到 -->
    <a-modal
      class="copy"
      :title="chooseType == 1 ? '复制到' : '移动到'"
      :visible="copyVisible"
      v-if="copyVisible"
      :confirm-loading="copyLoading"
      @ok="copyHandleOk"
      @cancel="copyHandleCancel"
    >
      <template slot="footer">
        <a-button
          key="submit"
          type="primary"
          :loading="moveLoading"
          @click="copyHandleOk"
        >
          确定
        </a-button>
        <a-button key="back" @click="copyHandleCancel"> 取消 </a-button>
      </template>

      <a-tree
        :load-data="onLoadData"
        :defaultExpandParent="false"
        :selected-keys="selectedKeys"
        :tree-data="findSpace"
        @expand="onExpand"
        @select="onSelect"
      />
    </a-modal>
    <!-- 上传 -->
    <a-modal
      title="上传"
      :visible="filesUploadVisible"
      @ok="filesUploadModalOk"
      @cancel="filesUploadModalCancel"
    >
      <template slot="footer">
        <a-button key="submit" type="primary" @click="filesUploadModalOk">
          确定
        </a-button>
        <a-button key="back" @click="filesUploadModalCancel"> 取消 </a-button>
      </template>

      <uploadHttp
        :uploadHttp="dataUploadHttp"
        :queryFileHttp="dataQueryFileHttp"
        :token="dataToken"
        ref="uploadRef"
      >
      </uploadHttp>
    </a-modal>

    <!-- 预览 -->
    <!-- <a-modal v-model="lookVisibleVisible" title="Title" on-ok="lookFile">
      <template slot="footer">
        <a-button key="back" @click="lookFile"> 取消 </a-button>
        <a-button
          key="submit"
          type="primary"
          :loading="loading"
          @click="lookFile"
        >
          确定
        </a-button>
      </template>
      <iframe ref="frame" :src="fileUrl" height="500px" width="100%"></iframe>
    </a-modal> -->

    <!-- 管理后台弹框 -->
    <a-modal
      v-model="adminVisible"
      v-if="adminVisible"
      title="管理后台"
      @ok="hideAdmin"
      :bodyStyle="{ height: '80vh' }"
      :dialog-style="{ top: '20px' }"
      width="80vw"
      :footer="null"
    >
      <admin />
    </a-modal>

    <!-- 新建文件夹 -->
    <a-modal
      title="新建文件夹"
      :visible="folderVisible"
      :confirm-loading="folderConfirmLoading"
      @cancel="folderHandleCancel"
    >
      <a-form-model
        :model="folderForm"
        :label-col="labelCol"
        :wrapper-col="wrapperCol"
      >
        <a-input v-model="newFolderName" placeholder="请输入文件夹" />
      </a-form-model>

      <template slot="footer">
        <a-button key="submit" type="primary" @click="folderHandleOk">
          确定
        </a-button>
        <a-button key="back" @click="folderHandleCancel"> 取消 </a-button>
      </template>
    </a-modal>

    <!-- 重命名 -->
    <a-modal
      title="重命名"
      :visible="renameVsible"
      :confirm-loading="renameConfirmLoading"
    >
      <a-input
        v-if="renameType == 0"
        v-model="newDirectoryName"
        placeholder="请输入文件名"
      />
      <a-input
        v-if="renameType == 1"
        v-model="newDirectoryName"
        placeholder="请输入文件夹名"
      />
      <template slot="footer">
        <a-button key="submit" type="primary" @click="renameOk">
          确定
        </a-button>
        <a-button key="back" @click="renameCancel"> 取消 </a-button>
      </template>
    </a-modal>

    <!-- 文件卡片页面鼠标悬浮显示文件信息 -->
    <div :style="cardBox" class="cardBox">
      <div>
        <span>大小:</span> {{ cardBoxInfo.size | KBDate(cardBoxInfo.size) }}
      </div>
      <div><span>名称:</span>{{ cardBoxInfo.name }}</div>
      <div><span>创建时间:</span>{{ cardBoxInfo.createTime }}</div>
      <div><span>修改时间:</span>{{ cardBoxInfo.updataTime }}</div>
      <div><span>路径:</span>{{ cardBoxInfo.path }}</div>
      <div>
        <span>是否被分享:</span
        >{{ cardBoxInfo.share == "1" ? "已分享" : "未分享" }}
      </div>
      <div>
        <span>是否被引用:</span
        >{{ cardBoxInfo.cause == "1" ? "已引用" : "未引用" }}
      </div>
      <div>
        <span>是否发布云门户:</span
        >{{ cardBoxInfo.send == "1" ? "已发布" : "未发布" }}
      </div>
    </div>
  </div>
</template>

<script>
// 引用表格表头名称
const flieColumns = [
  {
    title: "序号",
    dataIndex: "order",
    width: "15%",
    scopedSlots: {
      customRender: "order",
    },
  },
  {
    title: "引用时间",
    dataIndex: "applicationTime",
    width: "40%",
    scopedSlots: {
      customRender: "applicationTime",
    },
  },
  {
    title: "引用人",
    dataIndex: "applicationUser",
    width: "20%",
    scopedSlots: {
      customRender: "applicationUser",
    },
  },
  {
    title: "引用功能",
    dataIndex: "applicationType",
    scopedSlots: {
      customRender: "applicationType",
    },
  },
];
// 引用表格 假数据
const pullindata = [];
for (let i = 0; i < 100; i++) {
  pullindata.push({
    key: i.toString(),
    order: (i + 1).toString(),
    pullinTime: "2021-02-23 17:30:56",
    pullinUser: "刘思鉴",
    pullinFunction: "应用帮组手册",
  });
}
//时间范围选择
let dataRange = {
  最近3个月: [moment().startOf("day").subtract(3, "months"), moment()],
  最近半年: [moment().startOf("day").subtract(6, "months"), moment()],
  最近1年: [moment().startOf("day").subtract(1, "years"), moment()],
};

import {
  treeData,
  FileListColumns,
  // FileListData,
} from "./index.js";
import recycleBin from "./recycleBin.vue";
import moment from "moment"; //引入时间插件

// import './../../assets/fileIcon/iconFont/iconfont.css'
import axios from "axios";
import Vue from "vue";
import admin from "./Admin"; //后台管理弹窗
import Base64 from "base-64";
import shareFiles from "./ShareFiles/ShareFiles.vue"; //分享弹框
Vue.prototype.$axios = axios;

export default {
  name: "FilesUpload",
  components: {
    //   uploadFiles,
    //   fileAttribute,
    shareFiles,
    admin,
    recycleBin,
  },
  data() {
    return {
      arrarr: [], //选取文件路径的时候，懒加载文件下面的子节点
      chooseCopyRoute: "", //打开复制弹框选择的保存文件夹
      chooseType: "", //判断点击的是复制弹框还是移动弹框
      checkCopyOrMove: [], //单个文件夹进行复制或者移动
      CopyOrMoveState: "", //判断是单个文件操作还是多个文件操作

      lookVisibleVisible: false, //预览窗口
      fileUrl: "", //预览地址
      dataRange, //时间范围

      shareData: [], //选中的文件列表
      shareFileData: [], //分享的列表
      renameID: "",
      renameType: 0, // 1文件夹  0文件
      renameConfirmLoading: false,
      renameVsible: false, //
      newDirectoryName: "", //重命名
      // parentId: "-1", //文件夹父级ID
      parentFileId: ["-1"], //父级文件Id
      organizationID: "71731792389865472", //机构ID
      fileID: "", //文件ID
      folderID: -1, //文件夹ID
      folderForm: {},
      newFolderName: "",
      folderVisible: false,
      folderConfirmLoading: false,
      spaceType: 0, //空间类型
      upDownType: 0, //0收缩 1展开
      pageSize: 50, //
      pageNum: 1, //

      fileNavigation: ["个人空间"], //面包屑导航栏

      //上传
      filesUploadVisible: false,
      dataUploadHttp: this.uploadHttp,
      dataQueryFileHttp: this.queryFileHttp,
      dataToken: this.token,
      //复制到
      copyVisible: false,
      copyLoading: false,
      //复制路径
      findSpace: [{ title: "个人空间", key: "0", children: [] }],

      //移动到
      moveVisible: false,
      moveLoading: false,
      autoExpandParent: true,
      selectedKeys: [],
      moveTreeData: [{ title: "个人空间", key: "0", children: [] }],

      //分享
      shareVisible: false,
      shareLoading: false,
      filesShareform: {
        name: "",
        delivery: true,
        password: "",
        title: "",
        uesful: false,
        time: false,
        date1: undefined,
      },
      advancedConfiguration: false, //高级配置按钮
      //文件属性
      attributeLoading: false, //属性确定按钮loading
      attributeVisible: false, //属性弹框是否显示true
      // 文件属性数据
      labelCol: {
        span: 4,
      },
      wrapperCol: {
        span: 18,
      },
      // 属性表单
      fileAttributeForm: {
        filename: "",
        fileType: "文件夹",
        filePath: "文件路径",
        fileStorage: "文件大小",
        fileInclude: "包含",
        fileCreattime: "创建时间",
        fileMtime: "修改时间",
        filedesc: "",
      },
      //  属性表单校验
      fileAttributerules: {
        filename: [
          {
            required: true,
            message: "请填写文件名称",
            trigger: "blur",
          },
          // { min: 3, max: 5, message: 'Length should be 3 to 5', trigger: 'blur' },
        ],
        desc: [
          {
            required: true,
            message: "请填写描述说明",
            trigger: "blur",
          },
        ],
      },
      // 版本
      fileHistoryTotal: 0, //历史记录条数
      // 文件引用数据
      flieColumns,
      pullindata,
      tablePagination: {
        size: "small",
        "show-size-changer": true,
        // 'show-quick-jumper': true,
        total: pullindata.length,
        "show-total": (total) => `共 ${total} 条`,
      },
      // 分享
      fileShareBrowsed: "12次", //浏览
      fileShareDownload: "3次", //下载
      fileShareUnloading: "4次", //转存

      // marginTop:"60",
      collapsed: false,
      /* 左侧导航 */
      treeData: treeData,
      FileListColumns: FileListColumns,
      FileListData: [],
      selectedRowKeys: [],
      loading: false,
      // tablePagination: {
      //   'show-size-changer': true,
      //   'show-quick-jumper': true,
      //   'total': FileListData.length,
      //   'show-total': total => `共 ${total} 条`
      // },
      // listPagination: {
      //   'show-size-changer': true,
      //   'show-quick-jumper': true,
      //   'defaultPageSize': 30,
      //   'total': FileListData.length,
      //   'show-total': total => `共 ${total} 条`
      // },
      mode: "table", //表格与图片列表切换
      tableHeight: window.innerHeight - 250,
      uploadVisible: false, //文件上传显示
      attributeVisible: false, // 属性显示
      filesShareVisible: false, // 分享显示
      adminVisible: false,
      isActive: null,
      mySpace: {
        //我的空间
        percentum: "",
        personalSpaceSize: "", //总空间
        totalFileSize: "", //已使用空间
      },
      selectPageKey: "", //点击左侧菜单的key
      searchForm: {
        //搜索过滤文件列表
        search: "", //搜索框输入的内容
        scope: "all", //搜索范围
        fileType: "不限类型", //类型
        startData: "", //开始时间
        endData: "", //结束时间
        fileSize: "不限大小", //文件大小选择区间
        startSize: "", //最小
        endSize: "", //最大
        share: "1", //分享
        quote: "1", //引用
        cloudPortal: "1", //发布
      },

      //卡片页面悬浮两秒显示盒子
      cardBox: {
        display: "none",
        padding: "20px",
        position: "absolute",
        left: "",
        top: "",
        // border: "1px solid black",
        background: "#ffface",
      },
      //悬浮显示的信息
      cardBoxInfo: {
        size: "",
        name: "",
        createTime: "",
        updataTime: "",
        path: "",
        share: "",
        cause: "",
        send: "",
      },
      //卡片页面鼠标悬浮显示功能点
      listCard: {
        id: "-1",
      },
    };
  },
  props: {
    marginTop: {
      type: String,
      default: "60",
    },
    uploadHttp: {
      //上传
      type: String,
      default: "http://192.168.19.29:6001",
    },
    queryFileHttp: {
      //文件验证
      type: String,
      default: "http://192.168.19.29:6001",
    },
    serviceHttp: {
      //服务接口
      type: String,
      default: "http://192.168.19.29:6001",
    },
    token: {
      type: String,
      default: "d35a5b03-1ad0-42f0-84ea-dabdb9b7cd80",
      // default: "a74aeee2-03a6-4728-89ac-f5280e4aad42",
      // default:"ed0b489e-8571-4da2-a73a-e6871fa985ca"
    },
    config: {
      type: Object,
      default() {
        return {
          search: true, //搜索
          upload: true, //上传
          height: "",
          newFolder: true, //新建文件夹
          select: "checkbox", //单选radio 多选checkbox
          disableSelect: {
            //禁用选择
            state: false, //禁用选择
            lock: 0, //0 禁用后，过滤可选得后缀， 1禁用后，过滤不可选的后缀
            suffix: [], //禁用后,可选得后缀   ["folder", "pptx"]
            disableSuffix: [], //禁用后，过滤不可选的后缀
          },
          selectSave: false, //翻页保存勾选开启true 关闭false
          // search 搜索   Boolean
          // upload 上传   Boolean
          // NewFolder 新建文件夹  Boolean
          // select   string  单选radio 多选checkbox
          //disable-select object
          // {
          //   disableSelect:true,
          //   suffix:""  //后缀
          // }
          // 禁用选择 Boolean   true 不禁用  false警用
          //
        };
      },
    },
  },
  computed: {
    hasSelected() {
      return this.selectedRowKeys.length > 0;
    },
  },
  mounted() {
    let that = this;
    this.fileList();
    this.tableScroll();
    this.mineSpace(); //查询空间容量
    function miaovAddEvent(oEle, sEventName, fnHandler) {
      if (oEle.attachEvent) {
        oEle.attachEvent("on" + sEventName, fnHandler);
      } else {
        oEle.addEventListener(sEventName, fnHandler, false);
      }
    }

    console.log("window.onload = function()");
    var oDiv = document.getElementById("miaov_float_layer");
    var oBtnMin = document.getElementById("btn_min");
    var oBtnClose = document.getElementById("btn_close");
    var oDivContent = oDiv.getElementsByTagName("div")[0];
    var iMaxHeight = 0;

    // alert(this.config.upload)
    if (this.config.upload == true) {
      oDiv.style.display = "block";
    } else {
      oDiv.style.display = "none";
    }

    // oDiv.style.display = 'none';
    iMaxHeight = oDivContent.offsetHeight;

    oDiv.style.position = "absolute";
    repositionFixed();
    miaovAddEvent(window, "resize", repositionFixed);

    oBtnMin.timer = null;
    oBtnMin.isMax = true;
    oBtnMin.onclick = function () {
      startMove(
        oDivContent,
        (this.isMax = !this.isMax) ? iMaxHeight : 0,
        function () {
          oBtnMin.className = oBtnMin.className == "min" ? "max" : "min";
          that.upDownType = oBtnMin.className == "min" ? 0 : 1;
        }
      );
    };
    oBtnClose.onclick = function () {
      oDiv.style.display = "none";
    };

    function startMove(obj, iTarget, fnCallBackEnd) {
      if (obj.timer) {
        clearInterval(obj.timer);
      }
      obj.timer = setInterval(function () {
        doMove(obj, iTarget, fnCallBackEnd);
      }, 30);
    }

    function doMove(obj, iTarget, fnCallBackEnd) {
      var iSpeed = (iTarget - obj.offsetHeight) / 8;
      if (obj.offsetHeight == iTarget) {
        clearInterval(obj.timer);
        obj.timer = null;
        if (fnCallBackEnd) {
          fnCallBackEnd();
        }
      } else {
        iSpeed = iSpeed > 0 ? Math.ceil(iSpeed) : Math.floor(iSpeed);
        obj.style.height = obj.offsetHeight + iSpeed + "px";
        (window.navigator.userAgent.match(/MSIE 6/gi) &&
          window.navigator.userAgent.match(/MSIE 6/gi).length == 2
          ? repositionAbsolute
          : repositionFixed)();
      }
    }

    function repositionAbsolute() {
      var oDiv = document.getElementById("miaov_float_layer");
      var left =
        document.body.scrollLeft || document.documentElement.scrollLeft;
      var top = document.body.scrollTop || document.documentElement.scrollTop;
      var width = document.documentElement.clientWidth;
      var height = document.documentElement.clientHeight;
      oDiv.style.top = top + height - oDiv.offsetHeight + "px";
      oDiv.style.right = 10 + "px";
    }

    function repositionFixed() {
      console.log("repositionFixed");
      var oDiv = document.getElementById("miaov_float_layer");
      var width = document.documentElement.clientWidth;
      var height = document.documentElement.clientHeight;
      oDiv.style.top = height - oDiv.offsetHeight + "px";
      oDiv.style.right = 10 + "px";
    }
  },
  methods: {
    //
    //上传单独文件版本
    uploadFileVersion(){
        this.uploadType=1
        this.$refs.uploadHttp.fileVersionUP(1)
        // console.log(this.$refs.uploadHttp.ttt())
    },
    //重命名
    renameOk() {
      let data = {
        id: this.renameID,
        folderName: this.newDirectoryName,
      };
      axios
        .put(
          this.serviceHttp +
            "/cloudoffice/fileVirtualFolderInfo/updateFileVirtualFolderInfo",
          data,
          {
            headers: {
              "Content-Type": "application/json",
              Authorization: "Bearer " + this.dataToken,
            },
          }
        )
        .then((res) => {
          if (res.data.code == 200) {
            this.$message.success("重命名成功");
            this.fileList();
          }
        })
        .catch((error) => {
          console.log(error);
        });

      this.renameVsible = false;
    },
    //重命名
    renameCancel() {
      this.renameVsible = false;
    },
    //重命名
    rename(data) {
      console.log(data);
      this.renameID = data.id;
      this.newDirectoryName = "";
      if (data.isFolder == 0) {
        this.renameType = 0;
      } else {
        this.renameType = 1;
      }
      this.renameVsible = true;
    },

    //
    navOnExpand(expandedKeys) {
      console.log("onExpand", expandedKeys);
    },
    //左侧菜单点击
    navOnSelect(selectedKeys, info) {
      console.log("onSelect", info);
      console.log("onSelect2", selectedKeys);

      //点击左侧列表判断当前选中的空间类型
      // console.log(selectedKeys,'+++++');
      let chooseKey = 0;
      if (info.selected) {
        chooseKey = selectedKeys[0].slice(0, 3);
      }
      console.log(chooseKey, "+=+");
      if (chooseKey == "0-1") {
        this.spaceType = 0; //当前为个人空间
      } else if (chooseKey == "0-2") {
        this.spaceType = 1; //当前空间为机构空间
      } else if (chooseKey == "0-3") {
        this.spaceType = 2; //当前空间为系统空间
        console.log(1234);
      } else {
        this.spaceType = 0; //当前空间为系统空间
        console.log(1234);
      }
      // console.log("onSelect", info.node.$vnode.data.props.type,'??++==');
      // this.spaceType = info.node.$vnode.data.props.type;
      this.pageNum = 1;
      this.selectPageKey = selectedKeys;
      if (selectedKeys == "0-0") {
        //如果点击收藏页面
        this.CollectPage();
      } else {
        this.fileList();
      }
    },
    //新建文件夹
    folderVisibleClick() {
      this.folderVisible = true;
    },

    //文件夹
    folderHandleOk() {
      let data = {
        fileVirtualFolderInfoVO: {
          folderName: this.newFolderName,
        },
        targetFileVirtualFolderInfoVO: {
          id: this.parentFileId[this.parentFileId.length - 1],
          spaceType: this.spaceType,
          organizationId: "",
          applicationId: "",
        },
      };
      console.log(data, 112);
      axios
        .post(
          this.serviceHttp +
            "/cloudoffice/fileVirtualFolderInfo/createNewFileVirtualFolderInfo",
          data,
          {
            headers: {
              "Content-Type": "application/json",
              Authorization: "Bearer " + this.dataToken,
            },
          }
        )
        .then((res) => {
          if (res.data.code == 200) {
            this.folderVisible = false;
            this.$message.success("新建成功");
            this.newFolderName = ""; //新建成功后清除输入框
            this.fileList(); //新建成功后调用刷新列表接口
          }
        })
        .catch((error) => {
          console.log(error);
        });
    },
    folderHandleCancel() {
      this.newFolderName = ""; //新建成功后清除输入框
      this.folderVisible = false;
    },
    //数据列表
    fileList() {
      console.log("fileList");
      let that = this;

      let data = {
        parentId: this.parentFileId[this.parentFileId.length - 1],
        spaceType: this.spaceType,
        pageNum: this.pageNum,
        pageSize: this.pageSize,
        organizationId: this.spaceType == 1 ? this.organizationID : "",
        order: "update_date desc",
      };
      axios
        .post(
          this.serviceHttp +
            "/cloudoffice/fileVirtualFolderInfo/selectAllSpace",
          data,
          {
            headers: {
              "Content-Type": "application/json",
              Authorization: "Bearer " + this.dataToken,
            },
          }
        )
        .then((res) => {
          if (res.data.code == 200) {
            that.FileListData = res.data.data;
            console.log(that.FileListData);
          } else {
            this.$message.warning(res.data.message);
          }
        })
        .catch((error) => {
          console.log(error);
        });
    },
    Upload() {
      // console.log('父组件的xiechengUpload被调用了')
      this.$refs.uploadRef.fileClick(0);
    },
    //收藏页面
    CollectPage() {
      let that = this;
      let data = {
        pageNum: this.pageNum,
        pageSize: this.pageSize,
        order: "update_date desc",
      };
      axios
        .post(
          this.serviceHttp +
            "/cloudoffice/fileVirtualFolderInfo/selectMyCollection",
          data,
          {
            headers: {
              "Content-Type": "application/json",
              Authorization: "Bearer " + this.dataToken,
            },
          }
        )
        .then((res) => {
          if (res.data.code == 200) {
            that.FileListData = res.data.data;
            console.log(that.FileListData);
          }
        })
        .catch((error) => {
          console.log(error);
        });
    },

    //表格点击收藏
    // tableCollection(row) {
    //   console.log("收藏");
    //   console.log(row);
    // },

    //改变收藏状态
    ChangeCollection(row) {
      console.log("取消收藏");
      console.log(row);
      if (row.fileCollectId) {
        //取消收藏
        this.CancelCollect(row.fileCollectId, row);
      } else {
        //添加收藏
        this.CreateCollect(row.id, row.isFolder, row);
      }
    },
    //添加收藏接口
    CreateCollect(a, b, row) {
      let data = {
        id: a,
        isFolder: b,
      };

      axios
        .post(
          this.serviceHttp + "/cloudoffice/fileCollect/createFileCollect",
          data,
          {
            headers: {
              "Content-Type": "application/json",
              Authorization: "Bearer " + this.dataToken,
            },
          }
        )
        .then((res) => {
          if (res.data.code == 200) {
            console.log(res);
            // this.$router.go(0);//刷新页面
            row.fileCollectId = "111";
          }
        })
        .catch((error) => {
          console.log(error);
        });
    },
    //取消收藏接口
    CancelCollect(a, row) {
      axios
        .delete(
          this.serviceHttp + "/cloudoffice/fileCollect/deleteFileCollect",
          {
            headers: {
              "Content-Type": "application/json",
              Authorization: "Bearer " + this.dataToken,
            },
            params: {
              fileCollectId: a,
            },
          }
        )
        .then((res) => {
          if (res.data.code == 200) {
            console.log(res);
            row.fileCollectId = null;
          }
        })
        .catch((error) => {
          console.log(error);
        });
    },
    //全部收藏接口
    allCollect() {
      console.log(this.shareData);
      let data = [];
      this.shareData.forEach((item) => {
        data.push({
          id: item.id,
          isFolder: item.isFolder,
        });
      });

      axios
        .post(
          this.serviceHttp + "/cloudoffice/fileCollect/batchCreateFileCollect",
          data,
          {
            headers: {
              "Content-Type": "application/json",
              Authorization: "Bearer " + this.dataToken,
            },
          }
        )
        .then((res) => {
          if (res.data.code == 200) {
            console.log(res);
            this.shareData.forEach((item) => {
              item.fileCollectId = "111";
            });
          }
        })
        .catch((error) => {
          console.log(error);
        });
    },
    //刷新页面
    refresh() {
      this.$router.go(0); //刷新页面
    },
    //返回上一层
    backPage() {
      if (this.parentFileId[this.parentFileId.length - 1] == "-1") {
        this.$message.warning("已经最顶层了·");
        this.returnPage();
      } else {
        this.returnPage();
        this.parentFileId.splice(this.parentFileId.length - 1, 1);
        this.fileNavigation.splice(this.fileNavigation.length - 1, 1); //导航面包屑删除一层
      }
      console.log(this.parentFileId);
    },
    //返回上一层接口
    returnPage() {
      let that = this;
      let data = {
        id: that.parentFileId[that.parentFileId.length - 1],
        spaceType: this.spaceType,
        order: "update_date desc",
      };
      console.log(this.spaceType);
      axios
        .post(
          this.serviceHttp +
            "/cloudoffice/fileVirtualFolderInfo/selectAllSpacePreviousLevel",
          data,
          {
            headers: {
              "Content-Type": "application/json",
              Authorization: "Bearer " + that.dataToken,
            },
          }
        )
        .then((res) => {
          if (res.data.code == 200) {
            console.log(res);
            this.FileListData = res.data.data;
          }
        })
        .catch((error) => {
          console.log(error);
        });
    },
    //打开文件夹
    openFile(record) {
      console.log(record);
      let that = this;
      this.pageNum = 1;
      if (record.fileType == "folder") {
        //文件夹
        let data = {
          parentId: record.id,
          spaceType: record.spaceType,
          pageNum: this.pageNum,
          pageSize: this.pageSize,
          isFolder: this.isFolder,
          order: "update_date desc",
        };

        axios
          .post(
            this.serviceHttp +
              "/cloudoffice/fileVirtualFolderInfo/selectAllSpace",
            data,
            {
              headers: {
                "Content-Type": "application/json",
                Authorization: "Bearer " + this.dataToken,
              },
            }
          )
          .then((res) => {
            if (res.data.code == 200) {
              that.FileListData = [];
              that.FileListData = res.data.data;
              console.log(that.FileListData);
              this.parentFileId.push(record.id); //获取到父级文件夹ID
            }
          })
          .catch((error) => {
            console.log(error);
          });
      } else {
        //预览
      }
    },
    //双击文件
    dblclickFileName(record, index) {
      return {
        on: {
          dblclick: () => {
            let that = this;
            console.log(record); //fileNavigation
            that.fileNavigation = record.filePath.split("/");
            event.stopPropagation(); //阻止默认事件
            this.pageNum = 1;
            if (record.fileType == "folder") {
              //文件夹
              let data = {
                parentId: record.id,
                spaceType: record.spaceType,
                pageNum: this.pageNum,
                pageSize: this.pageSize,
                isFolder: this.isFolder,
                order: "update_date desc",
              };

              console.log(data);

              axios
                .post(
                  this.serviceHttp +
                    "/cloudoffice/fileVirtualFolderInfo/selectAllSpace",
                  data,
                  {
                    headers: {
                      "Content-Type": "application/json",
                      Authorization: "Bearer " + this.dataToken,
                    },
                  }
                )
                .then((res) => {
                  if (res.data.code == 200) {
                    that.FileListData = [];
                    that.FileListData = res.data.data;
                    console.log(that.FileListData);
                    this.parentFileId.push(record.id); //获取到父级文件夹ID
                  }
                })
                .catch((error) => {
                  console.log(error);
                });
            } else {
              //预览
              console.log("====预览");
              // this.lookVisibleVisible = true;

              // let id = "";
              let url =
                that.serviceHttp +
                "/cloudoffice/onlineDownloadFile?id=" +
                record.id;
              let path = "http://192.168.49.11:8012";
              let fileUrl = `${path}/onlinePreviewMd5?url=${
                Base64.encode(url) + "&suffix=" + record.fileType
              }`;
              window.open(fileUrl);
            }
          },
        },
      };
    },
    //打开预览窗口
    lookFile() {
      this.lookVisibleVisible = false;
    },
    //选择的卡片页文件
    onChangeCheckbox(checkedValues) {
      this.shareData = checkedValues;
      console.log(this.shareData.length);
    },
    //删除文件
    deleteFile(e) {
      console.log(e);
      this.deleteContent(e);
    },
    //删除
    deleteContent(e) {
      if (e == "deleteAll") {
        if (this.shareData.length == 0) {
          console.log(222);
          this.$message.warning("请选择文件或文件夹");
          return;
        }
      }
      console.log("deleteContent");
      console.log(e);
      let that = this;
      let fileVirtualInfoVOList = [];
      let fileVirtualFolderInfoVOList = [];
      if (e != "deleteAll") {
        if (e.isFolder == 1) {
          fileVirtualFolderInfoVOList.push({ id: e.id });
        } else {
          fileVirtualInfoVOList.push({ id: e.id });
        }
      } else {
        that.shareData.forEach((item) => {
          console.log(item);
          if (item.isFolder == 1) {
            fileVirtualFolderInfoVOList.push({ id: item.id });
          } else {
            fileVirtualInfoVOList.push({ id: item.id });
          }
        });
      }

      let data = {
        key: "fileManageBasicSet",
        ID: "-1",
        organizationID: that.organizationID,
        spaceType: that.spaceType,
        fileVirtualInfoVOList: fileVirtualInfoVOList, //文件id
        fileVirtualFolderInfoVOList: fileVirtualFolderInfoVOList, //文件夹id
      };
      console.log(data);
      axios
        .post(
          that.serviceHttp +
            "/cloudoffice/fileVirtualFolderInfo/deleteFileVirtualFolderInfo",
          data,
          {
            headers: {
              "Content-Type": "application/json",
              Authorization: "Bearer " + that.dataToken,
            },
          }
        )
        .then((res) => {
          //次要操作，静默处理
          console.log(res);
          if (res.data.code == 200) {
            this.fileList();
            this.$message.success("删除成功！！！");
          }
        })
        .catch((error) => {
          console.log(error);
        });
    },

    //打开选择文件保存位置弹框
    showRouteModal(e, y) {
      //如果传y值证明是单个文件操作
      if (y) {
        console.log(y);
        this.checkCopyOrMove = y; //把选择的单个文件保存下来
        this.CopyOrMoveState = 1; //单个文件操作
      } else {
        //多个文件操作，判断有没有选择文件或文件夹
        this.CopyOrMoveState = 2; //多个文件操作
        if (this.shareData.length == 0) {
          this.$message.warning("请选择文件或文件夹");
          return;
        }
      }
      //判断是复制，移动，还是其他操作
      if (e == "copy") {
        this.chooseType = 1;
      } else if (e == "move") {
        this.chooseType = 2;
      } else {
        this.chooseType = 3;
      }
      this.copyVisible = true; //打开选择文件弹框
      this.findCopyShowModalInfo("-1"); //初始化文件树
    },
    //查询个人空间
    findCopyShowModalInfo(e) {
      let data = {
        parentId: e ? e : "-1",
        spaceType: 0,
        isFolder: 1,
      };
      axios
        .post(
          this.serviceHttp +
            "/cloudoffice/fileVirtualFolderInfo/selectAllSpace",
          data,
          {
            headers: {
              "Content-Type": "application/json",
              Authorization: "Bearer " + this.dataToken,
            },
          }
        )
        .then((res) => {
          console.log(res);
          if (res.data.code == 200) {
            if (e == "-1") {
              this.findSpace[0].children = this.treeArry(res.data.data);
            } else {
              this.arrarr = this.treeArry(res.data.data);
            }
          }
        })
        .catch((error) => {
          console.log(error);
        });
    },
    //选择路径进行复制
    copyRoute(e) {
      let virtualFileAndFolderInfoVOList = [];
      console.log(this.checkCopyOrMove);
      //判断传值
      if (this.CopyOrMoveState == 1) {
        virtualFileAndFolderInfoVOList.push({
          id: this.checkCopyOrMove.id,
          isFolder: this.checkCopyOrMove.isFolder,
        });
      } else {
        this.shareData.forEach((item) => {
          virtualFileAndFolderInfoVOList.push({
            id: item.id,
            isFolder: item.isFolder,
          });
        });
      }

      let data = {
        virtualFileAndFolderInfoVOList: virtualFileAndFolderInfoVOList,
        targetFileVirtualFolderInfoVO: {
          id: this.chooseCopyRoute,
          spaceType: "0",
        },
      };
      axios
        .put(
          this.serviceHttp +
            "/cloudoffice/fileVirtualFolderInfo/batchCvFileAndFolder",
          data,
          {
            headers: {
              "Content-Type": "application/json",
              Authorization: "Bearer " + this.dataToken,
            },
          }
        )
        .then((res) => {
          console.log(res);
          if (res.data.code == 200) {
            this.$message.success("复制成功");
            this.copyLoading = false;
            this.copyVisible = false;
          }
        })
        .catch((error) => {
          console.log(error);
        });
    },
    //选择路径进行移动
    moveRoute(e) {
      let virtualFileAndFolderInfoVOList = [];
      if (this.CopyOrMoveState == 1) {
        virtualFileAndFolderInfoVOList.push({
          id: this.checkCopyOrMove.id,
          isFolder: this.checkCopyOrMove.isFolder,
        });
      } else {
        this.shareData.forEach((item) => {
          virtualFileAndFolderInfoVOList.push({
            id: item.id,
            isFolder: item.isFolder,
          });
        });
      }
      let data = {
        virtualFileAndFolderInfoVOList: virtualFileAndFolderInfoVOList,
        targetFileVirtualFolderInfoVO: {
          id: this.chooseCopyRoute,
          spaceType: "0",
        },
      };
      axios
        .put(
          this.serviceHttp +
            "/cloudoffice/fileVirtualFolderInfo/batchCxFileAndFolder",
          data,
          {
            headers: {
              "Content-Type": "application/json",
              Authorization: "Bearer " + this.dataToken,
            },
          }
        )
        .then((res) => {
          console.log(res);
          if (res.data.code == 200) {
            this.$message.success("移动成功");
            this.copyLoading = false;
            this.copyVisible = false;
            this.fileList();
          } else {
            this.$message.warning(res.data.message);
          }
        })
        .catch((error) => {
          console.log(error);
        });
    },

    //_________
    treeArry(arr) {
      let returnArr = [];
      arr.forEach((item) => {
        console.log(item.isFolder);
        returnArr.push({
          title: item.fileName,
          key: item.id,
        });
      });
      return returnArr;
    },
    //树型控件懒加载
    onLoadData(treeNode) {
      return new Promise((resolve) => {
        if (treeNode.dataRef.children) {
          resolve();
          return;
        }
        setTimeout(() => {
          treeNode.dataRef.children = this.arrarr;
          this.findSpace = [...this.findSpace];
          resolve();
        }, 1500);
      });
    },

    //我的空间容量查询
    mineSpace() {
      axios
        .get(
          this.serviceHttp + "/cloudoffice/fileInvoke/selectPersonalSpaceSize",
          {
            headers: {
              "Content-Type": "application/json",
              Authorization: "Bearer " + this.dataToken,
            },
          }
        )
        .then((res) => {
          if (res.data.code == 200) {
            console.log(res);
            this.mySpace.personalSpaceSize = res.data.data.personalSpaceSize;
            this.mySpace.totalFileSize = res.data.data.totalFileSize;
            this.mySpace.percentum =
              Math.round((5731272 / 221001837182976) * 1000000000000) /
              10000000000.0;
            this.mySpace.percentum =
              Math.round(
                (Number(this.mySpace.totalFileSize) /
                  Number(this.mySpace.personalSpaceSize)) *
                  1000000000000
              ) / 10000000000.0;
            console.log(
              Number(this.mySpace.totalFileSize),
              Number(this.mySpace.personalSpaceSize)
            );
          }
        });
    },

    //上传
    filesUploadModal() {
      // this.filesUploadVisible = true;
      this.$refs.uploadHttp.uploadHttpType(0)
      var oDiv = document.getElementById("miaov_float_layer");
      oDiv.style.display = "block";
    },

    filesUploadModalOk(e) {
      this.filesUploadVisible = false;
    },
    filesUploadModalCancel(e) {
      this.filesUploadVisible = false;
    },

    //复制移动弹框点击确定按钮
    copyHandleOk(e) {
      this.copyLoading = true;
      if (this.chooseType == 1) {
        this.copyRoute();
      } else {
        this.moveRoute();
      }

      setTimeout(() => {}, 2000);
    },
    copyHandleCancel(e) {
      console.log("Clicked cancel button");
      this.copyVisible = false;
    },

    //移动到
    onExpand(expandedKeys) {
      console.log("onExpand", expandedKeys);
      // if not set autoExpandParent to false, if children expanded, parent can not collapse.
      // or, you can remove all expanded children keys.
      this.expandedKeys = expandedKeys;
      this.autoExpandParent = false;
    },
    onCheck(checkedKeys) {
      console.log("onCheck", checkedKeys);
      this.checkedKeys = checkedKeys;
    },
    onSelect(selectedKeys, info) {
      console.log("onSelect", info);
      this.selectedKeys = selectedKeys;
    },
    moveShowModal() {
      this.moveVisible = true;
    },
    moveHandleOk(e) {
      this.moveLoading = true;
      setTimeout(() => {
        this.moveVisible = false;
        this.moveLoading = false;
      }, 2000);
    },
    moveHandleCancel(e) {
      console.log("Clicked cancel button");
      this.moveVisible = false;
    },

    //文件属性
    attributeHandleOk(e) {
      this.attributeLoading = true;
      setTimeout(() => {
        this.attributeLoading = false;
      }, 1000);
    },
    attributeHandleCancel(e) {
      this.attributeVisible = false;
    },

    //分享
    shareModal(type, e) {
      if (type == "all") {
        if (this.shareData.length == 0) {
          this.$message.error("请选择文件或文件夹");
        } else {
          this.shareFileData = [];
          this.shareFileData = this.shareData;
          this.shareVisible = true;
        }
      } else {
        console.log(1122);
        console.log(e);
        this.shareFileData = [];
        this.shareFileData.push(e);
        this.shareVisible = true;
      }
    },

    shareHandleOk(e) {
      this.shareLoading = true;
      setTimeout(() => {
        this.shareVisible = false;
        this.shareLoading = false;
      }, 2000);
    },

    shareHandleCancel(e) {
      console.log("Clicked cancel button");
      this.shareVisible = false;
    },

    //监听列表类型切换
    handleSizeChange(e) {
      if (e.target.value == "table") {
        console.log(e.target.value);
        this.$nextTick(() => {
          this.tableScroll();
        });
        // this.tsbleScroll()
      } else {
        console.log("list-----");
        this.$nextTick(() => {
          this.listScroll();
        });
      }
      //  this.size = e.target.value;
    },

    //表格滚动条
    tableScroll() {
      let tableTop = 170 + parseInt(this.marginTop);
      this.tableHeight = window.innerHeight - tableTop;

      window.onresize = () => {
        let tableTop = 170 + parseInt(this.marginTop);
        this.tableHeight = window.innerHeight - tableTop;
        console.log(this.tableHeight);
        console.log("Trigger Select", window.innerHeight);
        let tableDom = document.querySelector(
          ".tableBoxComponents>.ant-spin-nested-loading>.ant-spin-container>.ant-table>.ant-table-content>.ant-table-body"
        );
        // console.log(tableDom)
        tableDom.style.maxHeight = this.tableHeight + 55 + "px";
      };

      let dom = document.querySelector(
        ".tableBoxComponents>.ant-spin-nested-loading>.ant-spin-container>.ant-table>.ant-table-content>.ant-table-body"
      );
      // console.log(dom)
      // console.log(dom.scrollHeight)
      dom.style.maxHeight = this.tableHeight + 55 + "px";

      dom.addEventListener("scroll", (v) => {
        console.log("23222222");
        const scrollDistance =
          dom.scrollHeight - dom.scrollTop - dom.clientHeight;
        console.log(scrollDistance);
        if (scrollDistance <= 0.8) {
          console.log(scrollDistance);
          this.$message.warning("我~是有底线的 (～￣▽￣)～");
        }
      });
    },

    //列表滚动条
    listScroll() {
      let tableTop = 170 + parseInt(this.marginTop);
      this.tableHeight = window.innerHeight - tableTop;
      console.log(this.tableHeight);
      let listDom = document.querySelector(
        ".listBoxComponents>.ant-spin-nested-loading>.ant-spin-container"
      );
      listDom.style.width = 98.1 + "%";
      window.onresize = () => {
        let tableTop = 170 + parseInt(this.marginTop);
        this.tableHeight = window.innerHeight - tableTop;
        console.log(this.tableHeight);
        console.log("Trigger Select", window.innerHeight);
        let tableDom = document.querySelector(
          ".listBoxComponents>.ant-spin-nested-loading>.ant-spin-container>.ant-row"
        );
        // console.log(tableDom)
        tableDom.style.maxHeight = this.tableHeight + 55 + "px";
      };

      let dom = document.querySelector(
        ".listBoxComponents>.ant-spin-nested-loading>.ant-spin-container>.ant-row"
      );
      // console.log(dom)
      // console.log(dom.scrollHeight)
      dom.style.maxHeight = this.tableHeight + 55 + "px";

      dom.addEventListener("scroll", (v) => {
        console.log("23222222");
        const scrollDistance =
          dom.scrollHeight - dom.scrollTop - dom.clientHeight;
        console.log(scrollDistance);
        if (scrollDistance <= 0.8) {
          console.log(scrollDistance);
          this.$message.warning("我~是有底线的 (～￣▽￣)～");
        }
      });
    },

    //计算主体与上部导航的距离（与文档视口上边距的距离）
    height() {
      if (this.config.height != "") {
        return `height:${this.config.height}`;
      } else {
        return `height: calc((100% - ${this.marginTop}px);`;
      }
    },

    attributeFileList(e) {
      // 属性按钮事件
      this.attributeVisible = true;
      console.log(e);
      this.attributeFileListApi(e);
    },

    //获取文件属性
    attributeFileListApi(e) {
      let that = this;
      let data = {};
      if (e.isFolder == 0) {
        data.fileVirtualInfoId = e.id;
      } else {
        data.fileVirtualFolderInfoId = e.id;
      }
      axios
        .get(
          that.serviceHttp + "/cloudoffice/fileAttributes/getFileAttributes",
          {
            headers: {
              "Content-Type": "application/json",
              Authorization: "Bearer " + that.dataToken,
            },
            params: data,
          }
        )
        .then((res) => {
          console.log(res);
          if (res.data.code == 200) {
            if (e.isFolder == 0) {
              that.fileAttributeForm.fileName =
                res.data.data.fileVirtualInfoVO.fileName;
              that.fileAttributeForm.fileType =
                res.data.data.fileVirtualInfoVO.fileType;
              that.fileAttributeForm.filePath =
                res.data.data.fileVirtualInfoVO.filePath;
              that.fileAttributeForm.fileStorage =
                res.data.data.fileVirtualInfoVO.fileStorage;
              that.fileAttributeForm.fileInclude =
                res.data.data.fileVirtualInfoVO.include;
              that.fileAttributeForm.fileCreattime =
                res.data.data.fileVirtualInfoVO.createDate;
              that.fileAttributeForm.fileMtime =
                res.data.data.fileVirtualInfoVO.updateDate;
              that.fileAttributeForm.filedesc =
                res.data.data.fileVirtualInfoVO.fileDesc;
            } else {
              that.fileAttributeForm.fileName =
                res.data.data.fileVirtualFolderInfoVO.folderName;
              that.fileAttributeForm.fileType = "文件夹";
              that.fileAttributeForm.filePath =
                res.data.data.fileVirtualFolderInfoVO.filePath;
              that.fileAttributeForm.fileStorage =
                res.data.data.fileVirtualFolderInfoVO.fileStorage;
              that.fileAttributeForm.fileInclude =
                res.data.data.fileVirtualFolderInfoVO.include;
              that.fileAttributeForm.fileCreattime =
                res.data.data.fileVirtualFolderInfoVO.createDate;
              that.fileAttributeForm.fileMtime =
                res.data.data.fileVirtualFolderInfoVO.updateDate;
              that.fileAttributeForm.filedesc =
                res.data.data.fileVirtualFolderInfoVO.fileDesc;
            }
          }
        });
    },
    uploadFileList() {
      // 上传按钮事件
      this.uploadVisible = true;
      // 	 this.$nextTick(() => {
      // })
    },
    onSelect(keys, event) {
      console.log("Trigger Select", keys, event);
      this.chooseCopyRoute = keys[0];
    },
    onExpand(expandedKeys) {
      console.log("Trigger Expand", expandedKeys);
      function deepClone(obj) {
        let newObj = Array.isArray(obj) ? [] : {};
        if (obj && typeof obj === "object") {
          for (let key in obj) {
            if (obj.hasOwnProperty(key)) {
              newObj[key] =
                obj && typeof obj[key] === "object"
                  ? deepClone(obj[key])
                  : obj[key];
            }
          }
        }
        return newObj;
      }
      if (expandedKeys.length > 1) {
        console.log(expandedKeys);
        let aaa = deepClone(expandedKeys);
        // let aaa = expandedKeys;
        aaa.splice(0, aaa.length - 1);
        console.log(aaa);
        this.findCopyShowModalInfo(aaa[0]);
      }
    },
    start() {
      this.loading = true;
      setTimeout(() => {
        this.loading = false;
        this.selectedRowKeys = [];
      }, 1000);
    },

    onSelectChange(selectedRowKeys, selectedRows) {
      console.log(selectedRows);
      this.shareData = selectedRows;
      console.log("selectedRowKeys changed: ", selectedRowKeys);
      console.log(selectedRowKeys.length);
      this.selectedRowKeys = selectedRowKeys;
    },

    addClassload(index) {},
    removeClassload(index) {},
    //管理系统弹窗
    showAdmin() {
      this.adminVisible = true;
    },
    //管理系统弹窗
    hideAdmin() {
      this.adminVisible = false;
    },
    changeStar(index) {
      console.log(index, "filled");
      // this.starFilled = this.starFilled == 'filled' ? 'outlined' : 'filled'
      this.isActive = index;
    },

    //选择文件类型赋值
    searchFormTypeChange(e) {
      if (e == "all") {
        this.searchForm.fileType = "不限类型";
      } else {
        this.searchForm.fileType = e;
      }
    },

    // 首页搜索框文件大小改变
    searchFormSizeChange(e) {
      console.log(e);
      if (e == "0~100KB") {
        this.searchForm.startSize = 0;
        this.searchForm.endSize = 102400;
      } else if (e == "100KB~1MB") {
        this.searchForm.startSize = 102400;
        this.searchForm.endSize = 1048576;
      } else if (e == "1MB~10MB") {
        this.searchForm.startSize = 1048576;
        this.searchForm.endSize = 10485760;
      } else if (e == "10MB~100MB") {
        this.searchForm.startSize = 10485760;
        this.searchForm.endSize = 104857600;
      } else if (e == "100MB~1GB") {
        this.searchForm.startSize = 104857600;
        this.searchForm.endSize = 1073741824;
      } else if (e == "1GB以上") {
        this.searchForm.startSize = 1073741824;
        this.searchForm.endSize = "";
      } else {
        this.searchForm.startSize = "";
        this.searchForm.endSize = "";
        this.searchForm.fileSize = "不限大小";
      }
    },

    //搜索筛选框时间范围选择
    onChangeTime(date, dateString) {
      console.log(date, dateString);
      this.searchForm.startData = dateString[0];
      this.searchForm.endData = dateString[1];
    },
    //首页查询文件
    searchFile() {
      console.log(this.searchForm);
      /* 
        没有输入关键字并且也没给出筛选条件的话提示警告
      */
      if (
        this.searchForm.search == "" &&
        this.searchForm.fileType == "不限类型" &&
        this.searchForm.startData == "" &&
        this.searchForm.endData == "" &&
        this.searchForm.startSize == "" &&
        this.searchForm.endSize == "" &&
        this.searchForm.share == "1" &&
        this.searchForm.quote == "1" &&
        this.searchForm.cloudPortal == "1"
      ) {
        this.$message.warning("请给出关键字或给出筛选条件");
        return;
      }

      console.log(11);
      let parentId = this.parentFileId.splice(
        this.parentFileId.length - 1,
        1
      )[0];
      let data = {
        parentId: this.searchForm.scope == "1" ? "" : parentId, //查找范围
        spaceType: this.spaceType, //空间类型
        startDate: this.searchForm.startData, //开始时间
        endDate: this.searchForm.endData, //结束时间
        startFileStorage: this.searchForm.startSize, //大于文件的值
        endFileStorage: this.searchForm.endSize, //小于文件的值
        fileName: this.searchForm.search, //文件名称
        cloudPortal:
          this.searchForm.cloudPortal == "1"
            ? null
            : this.searchForm.cloudPortal == "2"
            ? 1
            : 2, //是否发布
        quote:
          this.searchForm.quote == "1"
            ? null
            : this.searchForm.quote == "2"
            ? 1
            : 2, //是否引用
        share:
          this.searchForm.share == "1"
            ? null
            : this.searchForm.share == "2"
            ? 1
            : 2, //是否分享
      };
      console.log(data);
      // console.log(this.parentFileId);
      // console.log(parentId);
      axios
        .post(
          this.serviceHttp +
            "/cloudoffice/fileVirtualFolderInfo/selectAllSpace",
          data,
          {
            headers: {
              "Content-Type": "application/json",
              Authorization: "Bearer " + this.dataToken,
            },
          }
        )
        .then((res) => {
          console.log(res);
          if (res.data.code == 200) {
            this.$message.success(res.data.message);
            //列表渲染
            this.FileListData = [];
            this.FileListData = res.data.data;
          }
        });
    },
    //重置搜索条件
    resetSearchFile() {
      console.log(1122);
      this.searchForm.search = "";
      this.searchForm.scope = "all";
      this.searchForm.fileType = "不限类型";
      this.searchForm.fileSize = "不限大小";
      this.searchForm.startSize = "";
      this.searchForm.endSize = "";
      this.searchForm.search = "";
      this.searchForm.share = "1";
      this.searchForm.quote = "1";
      this.searchForm.cloudPortal = "1";
    },
    local(e, a, i) {
      this.cardBox.left = e.x + 20 + "px";
      this.cardBox.top = e.y + 20 + "px";
      this.cardBox.display = "block";
      this.listCard.id = i;
      // console.log(a);
      this.cardBoxInfo.size = a.fileStorage;
      this.cardBoxInfo.name = a.fileName;
      this.cardBoxInfo.createTime = a.createDate;
      this.cardBoxInfo.updataTime = a.updateDate;
      this.cardBoxInfo.path = a.filePath;
      this.cardBoxInfo.share = a.share;
      this.cardBoxInfo.cause = a.quote;
      this.cardBoxInfo.send = a.cloudPortal;
    },
    leaveLocal() {
      this.cardBox.display = "none";
      this.listCard.id = "-1";
    },

    //开卡片文件双击进入文件夹
    dblclickFileList(record, index) {
      let that = this;
      console.log(record); //fileNavigation
      that.fileNavigation = record.filePath.split("/");
      event.stopPropagation(); //阻止默认事件
      this.pageNum = 1;
      if (record.fileType == "folder") {
        //文件夹
        let data = {
          parentId: record.id,
          spaceType: record.spaceType,
          pageNum: this.pageNum,
          pageSize: this.pageSize,
          isFolder: this.isFolder,
          order: "update_date desc",
        };

        console.log(data);

        axios
          .post(
            this.serviceHttp +
              "/cloudoffice/fileVirtualFolderInfo/selectAllSpace",
            data,
            {
              headers: {
                "Content-Type": "application/json",
                Authorization: "Bearer " + this.dataToken,
              },
            }
          )
          .then((res) => {
            if (res.data.code == 200) {
              that.FileListData = [];
              that.FileListData = res.data.data;
              console.log(that.FileListData);
              this.parentFileId.push(record.id); //获取到父级文件夹ID
            }
          })
          .catch((error) => {
            console.log(error);
          });
      } else {
        //预览
        console.log("====预览");
        // this.lookVisibleVisible = true;

        // let id = "";
        let url =
          that.serviceHttp + "/cloudoffice/onlineDownloadFile?id=" + record.id;
        let path = "http://192.168.49.11:8012";
        let fileUrl = `${path}/onlinePreviewMd5?url=${
          Base64.encode(url) + "&suffix=" + record.fileType
        }`;
        window.open(fileUrl);
      }
    },
  },
  destroyed() {
    window.onresize = null;
    window.removeEventListener("scroll", true);
  },

  filters: {
    //字节转换KB
    KBDate(limita) {
      let limit = parseInt(limita);
      if (limit > 0) {
        // console.log("大小" + limit);
        var size = "";
        if (limit < 0.1 * 1024) {
          //如果小于0.1KB转化成B
          let intNum = parseInt(limit);
          size = intNum.toFixed(2) + " B";
        } else if (limit < 0.999 * 1024 * 1024) {
          //如果小于0.1MB转化成KB
          size = (limit / 1024).toFixed(2) + "KB";
        } else if (limit < 0.999 * 1024 * 1024 * 1024) {
          //如果小于0.1GB转化成MB
          size = (limit / (1024 * 1024)).toFixed(2) + "MB";
        } else if (limit < 0.999 * 1024 * 1024 * 1024 * 1024) {
          //其他转化成GB
          size = (limit / (1024 * 1024 * 1024)).toFixed(2) + "G";
        } else {
          size = (limit / (1024 * 1024 * 1024 * 1024)).toFixed(2) + "T";
        }

        var sizestr = size + "";
        var len = sizestr.indexOf(".");
        var dec = sizestr.substr(len + 1, 2);
        if (dec == "00") {
          //当小数点后为00时 去掉小数部分
          return sizestr.substring(0, len) + sizestr.substr(len + 3, 2);
        }
        return sizestr;
      } else {
        return limit;
      }
    },
  },
  watch: {
    checkedKeys(val) {
      console.log("onCheck", val);
    },
    uploadHttp(val) {
      console.log(val);
      // alert(val)
      this.dataUploadHttp = val;
    },
    queryFileHttp(val) {
      // alert(val)
      this.dataQueryFileHttp = val;
    },
    token(val) {
      console.log(val);
      this.dataToken = val;
    },
    searchForm: {
      handler(newVal, oldVal) {
        console.log(newVal, oldVal);
        if (newVal.search == "") {
          this.fileList(); //如果输入框为空那么重新渲染列表
        }
      },
      deep: true,
    },
    spaceType(val) {
      console.log(val);
      this.fileNavigation =
        val == 0 ? ["个人空间"] : val == 1 ? ["机构空间"] : ["系统空间"];
    },
  },
};
</script>

<style lang="less" scoped>
.filesUpload {
  // min-width: 1280px;
  /* 布局背景色 */
  .ant-layout-header,
  .ant-layout-footer,
  .ant-layout-sider,
  .ant-layout-content {
    background: #fff;
  }
  .searchRight {
    float: right;
  }
  .box_left {
    min-width: 1076px;
  }
  /* 

 左侧菜单样式

 */
  .ant-layout-sider {
    // height: 80vh;
    height: 100%;
    position: relative;
    border-right: 1px solid #eee;

    .ant-tree {
      margin-top: 20px;
    }

    .treeContainer {
      height: 90vh;
      overflow: auto;
      text-align: left;
      background-color: #f7f7f7;
      padding-left: 10px;
    }

    .space {
      width: 100%;
      position: absolute;
      left: 0;
      bottom: 10px;
      height: 30px;

      .text {
        font-size: 12px;
      }

      .ant-progress {
        width: 70%;
        display: inline-block;
        margin-left: 1%;

        .ant-progress-text {
          span {
            font-size: 12px;
          }
        }
      }
    }
  }

  /* 

 右侧上面工具栏的样式

 */
  .toolbar {
    background: #f2f2f2;
    height: 50px;
    line-height: 50px;
    padding: 0;

    .ant-btn-link {
      color: #314659;
    }

    .toolbar-input-search {
      line-height: 50px;
      padding-right: 5px;

      .ant-input {
        width: 78%;
        vertical-align: baseline;
      }
    }
  }

  /* 

面包屑菜单栏样式 

 */
  .breadcrumb {
    padding: 0;

    .breadcrumb_left {
      text-align: left;

      // padding-left: 40px;
      .ant-breadcrumb {
        line-height: 60px;
        display: inline-block;
      }
    }

    .breadcrumb_center {
      text-align: left;
      line-height: 50px;

      .ant-breadcrumb {
        line-height: 60px;
      }
    }

    .breadcrumb_right {
      text-align: right;
      padding-right: 20px;
      .ant-btn-group {
        margin-right: 20%;
      }
    }
  }

  /* 表格样式 */
  .file-table {
    .icon {
      width: 20px;
      height: 20px;
    }
  }

  /deep/ .ant-row {
    overflow-y: auto;
  }

  /* 列表样式 */
  .file-list {
    //     overflow-y: auto;
    // height: 70vh;
    padding-left: 24px;
    // border: 1px solid blue;
    .ant-col {
    }
    .listFileBox {
      width: 130px;
      // border: 1px solid pink;
      height: 140px;
      overflow: hidden;
      margin: 10px;
    }
    .listFileBox:hover {
      background: #e5f3ff;
    }

    .list-content {
      // border: 1px solid red;
      width: 100%;
      // position: relative;
      // background: #eee;

      .list-menu {
        // position: absolute;
        // top: 0;
        // right: 5px;
        font-size: 18px;
        display: flex;
        justify-content: space-between;
        padding: 5px;

        .list-checkbox {
          /deep/.ant-checkbox-input {
            margin: 0;
            border-radius: 50%;
          }
        }
        .list-iconbox {
          // border: 1px solid blue;
          color: #a1a1a1;
          display: flex;
          justify-content: space-around;
          align-items: center;
        }
      }
      .imgFile {
        // border: 1px solid black;
        display: block;
        margin: 0 auto;
        width: 70px;
        margin-top: -10px;
      }
      .fileListImg {
        display: block;
        text-align: center;
        margin-bottom: 10px;
      }

      .list-icon {
        width: 50px;
        height: 100px;
      }

      p {
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
    }
  }
}
.activeStar {
  color: yellow;
}
.wfm-file-icon {
  cursor: pointer;
  margin: 0 2px;
}

.filesUpload {
  /deep/.ant-progress-show-info .ant-progress-outer {
    margin-right: calc(-3em - 8px);
    padding-right: calc(3em + 8px);
    width: 120px;
  }
}

.wfm-attribute-container {
  .ant-modal-body {
    height: 600px;
    overflow: auto;
  }
}

.wfm-attribute-container {
  .file-share {
    text-align: center;
  }
}

.filesUpload::-webkit-scrollbar {
  display: none;
}

.float_layer {
  width: 510px;
  border-top: 1px solid #d3d3d3;
  display: none;
  border-top-left-radius: 5px;
  border-top-right-radius: 5px;
  display: flex;
  align-items: center;
  position: absolute;
}

.float_layer h2 {
  background: #fff;
  height: 70px;
  line-height: 70px;
  padding-left: 10px;
  font-size: 22px;
  color: #333;
  // background: url(images/title_bg.gif) repeat-x;
  border-bottom: 2px solid #d3d3d3;
  position: relative;
  border-left: 1px solid #d3d3d3;
  border-right: 1px solid #d3d3d3;
  margin: 0;
}

.float_layer .min {
  width: 21px;
  height: 20px;
  // background: url(images/min.gif) no-repeat 0 bottom;
  position: absolute;
  top: 2px;
  right: 25px;
}

.float_layer .min:hover {
  // background: url(images/min.gif) no-repeat 0 0;
}

.float_layer .max {
  width: 21px;
  height: 20px;
  // background: url(images/max.gif) no-repeat 0 bottom;
  position: absolute;
  top: 2px;
  right: 25px;
}

.float_layer .max:hover {
  // background: url(images/max.gif) no-repeat 0 0;
}

.float_layer .close {
  width: 21px;
  height: 20px;
  // background: url(images/close.gif) no-repeat 0 bottom;
  position: absolute;
  top: 2px;
  right: 3px;
}

.float_layer .close:hover {
  // background: url(images/close.gif) no-repeat 0 0;
}

.float_layer .content {
  // height: 160px;
  overflow: hidden;
  font-size: 14px;
  line-height: 18px;
  color: #666;
  text-indent: 28px;
  background: #fff;
  border-left: 1px solid #d3d3d3;
  border-right: 1px solid #d3d3d3;
  border-bottom: 1px solid #d3d3d3;
  border-bottom-left-radius: 5px;
  border-bottom-right-radius: 5px;
  position: relative;
}

.float_layer .wrap {
  padding: 10px;
}

.float_layer_title_icon {
  color: #409eff;
  font-weight: bold;
  margin-right: 10px;
  margin-top: 3px;
}

.float_title_l {
  display: flex;
  align-items: center;
  line-height: 70px;
}
.float_footer {
  height: 10px;
  opacity: 0.5;
}

.icon_r {
  font-size: 16px;
  font-weight: bold;
  color: #646464;
}

h6 {
  margin: 0;
  padding: 0;
}
p {
  padding: 0;
  margin: 0;
}
/deep/ .ant-table-body {
  overflow-y: scroll;
  // height:70vh;
}

/deep/ .ant-progress-inner {
  vertical-align: baseline;
  background-color: #ffffff;
}
.copy {
  /deep/.ant-modal-body {
    overflow-y: scroll;
    height: 40vh;
  }
}

.searchModal {
  width: 350px;
  padding: 10px 0;
  position: relative;
  right: 50px;
  top: 20px;
  /deep/.ant-form-item {
    margin-bottom: 0;
  }
}
.footButton {
  // border: 1px solid black;
  text-align: center;
  margin-top: 10px;
}

.cardBox {
  .ant-form-item {
    margin-bottom: 0;
  }
}

.tab1 {
  /deep/.ant-form-item {
    margin-bottom: 0;
  }
}
</style>
