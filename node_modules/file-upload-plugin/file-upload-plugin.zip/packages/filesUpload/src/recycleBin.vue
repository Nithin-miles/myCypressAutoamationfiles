<template>
  <div class="main">
    <div class="top">
      <div class="title">回收站</div>
      <div class="right">
        <a-button class="btn" type="primary" @click="deleteAll"
          ><a-icon type="delete" />清空回收站</a-button
        >
        <div class="info">已全部加载 共{{ FileListData.length }}个</div>
      </div>
    </div>
    <a-table
      align="left"
      class="tableBoxComponents"
      :row-selection="{
        selectedRowKeys: selectedRowKeys,
        onChange: onSelectChange,
      }"
      :columns="FileListColumns"
      :data-source="FileListData"
      row-key="id"
      :customRow="customClick"
    >
      <span slot="fileNameTitle"
        >已选中{{ selectedRowKeys.length }}个文件/文件夹
        <span
          style="padding-left: 10px; color: #2fb4ff; font-weight: 600"
          @click="returnAll"
        >
          <a-icon type="redo" />还原
        </span>
      </span>
      <template slot="fileName" slot-scope="text, record">
        <div
          style="
            display: flex;
            align-items: baseline;
            justify-content: space-between;
          "
        >
          <span>
            <a-icon :type="record.type" />
            <svg class="icon" aria-hidden="true" style="vertical-align: middle">
              <use :xlink:href="'#icon-' + record.type"></use>
            </svg>
            <span v-if="record.fileType == 'folder'">
              <a style="cursor: pointer">
                <img
                  src="../../assets/fileIcon/icon-big-folder.png"
                  style="max-width: 30px"
                />
                <span>{{ record.fileName }}</span>
              </a>
            </span>

            <span
              v-else-if="
                record.fileType == 'jpg' ||
                record.fileType == 'png' ||
                record.fileType == 'jpeg' ||
                record.fileType == 'gif' ||
                record.fileType == 'bmp' ||
                record.fileType == 'dxf' ||
                record.fileType == 'bip'
              "
            >
              <a style="cursor: pointer">
                <img
                  src="../../assets/fileIcon/tupian.png"
                  style="max-width: 30px"
                />
                <span>{{ record.fileName }}</span>
              </a>
            </span>
            <span
              v-else-if="record.fileType == 'zip' || record.fileType == 'rar'"
            >
              <a style="cursor: pointer">
                <img
                  src="../../assets/fileIcon/zipRar.png"
                  style="max-width: 30px"
                />
                <span>{{ record.fileName }}</span>
              </a>
            </span>
            <span
              v-else-if="
                record.fileType == 'cda' ||
                record.fileType == 'wav' ||
                record.fileType == 'aif' ||
                record.fileType == 'au' ||
                record.fileType == 'mp3' ||
                record.fileType == 'wma' ||
                record.fileType == 'mmf' ||
                record.fileType == 'amr' ||
                record.fileType == 'aac' ||
                record.fileType == 'flac'
              "
            >
              <a style="cursor: pointer">
                <img
                  src="../../assets/fileIcon/yinpin.png"
                  style="max-width: 30px"
                />
                <span>{{ record.fileName }}</span>
              </a>
            </span>
            <span
              v-else-if="
                record.fileType == 'avi' ||
                record.fileType == 'wmv' ||
                record.fileType == 'mpg' ||
                record.fileType == 'mov' ||
                record.fileType == 'rm' ||
                record.fileType == 'ram' ||
                record.fileType == 'swf' ||
                record.fileType == 'flv' ||
                record.fileType == 'mp4'
              "
            >
              <a style="cursor: pointer">
                <img
                  src="../../assets/fileIcon/shipin.png"
                  style="max-width: 30px"
                />
                <span>{{ record.fileName }}</span>
              </a>
            </span>
            <span
              v-else-if="record.fileType == 'docx' || record.fileType == 'doc'"
            >
              <a style="cursor: pointer">
                <img
                  src="../../assets/fileIcon/word.png"
                  style="max-width: 30px"
                />
                <span>{{ record.fileName }}</span>
              </a>
            </span>
            <span
              v-else-if="record.fileType == 'xlsx' || record.fileType == 'xls'"
            >
              <a style="cursor: pointer">
                <img
                  src="../../assets/fileIcon/xlsx.png"
                  style="max-width: 30px"
                />
                <span>{{ record.fileName }}</span>
              </a>
            </span>
            <span
              v-else-if="record.fileType == 'ppt' || record.fileType == 'pptx'"
            >
              <a style="cursor: pointer">
                <img
                  src="../../assets/fileIcon/ppt.png"
                  style="max-width: 30px"
                />
                <span>{{ record.fileName }}</span>
              </a>
            </span>
            <span v-else-if="record.fileType == 'pdf'">
              <a style="cursor: pointer">
                <img
                  src="../../assets/fileIcon/pdf.png"
                  style="max-width: 30px"
                />
                <span>{{ record.fileName }}</span>
              </a>
            </span>
            <span v-else-if="record.fileType == 'txt'">
              <a style="cursor: pointer">
                <img
                  src="../../assets/fileIcon/txt.png"
                  style="max-width: 30px"
                />
                <span>{{ record.fileName }}</span>
              </a>
            </span>
            <span v-else-if="record.fileType == 'txt'">
              <a style="cursor: pointer">
                <img
                  src="../../assets/fileIcon/txt.png"
                  style="max-width: 30px"
                />
                <span>{{ record.fileName }}</span>
              </a>
            </span>
            <span v-else-if="record.fileType == 'csv'">
              <a style="cursor: pointer">
                <img
                  src="../../assets/fileIcon/csv.png"
                  style="max-width: 30px"
                />
                <span>{{ record.fileName }}</span>
              </a>
            </span>
            <span
              v-else-if="
                record.fileType == 'mdb' ||
                record.fileType == 'dbf' ||
                record.fileType == 'mdf' ||
                record.fileType == 'db' ||
                record.fileType == 'wdb'
              "
            >
              <a style="cursor: pointer">
                <img
                  src="../../assets/fileIcon/shujvku.png"
                  style="max-width: 30px"
                />
                <span>{{ record.fileName }}</span>
              </a>
            </span>
            <span
              v-else-if="
                record.fileType == 'shp' ||
                record.fileType == 'shx' ||
                record.fileType == 'dbf' ||
                record.fileType == 'prj' ||
                record.fileType == 'sbn' ||
                record.fileType == 'sbx' ||
                record.fileType == 'sbn' ||
                record.fileType == 'fbn' ||
                record.fileType == 'fbx' ||
                record.fileType == 'ain' ||
                record.fileType == 'ixs' ||
                record.fileType == 'mxs' ||
                record.fileType == 'atx' ||
                record.fileType == 'cpg'
              "
            >
              <a style="cursor: pointer">
                <img
                  src="../../assets/fileIcon/shapefile.png"
                  style="max-width: 30px"
                />
                <span>{{ record.fileName }}</span>
              </a>
            </span>

            <span v-else-if="record.fileType == 'sde'">
              <a style="cursor: pointer">
                <img
                  src="../../assets/fileIcon/kongjianshujv.png"
                  style="max-width: 30px"
                />
                <span>{{ record.fileName }}</span>
              </a>
            </span>
            <span v-else-if="record.fileType == 'tif'">
              <a style="cursor: pointer">
                <img
                  src="../../assets/fileIcon/tuxiandili.png"
                  style="max-width: 30px"
                />
                <span>{{ record.fileName }}</span>
              </a>
            </span>
            <span v-else-if="record.fileType == 'img'">
              <a style="cursor: pointer">
                <img
                  src="../../assets/fileIcon/img.png"
                  style="max-width: 30px"
                />
                <span>{{ record.fileName }}</span>
              </a>
            </span>
            <span v-else-if="record.fileType == 'mxd'">
              <a style="cursor: pointer">
                <img
                  src="../../assets/fileIcon/mxd.png"
                  style="max-width: 30px"
                />
                <span>{{ record.fileName }}</span>
              </a>
            </span>

            <span v-else>
              <a style="cursor: pointer">
                <img
                  src="../../assets/fileIcon/qita.png"
                  style="max-width: 30px"
                />
                <span>{{ record.fileName }}</span>
              </a>
            </span>
          </span>
        </div>
      </template>
      <template slot="fileStorage" slot-scope="text">
        <!-- <div>{{ text }}</div> -->
        <span>
          {{ text | KBDate(text) }}
        </span>
      </template>
      <template slot="existenceDate" slot-scope="text">
        <span
          :style="
            parseInt(Number(text) / (1000 * 60 * 60 * 24)) <= 5
              ? { color: 'red' }
              : { color: '' }
          "
        >
          <!-- 时间大于一天显示天数，时间小于一天显示小时，时间结束为00:00:00 -->
          <!-- {{
            parseInt(Number(text) / (1000 * 60 * 60 * 24)) >= 1
              ? parseInt(Number(text) / (1000 * 60 * 60 * 24))
              : Number(text) != 0
              ? toHHmmss(Number(text))
              : "00:00:00"
          }} -->
          {{
            parseInt(Number(text) / (1000 * 60 * 60 * 24)) >= 1
              ? parseInt(Number(text) / (1000 * 60 * 60 * 24))+'天'
              : Number(text) > 0
              ? toHHmmss(Number(text))
              : "00:00:00"
          }}
        </span>
      </template>
    </a-table>
    <a-menu :style="menuStyle" v-if="menuVisible" @click="handleClick">
      <a-menu-item key="1">还原</a-menu-item>
      <a-menu-item key="2">彻底删除</a-menu-item>
    </a-menu>
    <!-- 保存失败提示框 -->
    <a-modal v-model="visible" title="还原失败" on-ok="handleOk">
      <template slot="footer">
        <a-button key="back" @click="handleCancel"> 取消 </a-button>
        <a-button key="submit" type="primary" @click="handleOk">
          确定
        </a-button>
      </template>
      <div style="margin-bottom: 30px">
        {{ message }}
      </div>
      <h3>是否更换保存路径？</h3>
    </a-modal>
    <!-- 更换保存路径弹框 -->
    <a-modal
      class="copy"
      title="保存到"
      :visible="routeVisible"
      v-if="routeVisible"
      @ok="copyHandleOk"
      @cancel="copyHandleCancel"
    >
      <template slot="footer">
        <a-button key="submit" type="primary" @click="copyHandleOk">
          确定
        </a-button>
        <a-button key="back" @click="copyHandleCancel"> 取消 </a-button>
      </template>

      <a-tree
        :load-data="onLoadData"
        :defaultExpandParent="false"
        :selected-keys="selectedKeys"
        :tree-data="findSpace"
        @expand="onExpand"
        @select="onSelect"
      />
    </a-modal>
  </div>
</template>

<script>
import axios from "axios";
import Vue from "vue";
Vue.prototype.$axios = axios;
const FileListColumns = [
  {
    dataIndex: "fileName",
    slots: { title: "fileNameTitle" },
    scopedSlots: { customRender: "fileName" },
    align: "left",
    width: 300,
  },
  {
    title: "文件大小",
    dataIndex: "fileStorage",
    scopedSlots: { customRender: "fileStorage" },
    sorter: (a, b) => a.fileStorage > b.fileStorage,
    align: "left",
  },
  {
    title: "删除时间",
    dataIndex: "recycleDate",
    sorter: (a, b) => a.recycleDate > b.recycleDate,
    align: "left",
  },
  {
    title: "有效时间",
    dataIndex: "existenceDate",
    scopedSlots: { customRender: "existenceDate" },
    sorter: (a, b) => a.existenceDate > b.existenceDate,
    align: "left",
  },
];
export default {
  props: {
    serviceHttp: {
      //服务接口
      type: String,
      default: "http://192.168.19.29:6001",
    },
    token: {
      type: String,
      default: "ba160393-0dc0-415a-8f71-81eef251cdf2",
    },
  },
  data() {
    return {
      FileListColumns,
      FileListData: [],
      menuData: [], //右键
      chooseData: [], //选择的文件集合
      selectedRowKeys: [], //选择文件id
      menuVisible: false, //表格右键菜单
      menuStyle: {
        //右键菜单样式
        position: "absolute",
        top: "0",
        left: "0",
        border: "1px solid #eee",
      },
      //点击右键菜单
      customClick: (record) => ({
        on: {
          contextmenu: (e) => {
            e.preventDefault();
            this.menuData = [];
            this.menuData.push(record);
            console.log(this.menuData);
            this.menuVisible = true;
            this.menuStyle.top = e.clientY + "px";
            this.menuStyle.left = e.clientX + 10 + "px";
            document.body.addEventListener("click", this.bodyClick);
          },
        },
      }),

      //提示消息
      message: "",
      visible: false, //还原失败弹框
      routeVisible: false,
      //复制路径
      findSpace: [{ title: "个人空间", key: "0", children: [] }],
      selectedKeys: [],
      arrarr: [],
      chooseCopyRoute: "",
    };
  },
  mounted() {
    this.getInfo();
  },
  methods: {
    getInfo() {
      let data = {
        // pageNum: 1,
        // pageSize: 20,
        order: "recycle_date desc",
      };
      console.log(this.token);
      axios
        .post(
          this.serviceHttp +
            "/cloudoffice/fileVirtualFolderInfo/selectRecycleSpace",
          data,
          {
            headers: {
              "Content-Type": "application/json",
              Authorization: "Bearer " + this.token,
            },
          }
        )
        .then((res) => {
          console.log(res);
          if (res.data.code == 200) {
            this.FileListData = res.data.data;
            console.log(this.FileListData);
          }
        })
        .catch((error) => {
          console.log(error);
        });
    },
    //选中的对象
    onSelectChange(selectedRowKeys, selectedRows) {
      console.log(selectedRows);
      this.chooseData = selectedRows;
      console.log("selectedRowKeys changed: ", selectedRowKeys);
      console.log(selectedRowKeys.length);
      this.selectedRowKeys = selectedRowKeys;
    },
    //时间戳转换成小时
    toHHmmss(e) {
      var time;
      var hours = parseInt((e % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      var minutes = parseInt((e % (1000 * 60 * 60)) / (1000 * 60));
      var seconds = parseInt((e % (1000 * 60)) / 1000);
      console.log(seconds);
      time =
        (hours < 10 ? "0" + hours : hours) +
        ":" +
        (minutes < 10 ? "0" + minutes : minutes) +
        ":" +
        (seconds < 10 ? "0" + seconds : seconds);
      return time;
    },
    //点击其他位置菜单框隐藏
    bodyClick() {
      this.menuVisible = false;
      this.menuData = []; //清除右键菜单缓存对象
      document.body.removeEventListener("click", this.bodyClick);
    },
    //点击菜单选项
    handleClick(e) {
      console.log(e);
      if (e.key == "1") {
        this.return("one");
      } else {
        this.delete();
      }
    },
    //全部还原
    returnAll() {
      if (this.chooseData.length == 0) {
        this.$message.warning("请选择需要还原的文件");
      } else {
        this.return("all");
      }
    },
    //点击还原
    return(e) {
      console.log(this.menuData);
      let data = [];
      let that = this;
      if (e == "one") {
        this.menuData.forEach((item) => {
          data.push({
            id: item.id,
            isFolder: item.isFolder,
          });
        });
      } else {
        this.chooseData.forEach((item) => {
          data.push({
            id: item.id,
            isFolder: item.isFolder,
          });
        });
      }
      axios
        .post(
          this.serviceHttp +
            "/cloudoffice/fileVirtualFolderInfo/restoreRecycleFile",
          data,
          {
            headers: {
              "Content-Type": "application/json",
              Authorization: "Bearer " + this.token,
            },
          }
        )
        .then((res) => {
          console.log(res);
          if (res.data.code == 200) {
            that.$message.success("还原成功");
            that.getInfo();
          } else if (res.data.code == 501) {
            that.message = res.data.message;
            that.visible = true; //还原失败开启提示框
          }
        })
        .catch((error) => {
          console.log(error);
        });
    },
    //单个删除
    delete() {
      let data = [];
      let that = this;
      this.menuData.forEach((item) => {
        data.push({
          id: item.id,
          isFolder: item.isFolder,
        });
      });
      axios
        .post(
          this.serviceHttp +
            "/cloudoffice/fileVirtualFolderInfo/cleanRecycleFile",
          data,
          {
            headers: {
              "Content-Type": "application/json",
              Authorization: "Bearer " + this.token,
            },
          }
        )
        .then((res) => {
          console.log(res, "delete");
          if (res.data.code == 200) {
            that.$message.success("删除成功");
            that.getInfo();
          } else {
          }
        })
        .catch((error) => {
          console.log(error);
        });
    },
    //清空回收站
    deleteAll() {
      let that = this;
      axios
        .delete(
          this.serviceHttp +
            "/cloudoffice/fileVirtualFolderInfo/cleanAllRecycleFile",
          {
            headers: {
              "Content-Type": "application/json",
              Authorization: "Bearer " + this.token,
            },
          }
        )
        .then((res) => {
          console.log(res);
          if (res.data.code == 200) {
            that.$message.success("已全部删除");
            that.getInfo();
          }
        })
        .catch((error) => {
          console.log(error);
        });
    },
    //还原失败开启弹框
    showModal() {
      this.visible = true;
    },
    handleOk(e) {
      this.visible = false;
      this.routeVisible = true; //打开选择文件弹框
      this.findCopyShowModalInfo("-1"); //初始化文件树
    },
    //查询个人空间
    findCopyShowModalInfo(e) {
      let data = {
        parentId: e ? e : "-1",
        spaceType: 0,
        isFolder: 1,
      };
      axios
        .post(
          this.serviceHttp +
            "/cloudoffice/fileVirtualFolderInfo/selectAllSpace",
          data,
          {
            headers: {
              "Content-Type": "application/json",
              Authorization: "Bearer " + this.token,
            },
          }
        )
        .then((res) => {
          console.log(res);
          if (res.data.code == 200) {
            if (e == "-1") {
              this.findSpace[0].children = this.treeArry(res.data.data);
            } else {
              this.arrarr = this.treeArry(res.data.data);
            }
          }
        })
        .catch((error) => {
          console.log(error);
        });
    },
    treeArry(arr) {
      let returnArr = [];
      arr.forEach((item) => {
        console.log(item.isFolder);
        returnArr.push({
          title: item.fileName,
          key: item.id,
        });
      });
      return returnArr;
    },
    handleCancel(e) {
      this.visible = false;
       this.getInfo();
    },

    //树型控件懒加载
    onLoadData(treeNode) {
      return new Promise((resolve) => {
        if (treeNode.dataRef.children) {
          resolve();
          return;
        }
        setTimeout(() => {
          treeNode.dataRef.children = this.arrarr;
          this.findSpace = [...this.findSpace];
          resolve();
        }, 1500);
      });
    },
    onSelect(keys, event) {
      console.log("Trigger Select", keys, event);
      this.chooseCopyRoute = keys[0];
    },
    onExpand(expandedKeys) {
      console.log("Trigger Expand", expandedKeys);
      function deepClone(obj) {
        let newObj = Array.isArray(obj) ? [] : {};
        if (obj && typeof obj === "object") {
          for (let key in obj) {
            if (obj.hasOwnProperty(key)) {
              newObj[key] =
                obj && typeof obj[key] === "object"
                  ? deepClone(obj[key])
                  : obj[key];
            }
          }
        }
        return newObj;
      }
      if (expandedKeys.length > 1) {
        console.log(expandedKeys);
        let aaa = deepClone(expandedKeys);
        // let aaa = expandedKeys;
        aaa.splice(0, aaa.length - 1);
        console.log(aaa);
        this.findCopyShowModalInfo(aaa[0]);
      }
    },
    //复制移动弹框点击确定按钮
    copyHandleOk(e) {
      // this.copyLoading = true;
      this.copyRoute();
      this.routeVisible = false;

      setTimeout(() => {}, 2000);
    },

    copyRoute(e) {
      let virtualFileAndFolderInfoVOList = [];
      this.chooseData.forEach(item =>{
        virtualFileAndFolderInfoVOList.push({
          id:item.id,
          isFolder:item.isFolder,
        })
      })
      let data = {
        virtualFileAndFolderInfoVOList: virtualFileAndFolderInfoVOList,
        targetFileVirtualFolderInfoVO: {
          id: this.chooseCopyRoute,
          spaceType: "0",
          organizationId: null,
          applicationId: null,
        },
      };
      axios
        .put(
          this.serviceHttp +
            "/cloudoffice/fileVirtualFolderInfo/restoreFileChoosePath",
          data,
          {
            headers: {
              "Content-Type": "application/json",
              Authorization: "Bearer " + this.token,
            },
          }
        )
        .then((res) => {
          console.log(res);
          if (res.data.code == 200) {
            this.$message.success(res.data.message)
            this.getInfo();
          }
        })
        .catch((error) => {
          console.log(error);
        });
    },

    copyHandleCancel(e) {
      console.log("Clicked cancel button");
      this.routeVisible = false;
      this.getInfo();
    },
  },
  filters: {
    //字节转换KB
    KBDate(limita) {
      let limit = parseInt(limita);
      if (limit > 0) {
        console.log("大小" + limit);
        var size = "";
        if (limit < 0.1 * 1024) {
          //如果小于0.1KB转化成B
          let intNum = parseInt(limit);
          size = intNum.toFixed(2) + " B";
        } else if (limit < 0.999 * 1024 * 1024) {
          //如果小于0.1MB转化成KB
          size = (limit / 1024).toFixed(2) + "KB";
        } else if (limit < 0.999 * 1024 * 1024 * 1024) {
          //如果小于0.1GB转化成MB
          size = (limit / (1024 * 1024)).toFixed(2) + "MB";
        } else if (limit < 0.999 * 1024 * 1024 * 1024 * 1024) {
          //其他转化成GB
          size = (limit / (1024 * 1024 * 1024)).toFixed(2) + "G";
        } else {
          size = (limit / (1024 * 1024 * 1024 * 1024)).toFixed(2) + "T";
        }

        var sizestr = size + "";
        var len = sizestr.indexOf(".");
        var dec = sizestr.substr(len + 1, 2);
        if (dec == "00") {
          //当小数点后为00时 去掉小数部分
          return sizestr.substring(0, len) + sizestr.substr(len + 3, 2);
        }
        return sizestr;
      } else {
        return limit;
      }
    },
  },
};
</script>

<style lang="less" scoped>
.icon {
  width: 20px;
  height: 20px;
}
.top {
  display: flex;
  justify-content: space-between;
  // border: 1px solid black;
  .title {
    font-size: 20px;
    font-weight: 600;
    margin-top: 20px;
    margin-left: 10px;
  }
  .right {
    // border: 1px solid red;
    margin-right: 100px;
    margin-top: 20px;
    .btn {
      display: block;
      margin-bottom: 10px;
      border-radius: 20px;
    }
    .info {
      margin-bottom: 10px;
    }
  }
}
</style>
