<template>
<!-- 

 文件列表

 -->
<a-layout class="filesUpload">
  <a-layout-sider v-model="collapsed" :collapsedWidth="0">
    <div class="treeContainer">
      <a-tree :tree-data="treeData" show-icon :default-selected-keys="['0-0-0']">
        <a-icon slot="switcherIcon" type="down" />
        <a-icon slot="folder" type="folder" />
        <a-icon slot="file" type="file" />
        <template slot="custom" slot-scope="{ selected }">
          <a-icon :type="selected ? 'frown' : 'frown-o'" />
        </template>
      </a-tree>
    </div>
    <div class="space" v-if="!collapsed">
      <span class="text">我的空间</span>
      <a-progress :stroke-color="{

        from: '#108ee9',

        to: '#87d068',

      }" :percent="50" status="active">
        <template #format="percent">
          <span>{{ percent }}/200</span>
        </template>
      </a-progress>
    </div>
  </a-layout-sider>
  <a-layout>
    <a-layout-header class="toolbar">
      <a-row>
        <a-col :span="11" :xxl="20" :xl="16" :lg="16" :md="12" style="display: flex;align-items: center;">
          <a-button type="link" @click="uploadFileList">
            <a-icon type="upload" :style="{ color: '#108ee9' }" /> 上传
          </a-button>
          <a-button type="link" class="visible-lg-inline">
            <a-icon type="folder-add" :style="{ color: '#fa8c16' }" /> 新建文件夹
          </a-button>
          <a-button type="link">
            <a-icon type="download" :style="{ color: '#87d068' }" /> 下载
          </a-button>
          <a-button type="link" class="visible-lg-inline" @click="shareFileList">
            <a-icon type="share-alt" :style="{ color: '#108ee9' }" /> 分享
          </a-button>
          <a-button type="link">
            <a-icon type="delete" :style="{ color: '#f50' }" /> 删除
          </a-button>
          <a-button type="link" class="visible-lg-inline">
            <a-icon type="copy" :style="{ color: '#108ee9' }" /> 复制到
          </a-button>
          <a-button type="link" class="visible-lg-inline">
            <a-icon type="drag" :style="{ color: '#108ee9' }" /> 移动到
          </a-button>

          <a-dropdown :trigger="['click']" :placement="'bottomCenter'">
            <a class="ant-dropdown-link" @click="e => e.preventDefault()">
              <a-button type="link">
                <a-icon type="ellipsis" :style="{ color: '#108ee9' }" /> 更多
              </a-button>
            </a>
            <a-menu slot="overlay">
              <a-menu-item>
                <a href="javascript:;" @click="shareFileList">分享</a>
              </a-menu-item>
              <a-menu-item>
                <a href="javascript:;">复制到</a>
              </a-menu-item>
              <a-menu-item>
                <a href="javascript:;">复制</a>
              </a-menu-item>
              <a-menu-item>
                <a href="javascript:;">复制</a>
              </a-menu-item>
              <a-menu-item>
                <a href="javascript:;">剪切</a>
              </a-menu-item>
              <a-menu-item>
                <a href="javascript:;">添加到收藏夹</a>
              </a-menu-item>
              <a-menu-item>
                <a href="javascript:;">收藏</a>
              </a-menu-item>
            </a-menu>
          </a-dropdown>
          <a-button type="primary" class="visible-lg-inline" @click="showAdmin">
            管理后台
          </a-button>
        </a-col>
        <a-col :span="8" :xxl="4" :xl="8" :lg="8" :md="12">
          <a-input-group compact class="toolbar-input-search">
            <a-input style="width:65%" placeholder="请输入关键字搜索" />
            <a-button-group style="width: 35%;text-align: left;">
              <a-dropdown :trigger="['click']" :placement="'bottomCenter'">
                <a class="ant-dropdown-link" @click="e => e.preventDefault()">
                  <a-button type="primary">
                    <a-icon type="down" />
                  </a-button>
                </a>
                <a-menu slot="overlay">
                  <a-menu-item>
                    <a href="javascript:;">1st menu item</a>
                  </a-menu-item>
                  <a-menu-item>
                    <a href="javascript:;">2nd menu item</a>
                  </a-menu-item>
                  <a-menu-item>
                    <a href="javascript:;">3rd menu item</a>
                  </a-menu-item>
                </a-menu>
              </a-dropdown>
              <a-button type="primary">
                <a-icon type="search" />
              </a-button>
            </a-button-group>
          </a-input-group>
        </a-col>
      </a-row>

    </a-layout-header>
    <a-layout-header class="breadcrumb">
      <a-row>
        <a-col :span="21" :xxl="21" :xl="18" :lg="16" :md="15" class="breadcrumb_left">
          <a-button type="link">
            <a-icon type="undo" /> <span class="visible-lg-inline">返回上一层</span>
          </a-button>
          <a-button type="link">
            <a-icon type="sync" /> <span class="visible-lg-inline">刷新</span>
          </a-button>
          <a-divider type="vertical" />
          <a-breadcrumb separator=">">
            <a-breadcrumb-item>Home</a-breadcrumb-item>
            <a-breadcrumb-item href="">
              Application Center
            </a-breadcrumb-item>
            <a-breadcrumb-item href="">
              Application List
            </a-breadcrumb-item>
            <a-breadcrumb-item>An Application</a-breadcrumb-item>
          </a-breadcrumb>
        </a-col>
        <a-col :span="3" :xxl="3" :xl="6" :lg="8" :md="9" class="breadcrumb_right">
          <a-dropdown :trigger="['click']" :placement="'bottomCenter'">
            <a class="ant-dropdown-link" @click="e => e.preventDefault()">
              <a-button type="link">
                <a-icon type="ordered-list" />
              </a-button>
            </a>
            <a-menu slot="overlay">
              <a-menu-item>
                <a href="javascript:;">名称</a>
              </a-menu-item>
              <a-menu-item>
                <a href="javascript:;">修改时间</a>
              </a-menu-item>
              <a-menu-item>
                <a href="javascript:;">类型</a>
              </a-menu-item>
              <a-menu-item>
                <a href="javascript:;">大小</a>
              </a-menu-item>
            </a-menu>
          </a-dropdown>
          <a-radio-group v-model="mode" :style="{ marginBottom: '8px' }" button-style="solid">
            <a-radio-button value="table">
              <a-icon type="bars" />
            </a-radio-button>
            <a-radio-button value="list">
              <a-icon type="appstore" />
            </a-radio-button>
          </a-radio-group>
        </a-col>
      </a-row>
    </a-layout-header>
    <a-layout-content>
      <div class="file-table" v-if="mode=='table'">
        <a-table :row-selection="{ selectedRowKeys: selectedRowKeys, onChange: onSelectChange }" :columns="FileListColumns" :data-source="FileListData" :pagination="false"  :scroll="{ x: 1500, y: tableHeight }">
          <template slot="name" slot-scope="text, record">
            <div style="display:flex;align-items:baseline;justify-content:space-between;">
              <span>
                <!-- <a-icon :type="record.type" /> -->
                <svg class="icon" aria-hidden="true" style="vertical-align:middle">
                  <use :xlink:href="'#icon-'+record.type"></use>
                </svg>
                <span> {{ record.name }}</span>
              </span>
              <span>
                <a-icon v-if="record.collect" type="star" class="wfm-file-icon" style="color:gold" />
                <a-icon v-else type="star" class="wfm-file-icon" />
                <a-icon type="download" class="wfm-file-icon" />
                <a-dropdown :trigger="['click']" :placement="'bottomCenter'">
                  <a class="ant-dropdown-link" @click="e => e.preventDefault()">
                    <a-icon type="ellipsis" class="wfm-file-icon" />
                  </a>
                  <a-menu slot="overlay">
                    <a-menu-item>
                      <a href="javascript:;">打开</a>
                    </a-menu-item>
                    <a-menu-item>
                      <a href="javascript:;">下载</a>
                    </a-menu-item>
                    <a-menu-item>
                      <a href="javascript:;" @click="shareFileList">分享</a>
                    </a-menu-item>
                    <a-menu-item>
                      <a href="javascript:;">复制</a>
                    </a-menu-item>
                    <a-menu-item>
                      <a href="javascript:;">剪切</a>
                    </a-menu-item>
                    <a-menu-item>
                      <a href="javascript:;">重命名</a>
                    </a-menu-item>
                    <a-menu-item>
                      <a href="javascript:;">删除</a>
                    </a-menu-item>
                    <a-menu-item>
                      <a href="javascript:;">复制到</a>
                    </a-menu-item>
                    <a-menu-item>
                      <a href="javascript:;">移动到</a>
                    </a-menu-item>
                    <a-menu-item>
                      <a href="javascript:;">添加到收藏夹</a>
                    </a-menu-item>
                    <a-menu-item>
                      <a href="javascript:;" @click="attributeFileList">属性</a>
                    </a-menu-item>
                  </a-menu>
                </a-dropdown>
              </span>
            </div>
          </template>
      
        </a-table>
      </div>
      <div class="file-list" v-if="mode=='list'" :style="{height:`${tableHeight + 150}px`,overflow:'auto','overflow-x':'hidden'}">
        <a-list :grid="{ gutter:40, xs: 1, sm: 2, md: 4, lg: 4, xl: 6, xxl: 8 }" :data-source="FileListData" :pagination="listPagination" size="small">
          <a-list-item slot="renderItem" slot-scope="item, index">
            <!-- -------------------------- -->
            <a-popover title="Title"  placement="bottomLeft">
              <template slot="content">
                <p>Content</p>
                <p>Content</p>
              </template>
              <div class="list-content">
                <div class="list-menu" v-if="true">
                  <div class="list-checkbox">
                    <a-checkbox></a-checkbox>
                  </div>
                  <div class="list-iconbox">
                      <!-- <a-icon type="star" theme="filled" :class="{'activeStar': isActive}"  /> -->
                    <i @click="changeStar(index)" :class="[isActive == index ?'activeStar':'']">
                      <a-icon  type="star"  theme="filled" />
                    </i>
                    <a-icon type="download" />
                    <a-dropdown :trigger="['click']" :placement="'bottomCenter'">
                      <a class="ant-dropdown-link" @click="e => e.preventDefault()">
                        <a-icon type="ellipsis" />
                      </a>
                      <a-menu slot="overlay">
                        <a-menu-item>
                          <a href="javascript:;">打开</a>
                        </a-menu-item>
                        <a-menu-item>
                          <a href="javascript:;">下载</a>
                        </a-menu-item>
                        <a-menu-item>
                          <a href="javascript:;" @click="shareFileList">分享</a>
                        </a-menu-item>
                        <a-menu-item>
                          <a href="javascript:;">复制</a>
                        </a-menu-item>
                        <a-menu-item>
                          <a href="javascript:;">剪切</a>
                        </a-menu-item>
                        <a-menu-item>
                          <a href="javascript:;">重命名</a>
                        </a-menu-item>
                        <a-menu-item>
                          <a href="javascript:;">删除</a>
                        </a-menu-item>
                        <a-menu-item>
                          <a href="javascript:;">复制到</a>
                        </a-menu-item>
                        <a-menu-item>
                          <a href="javascript:;">移动到</a>
                        </a-menu-item>
                        <a-menu-item>
                          <a href="javascript:;">添加到收藏夹</a>
                        </a-menu-item>
                        <a-menu-item>
                          <a href="javascript:;" @click="attributeFileList">属性</a>
                        </a-menu-item>
                      </a-menu>
                    </a-dropdown>
                  </div>
                </div>
                <svg class="list-icon" aria-hidden="true">
                  <use :xlink:href="'#icon-'+item.type"></use>
                </svg>
                <p>
                  {{item.name}}
                </p>
              </div>
            </a-popover>
            <!-- -------------------------- -->


          </a-list-item>
        </a-list>
      </div>

    </a-layout-content>
  </a-layout>

  <!-- <upload-files :uploadVisible.sync="uploadVisible"></upload-files>
  <file-attribute :attributeVisible.sync="attributeVisible"></file-attribute>
  <share-files :filesShareVisible.sync="filesShareVisible"></share-files> -->



  <!-- 管理后台弹框 -->
  <!-- <a-modal v-model="adminVisible" title="管理后台" @ok="hideAdmin" :bodyStyle="{height:'80vh'}" :dialog-style="{ top: '20px' }" width="80vw" :footer="null">
    <admin />
  </a-modal> -->
</a-layout>
</template>

<script>
// import uploadFiles from '../UploadFiles/UploadFiles.vue' //上传弹框
// import fileAttribute from '../FileAttribute/FileAttribute.vue' //文件属性弹框
// import shareFiles from '../ShareFiles/ShareFiles.vue' //分享弹框
// import admin from '../Admin' //后台管理弹窗

import {
  treeData,
  FileListColumns,
  FileListData,
} from './index.js'
export default {
  name: "FilesUpload",
  // components: {
  //   uploadFiles,
  //   fileAttribute,
  //   shareFiles,
  //   admin
  // },
  data() {
    return {
      collapsed: false,
      /* 左侧导航 */
      treeData: treeData,
      FileListColumns: FileListColumns,
      FileListData: FileListData,
      selectedRowKeys: [],
      loading: false,
      tablePagination: {
        'show-size-changer': true,
        'show-quick-jumper': true,
        'total': FileListData.length,
        'show-total': total => `共 ${total} 条`
      },
      listPagination: {
        'show-size-changer': true,
        'show-quick-jumper': true,
        'defaultPageSize': 30,
        'total': FileListData.length,
        'show-total': total => `共 ${total} 条`
      },
      mode: 'table',
      tableHeight: window.innerHeight - 300,
      uploadVisible: false, //文件上传显示
      attributeVisible: false, // 属性显示
      filesShareVisible: false, // 分享显示
      adminVisible: false,
      isActive: null,
    }
  },
  computed: {
    hasSelected() {
      return this.selectedRowKeys.length > 0;
    },
  },
  mounted() {
    window.onresize = () => {
      this.tableHeight = window.innerHeight - 300
      console.log('Trigger Select', window.innerHeight);
    }
  },
  methods: {
    shareFileList() {
      // 分享按钮事件
      this.filesShareVisible = true
    },
    attributeFileList() {
      // 属性按钮事件
      this.attributeVisible = true
    },
    uploadFileList() {
      // 上传按钮事件
      this.uploadVisible = true
      // 	 this.$nextTick(() => {
      // })
    },
    onSelect(keys, event) {
      console.log('Trigger Select', keys, event);
    },
    onExpand() {
      console.log('Trigger Expand');
    },
    start() {
      this.loading = true;
      setTimeout(() => {
        this.loading = false;
        this.selectedRowKeys = [];
      }, 1000);
    },
    onSelectChange(selectedRowKeys) {
      console.log('selectedRowKeys changed: ', selectedRowKeys);
      this.selectedRowKeys = selectedRowKeys;
    },
    addClassload(index) {

    },
    removeClassload(index) {

    },
    showAdmin() {
      this.adminVisible = true
    },
    hideAdmin() {
      this.adminVisible = false
    },
    changeStar(index) {
      console.log(index,"filled")
      // this.starFilled = this.starFilled == 'filled' ? 'outlined' : 'filled'
      this.isActive = index


    }
  },
}
</script>

<style lang="less">
.filesUpload {
  .ant-progress-show-info .ant-progress-outer {
    margin-right: calc(-3em - 8px);
    padding-right: calc(3em + 8px);
  }

  .ant-progress-outer {
    .ant-progress-inner {
      vertical-align: baseline;
    }
  }
}
</style><style lang="less" scoped>
.filesUpload {

  /* 布局背景色 */
  .ant-layout-header,
  .ant-layout-footer,
  .ant-layout-sider,
  .ant-layout-content {
    background: #fff;
  }

  /* 

 左侧菜单样式

 */
  .ant-layout-sider {
    // height: 80vh;
    position: relative;
    border-right: 1px solid #eee;

    .ant-tree {
      margin-top: 20px;
    }

    .treeContainer {
      height: calc(100% - 30px);
      overflow: auto;
      text-align: left;
      background-color: #F7F7F7;
      padding-left: 10px;
    }

    .space {
      width: 100%;
      position: absolute;
      left: 0;
      bottom: 10px;
      height: 30px;

      .text {
        font-size: 12px;
      }

      .ant-progress {
        width: 70%;
        display: inline-block;
        margin-left: 1%;

        .ant-progress-text {
          span {
            font-size: 12px;
          }
        }
      }
    }
  }

  /* 

 右侧上面工具栏的样式

 */
  .toolbar {
    background: #f2f2f2;
    height: 50px;
    line-height: 50px;
    padding: 0;

    .ant-btn-link {
      color: #314659;
    }

    .toolbar-input-search {
      line-height: 50px;
      padding-right: 5px;

      .ant-input {
        width: 78%;
        vertical-align: baseline;
      }
    }
  }

  /* 

面包屑菜单栏样式 

 */
  .breadcrumb {
    padding: 0;

    .breadcrumb_left {
      text-align: left;

      // padding-left: 40px;
      .ant-breadcrumb {
        line-height: 60px;
        display: inline-block;
      }
    }

    .breadcrumb_center {
      text-align: left;
      line-height: 50px;

      .ant-breadcrumb {
        line-height: 60px;
      }
    }

    .breadcrumb_right {
      .ant-btn-group {
        margin-right: 20%;
      }
    }
  }

  /* 表格样式 */
  .file-table {
    .icon {
      width: 20px;
      height: 20px;
    }
  }

  /* 列表样式 */
  .file-list {
    .ant-col {}

    .list-content {
      width: 100%;
      // position: relative;
      background: #eee;

      .list-menu {
        // position: absolute;
        // top: 0;
        // right: 5px;
        font-size: 18px;
        display: flex;
        justify-content: space-between;
        padding: 5px;

        .list-checkbox {
           /deep/.ant-checkbox-input {
            margin: 0;
            border-radius: 50%;
          }
        }
        .list-iconbox {
          color: #a1a1a1;
          width: 40%;
          display: flex;
          justify-content: space-around;
          align-items: center;
        }


      }

      .list-icon {
        width: 50px;
        height: 100px;
      }

      p {
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
    }
  }
}
.activeStar {
  color: yellow;
}
.wfm-file-icon {
  cursor: pointer;
  margin: 0 2px;
}
</style>
