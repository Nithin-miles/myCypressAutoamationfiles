import FilesUpload from './src/filesUpload.vue';

FilesUpload.install = function(Vue) {
    Vue.component(FilesUpload.name, FilesUpload);
};

export default FilesUpload;