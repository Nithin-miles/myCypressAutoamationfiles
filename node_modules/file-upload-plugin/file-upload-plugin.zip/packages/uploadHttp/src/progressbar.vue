<template>
  <div
    class="progressbar progressbar-box" :id="value.fileID" ref="progressbarBox"
  >
   <!-- <div class="info"></div> -->
    
   <div class="number">{{percentage}}%</div>
   <div class="img_box">
         <img v-if="this.suffixType=='jpg'||
                     this.suffixType =='png'||
                     this.suffixType =='jpeg'||
                     this.suffixType =='gif'||
                     this.suffixType =='bmp'||
                     this.suffixType =='dxf'||
                     this.suffixType =='bip'" src="./../../assets/fileIcon/tupian.png" />

         <img v-else-if="this.suffixType =='zip'||this.suffixType =='rar'" src="./../../assets/fileIcon/zipRar.png" />             
   
        <img v-else-if="this.suffixType =='cda'||
                     this.suffixType =='wav'||
                     this.suffixType =='aif'||
                     this.suffixType =='au'||
                     this.suffixType =='mp3'||
                     this.suffixType =='wma'||
                     this.suffixType =='mmf'||
                     this.suffixType =='amr'||
                     this.suffixType =='aac'||
                     this.suffixType =='flac'
                     " src="./../../assets/fileIcon/yinpin.png" />
   
        <img v-else-if="this.suffixType =='avi'||
                   this.suffixType =='wmv'||
                   this.suffixType =='mpg'||
                   this.suffixType =='mov'||
                   this.suffixType =='rm'||
                   this.suffixType =='ram'||
                   this.suffixType =='swf'||
                   this.suffixType =='flv'||
                   this.suffixType =='mp4'
                   " src="./../../assets/fileIcon/shipin.png" />

        <img v-else-if="this.suffixType =='docx'||this.suffixType =='doc'" src="./../../assets/fileIcon/word.png" />

        <img v-else-if="this.suffixType =='xlsx'||this.suffixType =='xls'" src="./../../assets/fileIcon/xlsx.png" /> 

        <img v-else-if="this.suffixType =='ppt'||this.suffixType =='pptx'" src="./../../assets/fileIcon/ppt.png" /> 

        <img v-else-if="this.suffixType =='pdf'" src="./../../assets/fileIcon/pdf.png" /> 

        <img v-else-if="this.suffixType =='txt'" src="./../../assets/fileIcon/txt.png" /> 

        <img v-else-if="this.suffixType =='csv'" src="./../../assets/fileIcon/csv.png" />

        <img  v-else-if="this.suffixType =='mdb'||
                    this.suffixType =='dbf'||
                    this.suffixType =='mdf'||
                    this.suffixType =='db'||
                    this.suffixType =='wdb'
                    " src="./../../assets/fileIcon/shujvku.png" />

        <img  v-else-if="this.suffixType =='shp'||
                  this.suffixType =='shx'||
                  this.suffixType =='dbf'||
                  this.suffixType =='prj'||
                  this.suffixType =='sbn'||
                  this.suffixType =='sbx'||
                  this.suffixType =='sbn'||
                  this.suffixType =='fbn'||
                  this.suffixType =='fbx'||
                  this.suffixType =='ain'||
                  this.suffixType =='ixs'||
                  this.suffixType =='mxs'||
                  this.suffixType =='atx'||
                  this.suffixType =='cpg'
                  " src="./../../assets/fileIcon/shapefile.png" />

        <img v-else-if="this.suffixType =='sde'" src="./../../assets/fileIcon/kongjianshujv.png" />

        <img v-else-if="this.suffixType =='tif'" src="./../../assets/fileIcon/tuxiandili.png" />

        <img v-else-if="this.suffixType =='img'" src="./../../assets/fileIcon/img.png" /> 

        <img v-else-if="this.suffixType =='mxd'" src="./../../assets/fileIcon/mxd.png" />

        <img v-else src="./../../assets/fileIcon/qita.png" />
   </div>

    <div class="title_box">
        <div class="title">{{value.name}}</div>
        <div class="speed">
          <div v-if="value.uploadPercentage!=100">{{value.accomplishSize | KBDate(value.accomplishSize)}}<span>/</span>{{value.size | KBDate(value.size)}}</div>
          <div v-if="value.uploadPercentage==100">{{value.size | KBDate(value.size)}}<span>/</span>{{value.size | KBDate(value.size)}}</div>
          <div v-if="value.uploadPercentage!=100">{{value.speed}}{{value.units}}</div>
        </div>
        <!-- <div>{{value.speed}}{{value.units}}</div> -->
    </div>

    <div class="state" v-if="value.uploadPercentage!=100">{{value.state}}</div>
    <div class="state" v-if="value.uploadPercentage==100">已完成</div>
   <div class="delete" @click="deleteHttp()">x</div>
   
    <div
      :class="barClass"
      :style="barStyle"
      class="progressbar-bar progressbar-bar-box"
    >
      <slot/>
    </div>
  </div>
</template>

<script>
import './../../assets/iconFont/iconfont'
  export default {
    name: 'ProgressBar',
    data(){
      return{
         value:{},
         ext:"",
         suffixType:"",
      }
    },
    props: {
      value:{
         type: Object,
         default: ''
      },
      
      barClass: {
        type: String,
        default: ''
      },
      origin: {
        type: String,
        default: 'left'
      },
      scale: {
        type: String,
        default: 'X',
        validator: v => ['X', 'Y'].includes(v)
      },
      
      
    },
    data() {
      return {
        ready: false
      }
    },
    computed: {
      
      percentage(){

           
           return  Math.floor(this.value.uploadPercentage)

      },

      barStyle() {
        if (!this.ready) {
          return {
            transform: `scale${this.scale}(0)`
          }
        }

        return {
          transform: `scale${this.scale}(${this.value.uploadPercentage * 0.01})`,
          transformOrigin: `${this.origin}`
        }
      }
    },
    created() {
         this.abc()
    },
    mounted() {
      setTimeout(() => { this.ready = true }, 0)
    },
    filters: {
             //字节转换KB
          KBDate(limit){
              if(limit==0){
                 return 0
              }
              if(limit>0){
                  // console.log("大小"+limit)
              var size = "";  
                  if( limit < 0.1 * 1024 ){ //如果小于0.1KB转化成B  
                    let intNum = parseInt(limit)
                      size = intNum.toFixed(2) + ' B'  
                  }else if(limit < 0.999 * 1024 * 1024 ){//如果小于0.1MB转化成KB  
                      size = (limit / 1024).toFixed(2) + "KB";              
                  }else if(limit < 0.999 * 1024 * 1024 * 1024){ //如果小于0.1GB转化成MB  
                      size = (limit / (1024 * 1024)).toFixed(2) + "MB";  
                  }else if(limit < 0.999 * 1024 * 1024 * 1024* 1024){ //其他转化成GB  
                      size = (limit / (1024 * 1024 * 1024)).toFixed(2) + "G";  
                  }else{
                    size = (limit / (1024 * 1024 * 1024* 1024)).toFixed(2) + "T";  
                  }
                    
                  var sizestr = size + "";   
                  var len = sizestr.indexOf("\.");  
                  var dec = sizestr.substr(len + 1, 2);  
                  if(dec == "00"){//当小数点后为00时 去掉小数部分  
                      return sizestr.substring(0,len) + sizestr.substr(len + 3,2);  
                  }  
                  return sizestr; 
            }

          },
    },
    methods: {
         
        abc(){
             var index= this.value.name.lastIndexOf(".");
            //  alert(index)
             var ext = this.value.name.substr(index+1);
            //  alert(ext)
             this.suffixType=ext
             console.log(index)
        },
        
        deleteHttp(){
            console.log(this.value)
            this.$parent.deleteHttp(this.value.md5Id,this.value.fileID);
            var myList  = document.getElementById(this.value.fileID);
            myList.remove();
            //  myList.removeChild(removeNode);
        },

      },

     watch:{
         value(val){
           this.value = val
            }
      }
  }
</script>

<style lang="less" scoped>

.progressbar{
  height: 1.25rem;
  background: #F2F2F2;
}

.progressbar-bar{
  height: 100%;
        background: #E2EEFF;
        transition: transform 0.2s ease;
}


.progressbar-box{
  border-radius: 5px;
  height: 55px;
  position: relative;
  // box-shadow: rgb(128, 128, 128) 0px 0px 2px 1px inset;
  box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.25), 0 1px rgba(255, 255, 255, 0.08);
}

  .progressbar-bar-box{
    height: 55px;
    border-radius: 5px;
    
  }

.number{
  position: absolute;
  top: 0;
  right: 40px;
  width: 50px;
  z-index: 99;
  line-height:55px;
  color: rgba(0, 0, 0, 0.7);
  text-shadow: 0 1px rgba(255, 255, 255, 0.4);
  font-size: 11px;
  font-weight: bold;

}


.title{
    height:20px;
    color: rgba(0, 0, 0);
    text-shadow: 0 1px rgba(255, 255, 255, 0.4);
    font-size: 16px;

}
.speed{
    color: #6B6B6B;
    text-shadow: 0 1px rgba(255, 255, 255, 0.4);
    font-size: 12px;
    display: flex;
}
.speed span{
   margin-left:3px;
   margin-right: 3px;
}
.state{
  position: absolute;
  top: 0;
  right: 20%;
  width: 80px;
  z-index: 99;
  line-height:55px;
  color: rgba(0, 0, 0, 0.7);
  text-shadow: 0 1px rgba(255, 255, 255, 0.4);
  font-size: 11px;
  font-weight: bold;
}

.delete{
  position: absolute;
  top: 0;
  right: 20px;
  width: 30px;
  z-index: 99;
  line-height:40px;
  color: rgba(0, 0, 0, 0.7);
  text-shadow: 0 1px rgba(255, 255, 255, 0.4);
  font-size: 18px;
  line-height: 18px;
  font-weight: bold;
  text-align: right;
  padding-right: 10px;
  line-height: 50px;
  cursor:pointer;
}

.img_box{
  position: absolute;
  top: 0;
  z-index: 99;
  line-height: 50px;
  left: -15px;
}

.img_box img{
    width: 38px;
}
.title_box{
  display: flex;
  flex-direction: column;
  position: absolute;
  padding-top: 8px;
  top: 0;
  left: 30px;
  width:50%; 
  overflow: hidden;
text-overflow:ellipsis;
white-space: nowrap;
  z-index: 99;
  // line-height:50px;
  
}
</style>