<template>
  <div class="uploadHttp_box">
    <div class="uploadHttp_box_top">
       <input type="file" name="file" ref="readFiles" id="fileUpload" @change="readFile($event)" multiple="multiple" style="display:none">
        <input type="file" name="file" ref="readFolders" id="fileUpload" @change="readFolders($event)" multiple="multiple" webkitdirectory style="display:none">
              <a-dropdown>
      <a-menu slot="overlay" @click="handleMenuClick">
        <a-menu-item key="1" @click="upFilesButton()">文件上传 </a-menu-item>
        <a-menu-item key="2" @click="upFoldersButton()">文件夹上传 </a-menu-item>
      </a-menu>
      <a-button size="small" type="primary" style="margin-left: 8px"><a-icon type="cloud-upload" /> 选择文件  </a-button>
    </a-dropdown>

<div class="uploadHttp_box_l">
     <a-button type="primary" size="small">
  <a-icon type="pause" />
      全部暂停
    </a-button>
    <a-button :style="{ marginLeft: '8px' }" type="danger"  size="small" @click="deleteHttpBatch()">
      <a-icon type="delete" />
      全部取消
    </a-button>
</div>

    </div>

  <div class="uploadHttp">
    <h2 class="textCenter">把要上传的文件拖动到这里</h2>
 </div>
 <div class="progress_list_box">
      <div class="border m-2 d-inline-block p-4"  v-for="(file,index) in files" :key="index">
  <!-- <h5 class="mt-0">{{ file.name }}</h5> -->
  <div class="progress">
      <progress-bar :value="file" />
<!-- {{file.uploadPercentage}} -->
  </div>
 </div>
 </div>
 
  </div>
</template>

<script>
import Vue from 'vue'
import SparkMD5 from "spark-md5";
import md5 from 'js-md5';
Vue.prototype.$md5 = md5;

import ProgressBar from './progressbar.vue'
let token="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhdXRoIjoiQXJjR0lT5pyN5Yqh566h55CG5ZmoLEhvbWUsVW5kZXJDb25zdHJ1Y3Rpb24xLFVuZGVyQ29uc3RydWN0aW9uMixVbmRlckNvbnN0cnVjdGlvbjMsYWNoaWV2ZW1lbnQsYWNoaWV2ZW1lbnRBcHByb3ZlLGFjaGlldmVtZW50RGV0YWlsLGFjaGlldmVtZW50RXhhbWluZSxhY2hpZXZlbWVudE1hbmFnZSxhY2hpZXZlbWVudFVwbG9hZCxhZGREYXRhU2V0UGFnZSxhZGRSZXNvdXJjZU1pZGRsZVBhZ2UsYWRkUmVzb3VyY2VQYWdlLGFkbWluaXN0cmF0aW9uLGFuYWx5c2lzRXN0aW1hdGUsYXBwbGljYXRpb24sYXBwbGljYXRpb25MaXN0LGFzc2VzcyxidXNpbmVzc0xvZyxjYXJyeWluZyxjYXJyeWluZ0NhcGFjaXR5LGNhcnJ5aW5nTWFwLGNvb3JkaW5hdGVBZGQsY29vcmRpbmF0ZURldGFpbHMsY29vcmRpbmF0ZUVkaXQsY29vcmRpbmF0ZVN5c3RlbSxjdXJyZW50U2l0dWF0aW9uLGRhdGEsZGF0YS1vdXQsZGF0YU1hbmdlLGRhdGFSZXNvdXJjZSxkYXRhU2V0SW5mbyxkYXRhU2V0TWFuYWdlLGRhdGFTdGF0aXN0aWNzLGRhdGFUZXN0aW5nLGRhdGFiYXNlTGlzdCxkYXRhYmFzZU1ldGFkYXRhLGRhdGFiYXNlU3FsTWV0YWRhdGEsZGF0YWJhc2VTcWxNZXRhZGF0YUluZm8sZGVwdCxkaWN0aW9uYXJ5LGRpc3RyaWN0LGVkaXRNb2R1bGUsZXhhbWluZSxmaWxlUmVzb3Vyc2UsZmlsZXNVcGxvYWQsZ2V0QWxsRGF0YWJhc2UsZ2V0QWxsRGVwdCxnaXNhcHBidWlsZGVyLGdyZWV0LGljb24saW5kZXhHaXZlLGludGVyZmFjZSxpbnRlcmZhY2VEYXRhLGludGVyZmFjZU1hbmFnZSxpbnRlcmZhY2VSZXEsbG9nLGxvZ2luTG9nLG1hcCxtYXBBcHAsbWFwTWFuYWdlbWVudCxtYXBSZXNvdXJjZXMsbWFwUmVzb3Vyc2UsbWFwU2VydmVyTWFuYWdlLG1hcFNlcnZpY2VQdWJsaXNoaW5nLG1hdGNoSW50ZXJmYWNlRGF0YSxtZW51LG1lc3NhZ2VDZW50ZXIsbWV0YWRhdGEsbWV0YWRhdGExLG1ldGRhdGFJbmZvLG1ldGRhdGFJbmZvVGFibGVEZXRhaWxzLG1vZGVsRGVmaW5pdGlvbixtb2RlbExpc3QsbW9kZWxNYW5hZ2UsbW9kZWxNYW5hZ2VFZGl0LG1vbml0b3JWYWx1ZSxtb25pdG9yVmFsdWVBZGQsbXlBcHBsaWNhdGlvbixteUFwcGx5LG15QXBwcm92YWwsbXlDb2xsZWN0aW9uLG15RGF0YSxteURhdGFTZXRQYWdlLG15Z2lzQXBwLG15bWFwLG15c2NlbmUsb25lbWFwcGxhbixvdXRwdXRQYWdlUHJldmlldyxvdXRwdXRQYWdlU2V0dGluZyxwZW9wbGVBbGxvd2VkVG9BY2Nlc3MscGVyZm9ybVJldmlldyxwbGFuTWFuYWdlckxpc3QscHJlc2VudEFuYWx5c2lzLHByZXNlbnRBc3Nlc3MscHVibGlzaERhdGEscXVhbGl0eUFjaGlldmVtZW50RXhhbWluZSxxdWFsaXR5QWNoaWV2ZW1lbnRNYW5hZ2UscXVhbGl0eUFjaGlldmVtZW50VXBsb2FkLHJlc291cmNlQ2F0YWxvZ1F1ZXJ5LHJlc291cmNlSW5mbyxyZXNvdXJjZVN0YXRpc3RpY3Mscm9sZSxzY2hlbWFBZGQsc2NoZW1hRGV0YWlsLHNjaGVtYUluZm9ybWF0aW9uLHNjaGVtYU1hbmFnZSxzZGVNZXRhZGF0YURldGFpbHMsc2VydmljZVJlc291cmNlQ2F0YWxvZyxzaXRlUmVnaXN0ZXIsc2l0ZVNlcnZpY2Usc3BlY2lhbFRvcGljTWFwLHN0YXRpc3RpY3Msc3ltYm9sbWFuYWdlLHN5c3RlbSxzeXN0ZW1TZXQsdGFibGVEZXRhaWxzLHRhcmdldEVkaXQsdGFyZ2V0TW9kZWxNYW5hZ2UsdGFyZ2V0V2FybmluZyx0YXNrQ2VudGVyLHRhc2tEZXRhaWxTZGUsdGhlbWF0aWNNYXBJbmZvLHRoZW1hdGljbWFwcyx1c2VyLOWbveWcn-epuumXtOinhOWIkuS_oeaBr-mXqOaItyzlm73lnJ_nqbrpl7Top4TliJLlj4zor4Tku7cs5Zu95Zyf56m66Ze06KeE5YiS5pWw5o2u6LSo5qOA5Z-f5a6h5p-l57O757ufLOa1i-ivlVdpa2nns7vnu58s55S15a2Q5pS_5Yqh5LqR5bqU55So5bmz5Y-wLOezu-e7n-ebkeaOpyzomZrmi5_ljJblvJXmk47nrqHnkIblmags6KeE5YiS5LiA5byg5Zu-6aKG5a-86am-6am26IixIiwidXNlck5hbWUiOiJhZG1pbiIsImV4cCI6MTYyOTg1NTk2NSwidXNlcklkIjoxLCJpYXQiOjE2Mjk4NTQxNjV9.4hLNTtpZgus4pv6gkq5SKJUXMn7R63gP3aVxad087hE"
export default {
     name:"uploadHttp",
       data(){
         return{
              uploadType:0,// 0 默认上传各个目录，1上传单独文件版本
              files: [],
              chunkSize: 1024 * 1024 * 5, //分片上传5MB，大于5M 分片
              subChunkSize:"",//子分片
              requests:[],
              cancelList:[],
              fileIDList:[],
              dataUploadHttp:this.uploadHttp,
              dataQueryFileHttp:this.queryFileHttp,
              dataToken:this.token,
              computeMD5shop:false,
              breakpointUpload:true,//断点续传开关  false关闭，true打开
              notUploadedChunkNumbers:[],
              parentId:this.parentFileId,//父级ID
          }
      },
    props: {
        uploadHttp:{
          type: String,
          default:""
      },  
      queryFileHttp:{
          type: String,
          default:""
      }, 
      
      token:{
          type: String,
          default:""
      },
      parentId:{
          type: String,
          default:"-1"
      },
      config: {
         type: Object,
        default () {
          return {
            search:true,//搜索 
            upload:true,//上传
            newFolder:true,//新建文件夹
            select:"checkbox",//单选radio 多选checkbox
            disableSelect:{//禁用选择
              state:false,//禁用选择
              lock:0, //0 禁用后，过滤可选得后缀， 1禁用后，过滤不可选的后缀
              suffix:[],  //禁用后,可选得后缀   ["folder", "pptx"]
              disableSuffix:[]//禁用后，过滤不可选的后缀
            },
            selectSave:false,//翻页保存勾选开启true 关闭false
            height:"", 
             // search 搜索   Boolean
        // upload 上传   Boolean
        // NewFolder 新建文件夹  Boolean
        // select   string  单选radio 多选checkbox
        //disable-select object
        // {
        //   disableSelect:true,
        //   suffix:""  //后缀
        // }
        // 禁用选择 Boolean   true 不禁用  false警用
        // 
          }
        }
      },
    },
    created(){
          // alert(this.uploadHttp)
          // alert(this.queryFileHttp)
    },
      mounted(){
         var dropbox = document.querySelector('.uploadHttp_box');
          dropbox.addEventListener('dragenter', this.onDrag, false);
          dropbox.addEventListener('dragover', this.onDrag, false);
          dropbox.addEventListener('drop', this.onDrop, false);
      },
     
     methods:{
       //父级上传文件/文件夹
       uploadHttpType(uploadType){
           console.log(uploadType)
           this.uploadType=uploadType
       },

       //父级上传单独版本
       fileVersionUP(uploadType){
         console.log(uploadType)
         this.uploadType=uploadType
         this.$refs.readFiles.click();       
       },



       //上传文件事件
       upFilesButton(){
         console.log("upFilesButton")
           this.$refs.readFiles.click();
       },
        //上传文件夹事件
       upFoldersButton(){
         console.log("upFoldersButton")
           this.$refs.readFolders.click();
       },
       //上传文件
       readFile(e){
        console.log("readFile")
        console.log(e)

        var files =  e.target.files
        console.log(files.length);
     
      //  this.chkMd5(file,fullPathEntry)
       for (var i = 0; i<files.length; i++) {
           console.log(files[i])
           this.chkMd5(files[i],files[i].name)
       }

      },
      //上传文件夹
      readFolders(e){
        console.log("readFolders")
        console.log(e)
        var files =  e.target.files
        console.log(files.length);

        for (var i = 0; i<files.length; i++) {
           console.log(files[i])
           this.chkMd5(files[i],files[i].webkitRelativePath)
       }

      },


       // 计算MD5
    chkMd5(file,path) {
      console.log("chkMd5")
      console.log(path)
      console.log(file)
      console.log(file.name)
      //子分片
      // if(file.size<this.chunkSize){
      //      this.chunkSize=(file.size/2)
      // }



      //end

      let that = this;
      let blobSlice = File.prototype.slice || File.prototype.mozSlice || File.prototype.webkitSlice,
          // chunkSize = 2097152,//2M
          chunks = Math.ceil(file.size / this.chunkSize),
          currentChunk = 0,
          spark = new SparkMD5.ArrayBuffer(),
          fileReader = new FileReader();
          
           let time = new Date().getTime();
   
           let fileID=this.$md5(file.name+time+file.size)
           

            console.log('计算MD5...')
          


            file.cmd5 = true;

            if(chunks>1){
               var item = {
              name: file.name,
              size:file.size,
              accomplishSize:0,
              type:file.type,
              uploadPercentage: 0,
              parentId: 0,
              state:"计算中..",
              fileID:fileID
            };
            
            this.files.push(item);
            }
            
            
            
            fileReader.onload = (e) => {
              if(that.fileIDList.length>0){
                 for(let i=0; i<that.fileIDList.length; i++){
                  if(fileID==that.fileIDList[i]){
                     console.log("停")
                     return
                    }  
                  }   
              }
                
               console.log("触发--"+fileID)
                spark.append(e.target.result);   // Append array buffer
                currentChunk++;
          
                if (currentChunk < chunks) {
                    console.log(`第${currentChunk}分片解析完成, 开始第${currentChunk +1} / ${chunks}分片解析`);
                    // let percent = Math.floor(currentChunk / chunks * 100);
                    // console.log(percent);
                    // file.cmd5progress = percent;
                    
                   loadNext();
                } else {
                    console.log('finished loading');
                    let md5 = spark.end();
                    console.log(`MD5计算完成：${file.name} \nMD5：${md5} \n分片：${chunks} 大小:${file.size} 用时：${new Date().getTime() - time} ms`);
                    spark.destroy(); //释放缓存
                    file.uniqueIdentifier = md5; //将文件md5赋值给文件唯一标识
                    file.fileID=fileID
                    file.cmd5 = false; //取消计算md5状态
                    file.chunks=chunks; //总片数

                    console.log(file);
                    console.log(file.uniqueIdentifier)
                    console.log(file.size) //243168660
                    console.log(file)
                    



                    if(chunks==1){ //不分片
                    if (this.breakpointUpload!=false){ 
                          const form = new FormData();
                          form.append('originalName', file.name);
                          form.append('fileSize', file.size);
                          form.append('fileMd5', file.uniqueIdentifier)
                          form.append('fileRelativePath', path);
                          form.append('parentId', that.parentId);
                          var xhr = new XMLHttpRequest();
                          xhr.open('POST', this.dataQueryFileHttp+"/cloudoffice/upload/insertFileInfo", true);
                          xhr.setRequestHeader('Authorization', 'Bearer '+this.dataToken);
                          xhr.setRequestHeader('userName', 'admin'); 
                          xhr.onload = function(e) { 
                              if (xhr.readyState === 4){
                                  if (xhr.status === 200 || xhr.status === 304) {
                                        console.log(xhr.responseText);
                                        var responseObj = JSON.parse(xhr.responseText); 
                                        console.log(responseObj.code);
                                        if (responseObj.code==200){
                                             console.log(responseObj.data);
                                             console.log(responseObj.data.fileState);
                                             if (responseObj.data.fileState==1){//已有文件
                                                  var item = {
                                                          name: file.name,
                                                          size:file.size,
                                                          accomplishSize:file.size,
                                                          type:file.type,
                                                          uploadPercentage: 100,
                                                          parentId: "-1",
                                                          state:"已完成",
                                                          md5Id:file.uniqueIdentifier,
                                                          fileID:file.fileID,
                                                          speed:"0/s",
                                                          units:""
                                                          };

                                                        that.files.push(item);


                                             }else{//上传
                                                    const form = new FormData();
                                                          const start = 0 *  that.chunkSize;
                                                          const end = Math.min(file.size, start +  that.chunkSize);
                                                          form.append('file', blobSlice.call(file, start, end));
                                                          form.append('name', file.name);
                                                          form.append('total', chunks);
                                                          form.append('index', 1);
                                                          form.append('fileSize', file.size);
                                                          form.append('cmd5', file.uniqueIdentifier);
                                                          form.append('fileRelativePath', path);
                                                          form.append('parentId', that.parentId);
                                                          // uploadPercentage: 0,
                                                         that.uploadFile(file,path,1,form)
              

                                             }
                                        }
                                       
                                  }
                              }
                            };
                          xhr.send(form);

                     }else{
                         const form = new FormData();
                            const start = 1 * this.chunkSize;
                            const end = Math.min(file.size, start + this.chunkSize);
                            form.append('file', blobSlice.call(file, start, end));
                            form.append('name', file.name);
                            form.append('total', chunks);
                            form.append('index', 1);
                            form.append('fileSize', file.size);
                            form.append('cmd5', file.uniqueIdentifier);
                            form.append('fileRelativePath', path);
                            // uploadPercentage: 0,
                      this.uploadFile(file,path,1,form)
                     }
                     
                    }else{ //分片
                        if (this.breakpointUpload!=false){ 

                            
                             const form = new FormData();
                              form.append('originalName', file.name);
                              form.append('fileSize', file.size);
                              form.append('fileMd5', file.uniqueIdentifier)
                              form.append('fileRelativePath', path);
                              form.append('parentId', this.parentId);
                              var xhr = new XMLHttpRequest();
                                  xhr.open('POST', this.dataQueryFileHttp+"/cloudoffice/upload/insertFileInfo", true);
                                  xhr.setRequestHeader('Authorization', 'Bearer '+this.dataToken);
                                  xhr.setRequestHeader('userName', 'admin'); 
                                  xhr.onload = function(e) { 
                                      if (xhr.readyState === 4){
                                          if (xhr.status === 200 || xhr.status === 304) {
                                                console.log(xhr.responseText);
                                                 var responseObj = JSON.parse(xhr.responseText); 
                                                      console.log(responseObj.code);
                                                       console.log(responseObj.data.fileMd5);
                                                      if (responseObj.code==200){
                                                           if (responseObj.data.fileState==1){//已完成文件
                                                      
                                                               console.log("已完成文件")
                                                                   for(let i=0; i<that.files.length; i++){
                                                                        if(file.uniqueIdentifier==responseObj.data.fileMd5){
                                                                          that.files[i].state="已完成"
                                                                          that.files[i].uploadPercentage=100
                                                                        }
                                                                    }
 
                                                           }else {//没完成文件
                                                              
                                                              if(responseObj.data.fileChunkNum==0){// 文件首次上传
                                                                      var existingItem = {
                                                                          existingFile:responseObj.data.existingFile,
                                                                          originalName:responseObj.data.originalName
                                                                      }
                                                                      that.notUploadedChunkNumbers.push(existingItem)
                                                                      for (let i = 0; i < chunks; i++) {
                                                                                const start = i *  that.chunkSize;
                                                                                  const end = Math.min(file.size, start + that.chunkSize);
                                                                                  // 构建表单··
                                                                                  const form = new FormData();
                                                                                  form.append('file', blobSlice.call(file, start, end));
                                                                                  form.append('name', file.name);
                                                                                  form.append('total', chunks);
                                                                                  
                                                                                  form.append('index', i);
                                                                                  form.append('fileSize', file.size);
                                                                                  form.append('cmd5', file.uniqueIdentifier);
                                                                                  form.append('fileRelativePath', path);
                                                                                  form.append('chunkSize', that.chunkSize);
                                                                                  form.append('parentId', that.parentId);
                                                                                  that.uploadFile(file,path,chunks,form)   
                                                                          } 

                                                                }else{//不是首次上传
                                                                //  alert("545455455")
                                                                         for(let i=0; i<that.files.length; i++){
                                                                                    if(that.files[i].name==responseObj.data.originalName){
                                                                                           let fileChunkNum= (that.chunkSize * 100) / file.size
                                                                                            console.log(fileChunkNum)
                                                                                            console.log(responseObj.data)
                                                                                            console.log(responseObj.data.fileChunkNum)
                                                                                            console.log(responseObj.data.existingFile.length)
                                                                                           let successChunkNum=responseObj.data.existingFile.length
                                                                                            console.log(successChunkNum)
                                                                                            that.files[i].uploadPercentage=fileChunkNum*successChunkNum
                                                                                            that.files[i].accomplishSize=fileChunkNum*that.chunkSize  
                                                                                       }
                                                                          }  
                                                       

                                                                               //有缓存
                                                                              if(that.notUploadedChunkNumbers.length>0){
                                                                                    let find="0"
                                                                                     for(let i=0; i<that.notUploadedChunkNumbers.length; i++){
                    
                                                                                            if(that.notUploadedChunkNumbers[i].originalName!=responseObj.data.originalName){//没有
                                                                                                // console.log("不等于")
                                                                                                find="0"
                                                                                            }else{ //有
                                                                                                find="1"
                                                                                                that.notUploadedChunkNumbers[i].existingFile=responseObj.data.existingFile
                                                                                            }

                                                                                        }
                                                                                       
                                                                                    if(find=="0"){
                                                                                          var existingItem = {
                                                                                              existingFile:responseObj.data.existingFile,
                                                                                              originalName:responseObj.data.originalName
                                                                                              }
                                                                                          that.notUploadedChunkNumbers.push(existingItem)
                                                                                        }
                                                                              }else{//没有缓存
                                                                                     var existingItem = {
                                                                                        existingFile:responseObj.data.existingFile,
                                                                                        originalName:responseObj.data.originalName
                                                                                        }
                                                                                     that.notUploadedChunkNumbers.push(existingItem)
                                                                              }

                                                                             
                                                                            //  console.log(that.notUploadedChunkNumbers)
                                                                                     for(let a=0; a<that.notUploadedChunkNumbers.length; a++){
                                                                                        if(that.notUploadedChunkNumbers[a].originalName==responseObj.data.originalName){//匹配
                                                                                         for (let b = 0; b < chunks; b++) {
                                                                                                  if((that.notUploadedChunkNumbers[a].existingFile || []).indexOf(b + 1) < 0){
                                                                                                          const start = b * that.chunkSize;
                                                                                                          const end = Math.min(file.size, start + that.chunkSize);
                                                                                                          // 构建表单
                                                                                                          const form = new FormData();
                                                                                                          form.append('file', blobSlice.call(file, start, end));
                                                                                                          form.append('name', file.name);
                                                                                                          form.append('total', chunks);
                                                                                                          
                                                                                                          form.append('index', b);
                                                                                                          form.append('fileSize', file.size);
                                                                                                          form.append('cmd5', file.uniqueIdentifier);
                                                                                                          form.append('fileRelativePath', path);
                                                                                                          form.append('chunkSize', that.chunkSize);
                                                                                                          form.append('parentId', that.parentId);
                                                                                                          that.uploadFile(file,path,chunks,form) 
                                                                                                    }
                                                                                           } 
                                                                                        }
                                                                                  }
                                                                          
        
                                                                }
                                                                
                                                              
                                                            
                                                                  // console.log(that.notUploadedChunkNumbers)


                                                                  //  for(let i=0; i<that.notUploadedChunkNumbers.length; i++){ 
                                                                  //       if(that.notUploadedChunkNumbers[i].originalName==responseObj.data.originalName){//匹配
                                                                  //             that.notUploadedChunkNumbers[i].existingFile=responseObj.data.existingFile

                                                                  //       }else{// 没有匹配的
                                                                  //             that.notUploadedChunkNumbers.push(existingItem)
                                                                  //       }
                                                                  //  }
                                                                  //  console.log(that.notUploadedChunkNumbers)
                                                              
                                                                  
                                                                  // for(let a=0; a<that.notUploadedChunkNumbers.length; a++){ 
                                                                  //       if(that.notUploadedChunkNumbers[a].originalName==responseObj.data.originalName){//匹配
                                                                  //              for(let i=0; i<that.files.length; i++){
                                                                  //                   if(that.files[i].name==responseObj.data.originalName){
                                                                  //                          let aa= (this.chunkSize * 100) / file.size
                                                                  //                           console.log(responseObj.data)
                                                                  //                           console.log(responseObj.data.fileChunkNum)
                                                                  //                           console.log(responseObj.data.existingFile.length)
                                                                  //                          let successChunkNum=responseObj.data.fileChunkNum-responseObj.data.existingFile.length


                                                                  //                         //  that.files[i].uploadPercentage=100
                                                                  //                      }
                                                                  //               }       



                                                                //                for (let b = 0; b < chunks; b++) {
                                                                //           if((that.notUploadedChunkNumbers[a].existingFile || []).indexOf(b + 1) < 0){
                                                                //                 const start = b *  that.chunkSize;
                                                                //                   const end = Math.min(file.size, start + that.chunkSize);
                                                                //                   // 构建表单
                                                                //                   const form = new FormData();
                                                                //                   form.append('file', blobSlice.call(file, start, end));
                                                                //                   form.append('name', file.name);
                                                                //                   form.append('total', chunks);
                                                                                  
                                                                //                   form.append('index', b);
                                                                //                   form.append('fileSize', file.size);
                                                                //                   form.append('cmd5', file.uniqueIdentifier);
                                                                //                   form.append('fileRelativePath', path);
                                                                //                   form.append('chunkSize', that.chunkSize);
                                                                //                   that.uploadFile(file,path,chunks,form) 
                                                                //             }
                                                                // } 


                                                                  //      }      
                                                                  // } 


                                            
                                                                      
                                                                //     for (let i = 0; i < chunks; i++) {
                                                                //           if((that.notUploadedChunkNumbers || []).indexOf(i + 1) < 0){
                                                                //                 const start = i *  that.chunkSize;
                                                                //                   const end = Math.min(file.size, start + that.chunkSize);
                                                                //                   // 构建表单
                                                                //                   const form = new FormData();
                                                                //                   form.append('file', blobSlice.call(file, start, end));
                                                                //                   form.append('name', file.name);
                                                                //                   form.append('total', chunks);
                                                                                  
                                                                //                   form.append('index', i);
                                                                //                   form.append('fileSize', file.size);
                                                                //                   form.append('cmd5', file.uniqueIdentifier);
                                                                //                   form.append('fileRelativePath', path);
                                                                //                   form.append('chunkSize', that.chunkSize);
                                                                //                   that.uploadFile(file,path,chunks,form) 
                                                                //             }
                                                                // } 

                                                           }

                                                      }
                                          }
                                      }
                                    };
                                  xhr.send(form);


                        }else{

                             for (let i = 0; i < chunks; i++) {
                                  const start = i * that.chunkSize;
                                  const end = Math.min(file.size, start + that.chunkSize);
                                  // 构建表单
                                  const form = new FormData();
                                  form.append('file', blobSlice.call(file, start, end));
                                  form.append('name', file.name);
                                  form.append('total', chunks);
                                  form.append('index', i);
                                  form.append('fileSize', file.size);
                                  form.append('cmd5', file.uniqueIdentifier);
                                  form.append('fileRelativePath', path);
                                  form.append('chunkSize', that.chunkSize);
                                  form.append('parentId', that.parentId);
                                  that.uploadFile(file,path,chunks,form)   

                                  
                                  // var xhr = new XMLHttpRequest();
                                  //     xhr.open('POST', 'http://192.168.49.11:8099/upload/uploadFile', true);
                                  //     xhr.setRequestHeader('token', token);
                                  //     xhr.setRequestHeader('userName', 'admin');
                                  //     xhr.upload.addEventListener('progress', function (e) {
                                  //       //e.loaded 代表当前AJAX发送了多少字节，
                                  //       //e.total 代表AJAX总共要发送多少字节。
                                  //       //通过这两个属性可以计算上传进度的百分比。
                                  //       item.uploadPercentage = Math.round((e.loaded * 100) / e.total);
                                  //     }, false);
                                  // xhr.send(form);
                            }
                  

                        }
     
                       

                      }
                   
                }
            };
              fileReader.onerror = () => {
                 console.warn('文件读取失败！');
               };
           
         
            let loadNext = () =>　{
                let start = currentChunk * this.chunkSize
                let end = ((start + this.chunkSize) >= file.size) ? file.size : start + this.chunkSize;  
                fileReader.readAsArrayBuffer(blobSlice.call(file, start, end));
            };
         
            loadNext();
    },


    md5(file){
         var fileSize = file.size; // 文件大小
        var chunkSize = 2 * 1024 * 1024; // 切片的大小
        var chunks = Math.ceil(fileSize / chunkSize); // 获取切片的个数
        var blobSlice = File.prototype.slice || File.prototype.mozSlice || File.prototype.webkitSlice;
        var spark = new SparkMD5.ArrayBuffer();
        var reader = new FileReader();
        var currentChunk = 0;
        
        reader.onload = function(e) {
          const result = e.target.result;
          spark.append(result);
          currentChunk++;
          if (currentChunk < chunks) {
            loadNext();
            console.log(`第${currentChunk}分片解析完成，开始解析${currentChunk + 1}分片`);
          } else {
            const md5 = spark.end();
            console.log('解析完成');
            console.log(md5);
          }
        };
        function loadNext() {
          var start = currentChunk * chunkSize;
          var end = start + chunkSize > file.size ? file.size : (start + chunkSize);
          reader.readAsArrayBuffer(blobSlice.call(file, start, end));
        };
        loadNext();
    },

       //上传
       uploadFile(file,path,chunkNum,form) {
         console.log(this.requests)
         console.log(file)
         console.log(path)
         console.log(chunkNum)
         let that=this
        //  console.log(typeof(file));
        //  console.log(file.name);
        // this.chkMd5(file)
        // console.log(file.chunks);
        // //  this.md5(file)
        //   if(file.size<this.chunkSize){//不分片

        if(chunkNum==1){
                var item = {
              name: file.name,
              size:file.size,
              accomplishSize:0,
              type:file.type,
              uploadPercentage: 0,
              parentId: 0,
              state:"上传中...",
              md5Id:file.uniqueIdentifier,
              fileID:file.fileID,
              speed:0,
              units:""
            };
            
            if(this.files.length>0){
                 let find="0"
                 for(let i=0; i<this.files.length; i++){
                    
                    if(file.name!=this.files[i].name){//没有
                        // console.log("不等于")
                        find="0"
                    }else{ //有
                        find="1"
                        this.files[i].md5Id=file.uniqueIdentifier
                    }
                    if(file.name==this.files[i].name){
                       this.files[i].state="上传中..."
                    }
                 }

                 if(find=="0"){
                     this.files.push(item);
                 }
            }else{
              
              this.files.push(item);
            }

   
              // this.files.push(item);
 
            // var fd = new FormData();
            // fd.append('myFile', file);
            // form.append('parentId', "-1");
            var xhr = new XMLHttpRequest();
            xhr.fileID=file.fileID
            this.requests.push(xhr)
            xhr.open('POST', this.dataUploadHttp+"/cloudoffice/upload/uploadFile", true);
            // Authorization: "Bearer " + access_token,
            xhr.setRequestHeader('Authorization', 'Bearer '+this.dataToken);
            xhr.setRequestHeader('userName', 'admin');
            var lastTime = 0;//上一次计算时间
             var lastSize = 0;//上一次计算的文件大小
             var speed=0
             var units='b/s'
            xhr.upload.addEventListener('progress', function (e) {
              //e.loaded 代表当前AJAX发送了多少字节，
              //e.total 代表AJAX总共要发送多少字节。
              //通过这两个属性可以计算上传进度的百分比。
              
              console.log(e.loaded)
              item.uploadPercentage = Math.round((e.loaded * 100) / e.total);
              console.log(item.uploadPercentage)
              
              /*验证数据*/
              // if(lastTime == 0)
              // {
              //     lastTime = new Date().getTime();
              //     lastSize = e.loaded;
              //     return;
              // }

              /*计算间隔*/
              var nowTime = new Date().getTime();
              var intervalTime = (nowTime - lastTime)/1000;//时间单位为毫秒，需转化为秒
              var intervalSize = e.loaded - lastSize;

              /*重新赋值以便于下次计算*/
              lastTime = nowTime;
              lastSize = e.loaded;


              /*计算速度*/
              speed = intervalSize/intervalTime;
              var bSpeed = speed;//保存以b/s为单位的速度值，方便计算剩余时间
              units = 'b/s';//单位名称
              if(speed/1024>1){
                  speed = speed/1024;
                  units = 'k/s';
              }
              if(speed/1024>1){
                  speed = speed/1024;
                  units = 'M/s';
              }

             for(let i=0; i<that.files.length; i++){
              if(file.name==that.files[i].name){
                   that.files[i].speed=speed.toFixed(1)
                   that.files[i].accomplishSize=that.files[i].accomplishSize+e.loaded
                   that.files[i].units=units
                  // console.log(that.files[i].units)
              }
             }  
            //  console.log("----------"+speed.toFixed(1) + units)
             
            }, false);
            xhr.send(form);
        }else{//分片
             
               console.log("分片")
             
               var item = {
                name: file.name,
                size:file.size,
                accomplishSize:0,
                type:file.type,
                uploadPercentage: 0,
                parentId: "-1",
                state:"上传中...",
                md5Id:file.uniqueIdentifier,
                fileID:file.fileID,
                speed:0,
                units:""
                };
            
            if(this.files.length>0){
                 let find="0"
                 for(let i=0; i<this.files.length; i++){
                    
                    if(file.name==this.files[i].name){//没有
                        this.files[i].md5Id=file.uniqueIdentifier
                        find="1"
                        this.files[i].state="上传中..."
                    }
                    
                 }

                 if(find=="0"){
                     this.files.push(item);
                 }

            }else{
             
              this.files.push(item);
            }
            
           console.log(this.files)

            // this.files.push(item);

            // var fd = new FormData();
            // fd.append('myFile', file);

            var xhr = new XMLHttpRequest();
            
            xhr.fileID=file.fileID
            // alert(this.dataUploadHttp)
            xhr.open('POST', this.dataUploadHttp+"/cloudoffice/upload/uploadFile", true);
            xhr.setRequestHeader('Authorization', '                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   Bearer '+this.dataToken);
            xhr.setRequestHeader('userName', 'admin');
            this.requests.push(xhr)
            // console.log(this.requests)
            //  console.log(this.requests.length)
            // xhr.upload.addEventListener('progress', function (e) {
            //   //e.loaded 代表当前AJAX发送了多少字节，
            //   //e.total 代表AJAX总共要发送多少字节。
            //   //通过这两个属性可以计算上传进度的百分比。
            //   // console.log(e)

            //   item.uploadPercentage = Math.round((e.loaded * 100) / file.size);
            //   console.log(item.uploadPercentage)
            //   for(let i=0; i<that.files.length; i++){
              
            //         if(file.name==that.files[i].name){
            //            that.files[i].uploadPercentage=that.files[i].uploadPercentage+item.uploadPercentage
            //         } 
            //      }

            // }, false);
             var lastTime = 0;//上一次计算时间
             var lastSize = 0;//上一次计算的文件大小
             var speed=0
             var units='b/s'
            xhr.upload.addEventListener('progress', function (event) {
                   
                    /*验证数据*/
                    if(lastTime == 0)
                    {
                        lastTime = new Date().getTime();
                        lastSize = event.loaded;
                        return;
                    }

                    /*计算间隔*/
                    var nowTime = new Date().getTime();
                    var intervalTime = (nowTime - lastTime)/1000;//时间单位为毫秒，需转化为秒
                    var intervalSize = event.loaded - lastSize;

                    /*重新赋值以便于下次计算*/
                    lastTime = nowTime;
                    lastSize = event.loaded;


                    /*计算速度*/
                    speed = intervalSize/intervalTime;
                    var bSpeed = speed;//保存以b/s为单位的速度值，方便计算剩余时间
                    units = 'b/s';//单位名称
                    if(speed/1024>1){
                        speed = speed/1024;
                        units = 'k/s';
                    }
                    if(speed/1024>1){
                        speed = speed/1024;
                        units = 'M/s';
                    }

                    // /*计算剩余时间*/
                    //  var leftTime = ((event.total - event.loaded) / bSpeed);
                    //  console.log(leftTime.toFixed(1) + "秒")

            })

            xhr.send(form);
              
            xhr.onreadystatechange = () => {
              // console.log(xhr.readyState)
              //  console.log(xhr.status)
                  if(xhr.readyState === 4 && xhr.status === 200) {
                    // console.log("成功")
                    // console.log(file.chunks) 
                          item.uploadPercentage = (this.chunkSize * 100) / file.size;
                     
                     for(let i=0; i<that.files.length; i++){
              
                    if(file.name==that.files[i].name){
                      //解决 传输过程当中，在不断网情况下，网速偶发0.0问题，让网速显示平滑过度  
                      if(speed.toFixed(1)!=0){
                            that.files[i].speed=speed.toFixed(1)
                            that.files[i].units=units
                      }
                      
        
                       that.files[i].accomplishSize=that.files[i].accomplishSize+this.chunkSize
                      // console.log(that.files[i].uploadPercentage+item.uploadPercentage)
                      // console.log(Math.floor(that.files[i].uploadPercentage+item.uploadPercentage))
                       that.files[i].uploadPercentage=that.files[i].uploadPercentage+item.uploadPercentage
                       if(that.files[i].uploadPercentage>100){
                         that.files[i].uploadPercentage=100
                       }
                    } 
                   }
                  }
                };
           }
       },

       //拖拽上传
      onDrag(e) {
        //阻止默认行为
          e.stopPropagation();
          e.preventDefault();
      },
      //批量文件上传
      onDrop(e) {
         let self = this
          console.log(e)
          //阻止默认行为 
          e.stopPropagation();
          e.preventDefault();
          var dt = e.dataTransfer;
     
          var items = e.dataTransfer.items;
          console.log(items.length)
          
          //  this.entries(items)
          var itemsCount =items.length
            var entries = []; 

          for (var i = 0; i<itemsCount; i++) {

            // this.uploadFile(dt.files[i]);
           entries.push(items[i].webkitGetAsEntry());
          }

          console.log(entries)

      
          //区分  混合批量的话，自动分配
         //每个Entry对象具备isDirectory, isFile属性，判定目标为文件或是文件夹
         entries.forEach(function(entry, key) {
            if(entry.isDirectory && !entry.isFile) {
                 // 文件夹
                readDir(entry)
            }else if(!entry.isDirectory && entry.isFile) { 
                // 文件
                console.log("一级区分-文件")
                console.log(entry.fullPath)
                let fullPathEntry=entry.fullPath
                // fullPathEntry.charAt(0)
                // alert(fullPathEntry.charAt(0))
                if(fullPathEntry.charAt(0)=="/"){
                        fullPathEntry = fullPathEntry.substr(1)
                        // alert(fullPathEntry)
                }
                entry.file(function(file){
                          console.log(file);
                         self.chkMd5(file,fullPathEntry)
                          
                })
                
            }else{
                return false;
            }

           })


          function readDir(directoryEntry) {
                    console.log(directoryEntry)
              if (!directoryEntry.isDirectory || !typeof value === 'function') {
                  return false;
              }

              var fileEntriesContainer = [];
              var dirReader = directoryEntry.createReader();
              // console.log(dirReader)
              // 遍历目录，由于无法一次性返回全部，所以需要递归调用，直到返回结果为空，执行回调函数。
              var readEntries = function() {
                dirReader.readEntries (function(results) {
                  // console.log(results.length)
                  if (!results.length) {
                     console.log("console.log(fileEntriesContainer)")
                    // console.log(fileEntriesContainer)
                    // readDirCallback(fileEntriesContainer);
                  } else { //读取文件夹嵌套
                    console.log("323333333")
                    // console.log(results)

                    // console.log(results[0].isFile)
                      
                      for (var i = 0; i<results.length; i++) {
                          if(results[i].isFile==false){//文件夹
                           readDir(results[i])
                           }else if(results[i].isFile==true){//文件
                             
                            console.log("上传")
                            

                            console.log(results[i].isFile)
                            console.log(results[i].name)
                            console.log(results)
                            console.log(results[i].fullPath)
                             var fullPath=results[i].fullPath
                             if(fullPath.charAt(0)=="/"){
                                  fullPath = fullPath.substr(1)
                                   // alert(fullPathEntry)
                               }
                              // 通过file函数即可获得File 对象
                              // File 对象处理请自行参阅 FileReader
                              results[i].file(function(file){
                                console.log(file);
                                self.chkMd5(file,fullPath)
                                // self.uploadFile(file,fullPath);
                                
                                // var fileReader = new FileReader(); //读取文件内容
                                // fileReader.readAsText(file);  //读取文本文件
                                // console.log(fileReader)
                                // fileReader.addEventListener('load', function(){
                                //     console.log(this.result);
                                // })

                              })
                             
                          }
                     }
                    // fileEntriesContainer = fileEntriesContainer.concat(toArray(results));
                    readEntries();
                  }
                });
              };
              readEntries();
         } 

  
       },
      
      //上传业务逻辑主体
      entries(items){
            let self = this
            
      },

        handleMenuClick(e) {
      console.log('click', e);
      // this.$refs.readFiles.dispatchEvent(new MouseEvent('click'))
    },

      deleteHttp(md5ID,fileID){
  
          console.log(md5ID)
          console.log(fileID)
          this.fileIDList.push(fileID)
          for(let i=0; i<this.requests.length; i++){
              if(fileID==this.requests[i].fileID){
                   this.requests[i].abort()
              }  
          }
       },
       
       //批量取消
       deleteHttpBatch(){
         console.log("deleteHttpBatch")
          for(let i=0; i<this.requests.length; i++){
                   this.requests[i].abort() 
          }

         for(let K=0; K<this.files.length; K++){
                //  console.log(this.files.fileID)
                 this.fileIDList.push(this.files[K].fileID)
                 var myList  = document.getElementById(this.files[K].fileID);
                 myList.remove();
          }

         this.files=[]
        //  this.fileIDList=[]

       },
       

       fileClick(index) {
          console.log('子组件的fileClick被调用了')
          console.log('index:  '+index)

       }

     },
 
components: {
      ProgressBar
    },
    watch:{
         value(val){
           this.value = val
            },
         dataUploadHttp(val){
            // alert(val)
            console.log(val)
            this.uploadHttp = val
         },
         dataQueryFileHttp(val){
            // alert(val)
            this.queryFileHttp = val
         },
         dataToken(val){
           this.token = val
         }
      },
      
}
</script>

<style scoped>
#fileUpload {
            /* position: absolute; */
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            /* opacity: 0; */
        }
.uploadHttp{
  border-radius: 6px;
  margin: 5px;
  height: 260px;
  display: flex;
  /* border: 1px solid rgb(154, 189, 255); */
  text-align: center;
  justify-content: center;
  align-items: center;
      position: absolute;
    top: 0;
    width: 100%;
    margin-top:30px
}

.textCenter{
   color: #C9CCD0;
   text-shadow: 0 5px rgba(255, 255, 255, 0.4);
    font-size: 22px;
  /* font-weight: bold; */
}

.progress{
      width: 100%;
      padding: 7px;
}
.progress-bar-striped{
  height: 30px;
}
.uploadHttp_box{
  position: relative;
  min-height: 300px;
}
.uploadHttp_box_top{
  display: flex;
  justify-content: space-between;
}
.uploadHttp_box_l{
  margin-right:8px;
}

</style>
