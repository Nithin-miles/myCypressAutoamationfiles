import uploadHttp from './src/uploadHttp.vue'

uploadHttp.install = function(Vue) {
    Vue.component(uploadHttp.name, uploadHttp)
}

export default uploadHttp