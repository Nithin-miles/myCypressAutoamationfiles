<template>
  <div class="home">
    <div class="nav">
      <div class="wp-disk-header__left">
        <img src="../assets/folder.png" />文件管理
      </div>
    </div>
    <!-- <w-button disabled>圆角按钮</w-button>
        <w-button type="w-primary" disabled>主要按钮</w-button>
        <w-button type="w-success" disabled>成功按钮</w-button>
        <w-button type="w-info" disabled>信息按钮</w-button>
        <w-button type="w-warning" disabled>警告按钮</w-button>
        <w-button type="w-danger" disabled>危险按钮</w-button>

  <FilesUpload></FilesUpload> -->
    <FilesUpload marginTop="75"></FilesUpload>
  </div>
</template>

<script>
// @ is an alias to /src
export default {
  name: "Home",
};
</script>
<style lang="less" scoped>
.home {
  height: 100%;
}
.nav {
  width: 100%;
  height: 60px;
  margin-bottom: 15px;
  background-color: #fff;
  -webkit-box-shadow: 0 3px 10px 0 #0000000f;
  box-shadow: 0 3px 10px 0 #0000000f;
}
.wp-disk-header__left {
  display: flex;
  flex-direction: row;
  align-items: center;

  height: 60px;
  margin-left: 20px;
  font-size: 20px;
  font-weight: 600;
}
.wp-disk-header__left img {
  height: 50px;
  margin-right: 5px;
  // width: 133px;
  // height: auto;
  // display: block;
}
</style>
