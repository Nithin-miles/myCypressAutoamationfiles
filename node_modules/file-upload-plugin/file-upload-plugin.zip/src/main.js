import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
import upLoadPlugin from '../packages/index'
import '../packages/theme-chalk/lib/index.css'
import Antd from 'ant-design-vue';
import 'ant-design-vue/dist/antd.css';
import './assets/css/scrollReset.css';
import ElementUI from 'element-ui';
import axios from 'axios';
import VueAxios from 'vue-axios';
import 'element-ui/lib/theme-chalk/index.css'
Vue.use(Antd);
Vue.use(ElementUI)
Vue.use(upLoadPlugin)
Vue.use(VueAxios, axios)
Vue.config.productionTip = false

new Vue({
    router,
    store,
    render: h => h(App)
}).$mount('#app')