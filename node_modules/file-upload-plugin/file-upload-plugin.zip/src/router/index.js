import Vue from 'vue'
import VueRouter from 'vue-router'
import Home from '../views/Home.vue'
import About from '../views/About.vue'

Vue.use(VueRouter)

const routes = [{
        path: '/',
        name: 'Home',
        component: Home
    },
    {
        path: '/about',
        name: 'about',
        component: About
    },
    {
        path: '/mine',
        name: 'mine',
        component: () =>
            import ('../../packages/filesUpload/src/log.vue')
    },
    {
        path: '/link',
        name: 'link',
        component: () =>
            import ('../../packages/filesUpload/src/ShareFiles/link.vue')
    },

]

const router = new VueRouter({
    mode: 'history',
    base: process.env.BASE_URL,
    routes
})

export default router