import axios from 'axios'
let requestList = new Set() // 存储请求url
import Config from "../config/http";
const service = axios.create({
    // api的base_url
    baseURL: Config.serviceHost,
    // baseURL: '/api',
    // baseURL: process.env.BASE_URL,
    timeout: 8000,
    headers: { 'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8' },
    // headers: {"Access-Control-Allow-Credentials": "true"},
    withCredentials: true,
    crossDomain: true,
})

// request拦截器
service.interceptors.request.use(config => {
    console.log(config)
        // setTimeout(() => {
        //     requestList.delete(response.config.url)
        //   }, 600)
    console.log(localStorage.getItem('token'))
    if (localStorage.getItem('token')) {

        config.headers.token = localStorage.getItem('token');
        // config.headers.Cookies = localStorage.getItem('userName');
    }
    return config;

}, error => {
    // store.commit('loading/hideLoading')
    // Do something with request error
    console.log('request拦截器1', error) // for debug
    Promise.reject(error)
})


// respone拦截器
service.interceptors.response.use(response => {
    return response.data;
}, error => {
    // 相同请求不得在600毫秒内重复发送，反之继续执行
    // setTimeout(() => {
    //   requestList.delete(error.config.url)
    // }, 2000)
    console.log('respone拦截器22' + error) // for debug
    console.log(JSON.stringify(error))
})

export default service